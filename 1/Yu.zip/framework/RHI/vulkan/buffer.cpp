﻿//
// Created by 秋鱼 on 2022/7/5.
//

#include "buffer.hpp"
#include "error.hpp"
#include "vulkan_utils.hpp"

#ifdef USE_VMA
#define VMA_IMPLEMENTATION
#include <vk_mem_alloc.h>
#endif

namespace yu::vk {

/**
 * @brief 缓冲区的创建信息
 * @param usage 指示缓冲区的用途
 * @param flags 一些额外的信息
 */
VkBufferCreateInfo makeBufferCreateInfo(VkDeviceSize size,
                                        VkBufferUsageFlags usage,
                                        VkBufferCreateFlags flags)
{
    VkBufferCreateInfo createInfo = {VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    createInfo.size  = size;
    createInfo.usage = usage | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    createInfo.flags = flags;

    return createInfo;
}

/**
 * @brief 缓冲区视图的创建信息
 * @param format 缓冲区的格式
 * @param range 所指定的缓冲区范围
 * @param offset 视图所指定内存在缓冲区的偏移
 */
VkBufferViewCreateInfo makeBufferViewCreateInfo(VkBuffer buffer,
                                                VkFormat format,
                                                VkDeviceSize range,
                                                VkDeviceSize offset,
                                                VkBufferViewCreateFlags flags)
{
    VkBufferViewCreateInfo createInfo = {VK_STRUCTURE_TYPE_BUFFER_VIEW_CREATE_INFO};
    createInfo.buffer = buffer;
    createInfo.offset = offset;
    createInfo.range  = range;
    createInfo.flags  = flags;
    createInfo.format = format;

    return createInfo;
}

/**
 * @brief 通过描述符的缓冲区信息来设置缓冲区视图创建信息
 */
VkBufferViewCreateInfo makeBufferViewCreateInfo(const VkDescriptorBufferInfo& descrInfo,
                                                VkFormat fmt,
                                                VkBufferViewCreateFlags flags)
{
    VkBufferViewCreateInfo createInfo = {VK_STRUCTURE_TYPE_BUFFER_VIEW_CREATE_INFO};
    createInfo.buffer = descrInfo.buffer;
    createInfo.offset = descrInfo.offset;
    createInfo.range  = descrInfo.range;
    createInfo.flags  = flags;
    createInfo.format = fmt;

    return createInfo;
}

/**
 * @brief 创建 vulkan 缓冲区
 */
VkBuffer createBuffer(VkDevice device, VkBufferCreateInfo info)
{
    VkBuffer buffer;
    VkResult result = vkCreateBuffer(device, &info, nullptr, &buffer);
    assert(result == VK_SUCCESS);
    return buffer;
}

/**
 * @brief 创建 vulkan 缓冲区的视图
 */
VkBufferView createBufferView(VkDevice device, VkBufferViewCreateInfo info)
{
    VkBufferView bufferView;
    VkResult     result = vkCreateBufferView(device, &info, nullptr, &bufferView);
    assert(result == VK_SUCCESS);
    return bufferView;
}

/** 
* 映射这个缓冲区的某一个内存范围
* 
* @param size (可选）要映射的内存范围的大小。通过VK_WHOLE_SIZE来映射整个缓冲区范围
* @param offset (可选)从头开始的字节偏移
* 
* @return VkResult of the buffer mapping call
*/
VkResult Buffer::map(VkDeviceSize size, VkDeviceSize offset)
{
    return vkMapMemory(device, memory, offset, size, 0, &mapped);
}
/**
* 解除对当前内存的映射
*
* @note 不返回结果，因为vkUnmapMemory不会失败
*/
void Buffer::unmap()
{
    if (mapped) {
        vkUnmapMemory(device, memory);
        mapped = nullptr;
    }
}

/** 
* 将分配的内存块附加到缓冲区上
* 
* @param offset (Optional) 要绑定的内存区域的字节偏移量（从开始）
* 
* @return VkResult of the bindBufferMemory call
*/
VkResult Buffer::bind(VkDeviceSize offset)
{
    return vkBindBufferMemory(device, buffer, memory, offset);
}

/**
* 设置当前缓冲区的默认描述符
*
* @param size (可选) 描述符的内存大小
* @param offset (可选) 从头开始的字节偏移量
*
*/
void Buffer::setupDescriptor(VkDeviceSize size, VkDeviceSize offset)
{
    descriptor.offset = offset;
    descriptor.buffer = buffer;
    descriptor.range  = size;
}

/**
* 复制指定的数据到映射的缓冲区
* 
* @param data 指向要复制的数据的指针
* @param size 要复制的数据的大小，以机器单位计算
*
*/
void Buffer::copyTo(void* data, VkDeviceSize size)
{
    assert(mapped);
    memcpy(mapped, data, size);
}

/** 
* 刷新缓冲区的内存范围，使其对设备可见
*
* @note 只对 non-coherent memory 有要求
*
* @param size (Optional) 要刷新的内存大小。通过VK_WHOLE_SIZE来刷新整个缓冲区范围
* @param offset (Optional) 从开始的字节偏移量
*
* @return VkResult of the flush call
*/
VkResult Buffer::flush(VkDeviceSize size, VkDeviceSize offset)
{
    VkMappedMemoryRange mappedRange = {};
    mappedRange.sType  = VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE;
    mappedRange.memory = memory;
    mappedRange.offset = offset;
    mappedRange.size   = size;
    return vkFlushMappedMemoryRanges(device, 1, &mappedRange);
}

/**
* Invalidate 缓冲区的一个内存范围，使其对 host 可见
*
* @note 只对 non-coherent memory 有要求
*
* @param size (Optional) 要刷新的内存大小。通过VK_WHOLE_SIZE来刷新整个缓冲区范围
* @param offset (Optional) 从开始的字节偏移量
*
* @return VkResult of the invalidate call
*/
VkResult Buffer::invalidate(VkDeviceSize size, VkDeviceSize offset)
{
    VkMappedMemoryRange mappedRange = {};
    mappedRange.sType  = VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE;
    mappedRange.memory = memory;
    mappedRange.offset = offset;
    mappedRange.size   = size;
    return vkInvalidateMappedMemoryRanges(device, 1, &mappedRange);
}

/**
 * @brief 释放该缓冲区持有的所有Vulkan资源
 */
void Buffer::destroy()
{
    if (buffer) {
        vkDestroyBuffer(device, buffer, nullptr);
    }
    if (memory) {
        vkFreeMemory(device, memory, nullptr);
    }
}

/**
 * @brief 获取缓冲区在设备上的地址
 */
VkDeviceAddress Buffer::getDeviceAddress() const
{
    VkBufferDeviceAddressInfo info = {VK_STRUCTURE_TYPE_BUFFER_DEVICE_ADDRESS_INFO};
    info.buffer = buffer;
    return vkGetBufferDeviceAddress(device, &info);
}

VkResult CreateBufferVMA(VkBufferUsageFlags usageFlags,
                         VkDeviceSize size,
                         VmaAllocator vmaAllocator,
                         VmaMemoryUsage vmaUsageFlags,
                         VkBuffer* pBuffer,
                         VmaAllocation* pAllocation,
                         void** pData,
                         std::string_view name,
                         VmaAllocationCreateFlags allocationFlags)
{
    VkBufferCreateInfo bufferCreateInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufferCreateInfo.usage = usageFlags;
    bufferCreateInfo.size  = size;

    VmaAllocationCreateInfo allocInfo = {};
    allocInfo.usage     = vmaUsageFlags;
    allocInfo.flags     = allocationFlags;
    allocInfo.pUserData = const_cast<char*>(name.data());

    VK_CHECK(vmaCreateBuffer(vmaAllocator, &bufferCreateInfo, &allocInfo, pBuffer, pAllocation, nullptr));

    if (pData != nullptr) {
        VK_CHECK(vmaMapMemory(vmaAllocator, *pAllocation, pData));
    }

    return VK_SUCCESS;
}

VkResult CreateBuffer(VkDevice device,
                      VkPhysicalDevice physicalDevice,
                      VkBufferUsageFlags usageFlags,
                      VkMemoryPropertyFlags memoryPropertyFlags,
                      VkDeviceSize size,
                      VkBuffer* pBuffer,
                      VkDeviceMemory* memory,
                      bool bCopyData,
                      void** pData)
{
    // 创建缓冲区句柄
    VkBufferCreateInfo bufferCreateInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufferCreateInfo.usage       = usageFlags;
    bufferCreateInfo.size        = size;
    bufferCreateInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK_CHECK(vkCreateBuffer(device, &bufferCreateInfo, nullptr, pBuffer));

    // 创建支持缓冲区句柄的内存
    VkMemoryRequirements memReqs;
    vkGetBufferMemoryRequirements(device, *pBuffer, &memReqs);

    VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAllocInfo.allocationSize  = memReqs.size;
    // 找到一个符合缓冲区属性的内存类型索引
    if (pData != nullptr) {
        memoryPropertyFlags |= VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    }
    memAllocInfo.memoryTypeIndex = GetMemoryType(physicalDevice, memReqs.memoryTypeBits, memoryPropertyFlags);

    // 如果缓冲区设置了VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT，也需要在分配时启用相应的标志
    VkMemoryAllocateFlagsInfoKHR allocFlagsInfo{};
    if (usageFlags & VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT) {
        allocFlagsInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_FLAGS_INFO_KHR;
        allocFlagsInfo.flags = VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT_KHR;
        memAllocInfo.pNext   = &allocFlagsInfo;
    }
    VK_CHECK(vkAllocateMemory(device, &memAllocInfo, nullptr, memory));

    // 如果传递了一个指向缓冲区数据的指针，则映射缓冲区并复制数据
    if (bCopyData) {
        void* mapped;
        VK_CHECK(vkMapMemory(device, *memory, 0, size, 0, &mapped));
        std::memcpy(mapped, *pData, size);
        // 如果没有要求主机一致性，则进行手动刷新，使写入的内容可见
        if ((memoryPropertyFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) == 0) {
            VkMappedMemoryRange mappedRange{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
            mappedRange.memory = *memory;
            mappedRange.offset = 0;
            mappedRange.size   = size;
            vkFlushMappedMemoryRanges(device, 1, &mappedRange);
        }
        vkUnmapMemory(device, *memory);
    } else if (pData != nullptr) {
        VK_CHECK(vkMapMemory(device, *memory, 0, memReqs.size, 0, pData));
    }

    // 将内存附加到缓冲区对象上
    VK_CHECK(vkBindBufferMemory(device, *pBuffer, *memory, 0));

    return VK_SUCCESS;
}

VkResult CreateBuffer(VkDevice device,
                      VkPhysicalDevice physicalDevice,
                      VkBufferUsageFlags usageFlags,
                      VkMemoryPropertyFlags memoryPropertyFlags,
                      VkDeviceSize size,
                      Buffer* pBuffer,
                      void* pData)
{
    pBuffer->device = device;

    // 创建缓冲区句柄device_device_device_
    VkBufferCreateInfo bufferCreateInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufferCreateInfo.usage = usageFlags;
    bufferCreateInfo.size  = size;
    VK_CHECK(vkCreateBuffer(device, &bufferCreateInfo, nullptr, &pBuffer->buffer));

    // 创建支持缓冲区句柄的内存
    VkMemoryRequirements memReqs;
    vkGetBufferMemoryRequirements(device, pBuffer->buffer, &memReqs);

    VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAllocInfo.allocationSize  = memReqs.size;
    // 找到一个符合缓冲区属性的内存类型索引
    if (pData != nullptr) {
        memoryPropertyFlags |= VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    }
    memAllocInfo.memoryTypeIndex = GetMemoryType(physicalDevice, memReqs.memoryTypeBits, memoryPropertyFlags);

    // 如果缓冲区设置了VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT，也需要在分配时启用相应的标志
    VkMemoryAllocateFlagsInfoKHR allocFlagsInfo{};
    if (usageFlags & VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT) {
        allocFlagsInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_FLAGS_INFO_KHR;
        allocFlagsInfo.flags = VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT_KHR;
        memAllocInfo.pNext   = &allocFlagsInfo;
    }
    VK_CHECK(vkAllocateMemory(device, &memAllocInfo, nullptr, &pBuffer->memory));

    pBuffer->alignment           = memReqs.alignment;
    pBuffer->size                = size;
    pBuffer->usageFlags          = usageFlags;
    pBuffer->memoryPropertyFlags = memoryPropertyFlags;

    // 如果传递了一个指向缓冲区数据的指针，则映射缓冲区并复制数据
    if (pData != nullptr) {
        VK_CHECK(pBuffer->map());
        memcpy(pBuffer->mapped, pData, size);
        if ((memoryPropertyFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) == 0)
            pBuffer->flush();

        pBuffer->unmap();
    }

    // 初始化一个覆盖整个缓冲区大小的默认描述符
    pBuffer->setupDescriptor();

    // 将内存附加到缓冲区对象上
    return pBuffer->bind();
}

} // namespace yu::vk