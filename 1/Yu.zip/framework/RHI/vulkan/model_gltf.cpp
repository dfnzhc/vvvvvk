﻿//
// Created by 秋鱼 on 2022/9/7.
//

#define TINYGLTF_NO_STB_IMAGE_WRITE
#include "model_gltf.hpp"
#include "descriptor_sets.hpp"
#include "common/common.hpp"

namespace yu::vk {

void ModelGltf::load(std::string_view filename, ResourceAllocator* resourceAllocator, GltfAttributes loadAttributes)
{
    tinygltf::Model    tModel;
    tinygltf::TinyGLTF tContext;

    LOG_INFO("Loading file: {}", filename);

    auto fullPath = yu::GetModelFile(filename.data());

    std::string warn, error;
    if (!tContext.LoadASCIIFromFile(&tModel, &error, &warn, fullPath)) {
        LOG_FATAL("Error: {} \nFailed to load/parse .gltf file: {}.", error, fullPath);
    }

    gltfScene.importMaterials(tModel);
    gltfScene.importDrawableNodes(tModel, loadAttributes);

    // 创建缓冲区
    resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.positions, &positionBufferInfo);
    resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.indices, &indexBufferInfo);

    if ((loadAttributes & GltfAttributes::Normal) != GltfAttributes::NoAttribs) {
        resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.normals, &normalBufferInfo);
    }
    if ((loadAttributes & GltfAttributes::Texcoord_0) != GltfAttributes::NoAttribs) {
        resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.texcoords0, &uv0BufferInfo);
    }
    if ((loadAttributes & GltfAttributes::Texcoord_1) != GltfAttributes::NoAttribs) {
        resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.texcoords1, &uv1BufferInfo);
    }
    if ((loadAttributes & GltfAttributes::Tangent) != GltfAttributes::NoAttribs) {
        resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.tangents, &tangentBufferInfo);
    }
    if ((loadAttributes & GltfAttributes::Color_0) != GltfAttributes::NoAttribs) {
        resourceAllocator->getStaticBuffer().allocBuffer(gltfScene.colors0, &colorBufferInfo);
    }
    resourceAllocator->uploadStaticAllocation();

    std::vector<MaterialGLTF> shadeMaterials;
    for (const auto& m : gltfScene.materials) {
        shadeMaterials.emplace_back(MaterialGLTF{m.shadingModel, m.baseColorFactor, m.baseColorTexture,
                                                 m.metallicFactor, m.roughnessFactor, m.metallicRoughnessTexture,
                                                 m.emissiveTexture, m.emissiveFactor,
                                                 m.alphaMode, m.alphaCutoff, m.doubleSided,
                                                 m.normalTexture, m.normalTextureScale,
                                                 m.occlusionTexture, m.occlusionTextureStrength});
    }
    if (!shadeMaterials.empty()) {
        matBuffer = resourceAllocator->createBuffer(shadeMaterials, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT);
    }

    {
        std::vector<DescGLTF> descs(1);
        auto& desc = descs[0];
        desc.materialAddress = matBuffer.getDeviceAddress();
        descBuffer = resourceAllocator->createBuffer(descs, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT);
    }

    {
        auto basePath = fullPath.substr(0, fullPath.find_last_of('/') + 1);

        // 加载纹理
        for (const auto& imgFile : gltfScene.textures) {
            textures.push_back(resourceAllocator->createTexture<Texture2D>(basePath + imgFile));
        }
    }

    loadedAttributes = loadAttributes;
}

void ModelGltf::destroy()
{
    matBuffer.destroy();
    descBuffer.destroy();

    gltfScene.destroy();

    for (auto& tex : textures) {
        tex.destroy();
    }
}

void ModelGltf::setDescriptorSet(VkDevice device,
                                 ResourceAllocator* resourceAllocator,
                                 DescriptorSetBindings* pDescSetBinds,
                                 VkDescriptorSet* pDescSet)
{
    // 更新描述符信息
    resourceAllocator->getDynamicBuffer().setDescriptorSet(static_cast<uint32_t>(SceneBindingsGLTF::eGlobals), sizeof(GlobalUniforms), *pDescSet);

    std::vector<VkWriteDescriptorSet> writes;

    VkDescriptorBufferInfo sceneDesc{descBuffer.buffer, 0, VK_WHOLE_SIZE};
    writes.emplace_back(pDescSetBinds->makeWrite(*pDescSet, static_cast<uint32_t>(SceneBindingsGLTF::eGltfDescs), &sceneDesc));

    // All texture samplers
    std::vector<VkDescriptorImageInfo> diit;
    for (auto& texture : textures) {
        diit.push_back(texture.descriptor);
    }
    if (!textures.empty()) {
        writes.emplace_back(pDescSetBinds->makeWriteArray(*pDescSet, static_cast<uint32_t>(SceneBindingsGLTF::eTextures), diit.data()));
    }

    // Writing the information
    vkUpdateDescriptorSets(device, static_cast<uint32_t>(writes.size()), writes.data(), 0, nullptr);
}

void ModelGltf::draw(VkCommandBuffer cmdBuffer, VkPipelineLayout pipelineLayout, PushConstantRasterGLTF* pConstant)
{
    std::vector<VkBuffer>     vertexBuffers = {positionBufferInfo.buffer};
    std::vector<VkDeviceSize> offsets       = {positionBufferInfo.offset};

    if ((loadedAttributes & GltfAttributes::Normal) != GltfAttributes::NoAttribs) {
        vertexBuffers.push_back(normalBufferInfo.buffer);
        offsets.push_back(normalBufferInfo.offset);
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_0) != GltfAttributes::NoAttribs) {
        vertexBuffers.push_back(uv0BufferInfo.buffer);
        offsets.push_back(uv0BufferInfo.offset);
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_1) != GltfAttributes::NoAttribs) {
        vertexBuffers.push_back(uv1BufferInfo.buffer);
        offsets.push_back(uv1BufferInfo.offset);
    }
    if ((loadedAttributes & GltfAttributes::Tangent) != GltfAttributes::NoAttribs) {
        vertexBuffers.push_back(tangentBufferInfo.buffer);
        offsets.push_back(tangentBufferInfo.offset);
    }
    if ((loadedAttributes & GltfAttributes::Color_0) != GltfAttributes::NoAttribs) {
        vertexBuffers.push_back(colorBufferInfo.buffer);
        offsets.push_back(colorBufferInfo.offset);
    }

    vkCmdBindVertexBuffers(cmdBuffer, 0, static_cast<uint32_t>(vertexBuffers.size()), vertexBuffers.data(), offsets.data());
    vkCmdBindIndexBuffer(cmdBuffer, indexBufferInfo.buffer, indexBufferInfo.offset, VK_INDEX_TYPE_UINT32);

    for (auto& node : gltfScene.nodes) {
        auto& primitive = gltfScene.primMeshes[node.primMesh];

        if (pConstant) {
            pConstant->modelMatrix = node.worldMatrix;
            pConstant->objIndex    = node.primMesh;
            pConstant->materialId  = primitive.materialIndex;
            vkCmdPushConstants(cmdBuffer, pipelineLayout, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0,
                               sizeof(PushConstantRasterGLTF), pConstant);
        }
        vkCmdDrawIndexed(cmdBuffer, primitive.indexCount, 1, primitive.firstIndex, primitive.vertexOffset, 0);
    }
}

std::vector<VkVertexInputAttributeDescription> ModelGltf::getVertexInputDescriptions(uint32_t startBinding)
{
    std::vector<VkVertexInputAttributeDescription> inputAttr;

    // position
    inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32B32_SFLOAT, 0});
    startBinding += 1;

    if ((loadedAttributes & GltfAttributes::Normal) != GltfAttributes::NoAttribs) {
        inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32B32_SFLOAT, 0});
        startBinding += 1;
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_0) != GltfAttributes::NoAttribs) {
        inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32_SFLOAT, 0});
        startBinding += 1;
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_1) != GltfAttributes::NoAttribs) {
        inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32_SFLOAT, 0});
        startBinding += 1;
    }
    if ((loadedAttributes & GltfAttributes::Tangent) != GltfAttributes::NoAttribs) {
        inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32B32A32_SFLOAT, 0});
        startBinding += 1;
    }
    if ((loadedAttributes & GltfAttributes::Color_0) != GltfAttributes::NoAttribs) {
        inputAttr.push_back({startBinding, startBinding, VK_FORMAT_R32G32B32A32_SFLOAT, 0});
        startBinding += 1;
    }

    return inputAttr;
}

std::vector<VkVertexInputBindingDescription> ModelGltf::getBindingDescriptions(uint32_t startBinding)
{

    std::vector<VkVertexInputBindingDescription> bindings;

    // position
    bindings.push_back({startBinding, sizeof(glm::vec3)});

    uint32_t offset = 0;
    if ((loadedAttributes & GltfAttributes::Normal) != GltfAttributes::NoAttribs) {
        bindings.push_back({startBinding + (++offset), sizeof(glm::vec3)});
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_0) != GltfAttributes::NoAttribs) {
        bindings.push_back({startBinding + (++offset), sizeof(glm::vec2)});
    }
    if ((loadedAttributes & GltfAttributes::Texcoord_1) != GltfAttributes::NoAttribs) {
        bindings.push_back({startBinding + (++offset), sizeof(glm::vec2)});
    }
    if ((loadedAttributes & GltfAttributes::Tangent) != GltfAttributes::NoAttribs) {
        bindings.push_back({startBinding + (++offset), sizeof(glm::vec4)});
    }
    if ((loadedAttributes & GltfAttributes::Color_0) != GltfAttributes::NoAttribs) {
        bindings.push_back({startBinding + (++offset), sizeof(glm::vec4)});
    }

    return bindings;
}

} // yu::vk