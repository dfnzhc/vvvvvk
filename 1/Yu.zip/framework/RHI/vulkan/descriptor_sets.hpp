﻿//
// Created by 秋鱼 on 2022/8/4.
//

#pragma once

#include <utility>
#include <vulkan/vulkan_core.h>

#include "error.hpp"

namespace yu::vk {

inline VkDescriptorPool CreateDescriptorPool(VkDevice device, size_t poolSizeCount, const VkDescriptorPoolSize* poolSizes, uint32_t maxSets)
{
    VkDescriptorPool           descrPool;
    VkDescriptorPoolCreateInfo descrPoolInfo = {};
    descrPoolInfo.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    descrPoolInfo.pNext         = nullptr;
    descrPoolInfo.maxSets       = maxSets;
    descrPoolInfo.poolSizeCount = uint32_t(poolSizeCount);
    descrPoolInfo.pPoolSizes    = poolSizes;

    // scene pool
    VK_CHECK(vkCreateDescriptorPool(device, &descrPoolInfo, nullptr, &descrPool));
    return descrPool;
}

inline VkDescriptorPool CreateDescriptorPool(VkDevice device, const std::vector<VkDescriptorPoolSize>& poolSizes, uint32_t maxSets)
{
    return CreateDescriptorPool(device, poolSizes.size(), poolSizes.data(), maxSets);
}

inline VkDescriptorSet AllocateDescriptorSet(VkDevice device, VkDescriptorPool pool, VkDescriptorSetLayout layout)
{
    VkDescriptorSetAllocateInfo allocInfo = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    allocInfo.descriptorPool     = pool;
    allocInfo.descriptorSetCount = 1;
    allocInfo.pSetLayouts        = &layout;

    VkDescriptorSet set;
    VK_CHECK(vkAllocateDescriptorSets(device, &allocInfo, &set));

    return set;
}

inline void AllocateDescriptorSets(VkDevice device,
                                   VkDescriptorPool pool,
                                   VkDescriptorSetLayout layout,
                                   uint32_t count,
                                   std::vector<VkDescriptorSet>& sets)
{
    sets.resize(count);
    std::vector<VkDescriptorSetLayout> layouts(count, layout);

    VkDescriptorSetAllocateInfo allocInfo = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    allocInfo.descriptorPool     = pool;
    allocInfo.descriptorSetCount = count;
    allocInfo.pSetLayouts        = layouts.data();

    VK_CHECK(vkAllocateDescriptorSets(device, &allocInfo, sets.data()));
}

/**
 * @class DescriptorSetBindings
 * 
 * @brief DescriptorSetBindings 是一个工具类，用于保存单个 'VkDescriptorSetLayout' 的一系列绑定信息 'VkDescriptorSetLayoutBinding'
 * 有一系列用于创建 ‘VkDescriptorSetLayout' 和 'VkDescriptorPool' 的方法，还有一些用绑定信息填充 'VkWriteDescriptorSet' 的方法
 */


/* 
* 代码实例
* descriptorSetBindings binds;
* 
* binds.addBinding( VIEW_BINDING, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1, VK_SHADER_STAGE_VERTEX_BIT);
* binds.addBinding(XFORM_BINDING, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1, VK_SHADER_STAGE_VERTEX_BIT);
* 
* VkDescriptorSetLayout layout = binds.createLayout(device);
* 
* VkDescriptorPool      pool   = binds.createPool(device, 2);
* 
* # 更新绑定的数据
* std::vector<VkWriteDescriptorSet> updates;
* 
* updates.push_back(binds.makeWrite(0, VIEW_BINDING, &view0BufferInfo));
* updates.push_back(binds.makeWrite(1, VIEW_BINDING, &view1BufferInfo));
* updates.push_back(binds.makeWrite(0, XFORM_BINDING, &xform0BufferInfo));
* updates.push_back(binds.makeWrite(1, XFORM_BINDING, &xform1BufferInfo));
* 
* vkUpdateDescriptorSets(device, updates.size(), updates.data(), 0, nullptr);
*/
class DescriptorSetBindings
{
public:
    DescriptorSetBindings() = default;
    explicit DescriptorSetBindings(std::vector<VkDescriptorSetLayoutBinding> bindings)
        : bindings_(std::move(bindings))
    {
    }

    /**
    * @brief 向描述符集中添加一个绑定
    * @param binding 绑定的槽，对应 shader 中的 layout 的绑定索引
    * @param type 绑定描述符的类型 
    * @param count 绑定个数
    * @param stageFlags 绑定资源可用的着色器阶段
    * @param pImmutableSampler 当绑定纹理时，需要设定采样器
    */
    void addBinding(uint32_t binding,
                    VkDescriptorType type,
                    uint32_t count,
                    VkShaderStageFlags stageFlags,
                    const VkSampler* pImmutableSampler = nullptr
    )
    {
        bindings_.push_back({binding, type, count, stageFlags, pImmutableSampler});
    }

    /**
    * @brief 向描述符添加一个绑定
    * @param layoutBinding 所添加的绑定
    */
    void addBinding(const VkDescriptorSetLayoutBinding& layoutBinding) { bindings_.emplace_back(layoutBinding); }

    /**
    * @brief 设置描述符绑定
    * @param bindings 所要设置的描述符绑定几何
    */
    void setBindings(const std::vector<VkDescriptorSetLayoutBinding>& bindings) { bindings_ = bindings; }

    /**
     * @brief 清除所有绑定
     */
    void clear() { bindings_.clear(); }

    /**
    * @brief 判断绑定是否为空
    * @return 如果为空则返回 true
    */
    [[nodiscard]] bool empty() const { return bindings_.empty(); }

    /**
    * @brief 返回绑定的数量
    * @return 描述符绑定点的数量
    */
    [[nodiscard]] size_t size() const { return bindings_.size(); }

    /**
    * @brief 返回描述符的绑定数据
    * @return 绑定点集合的数据指针
    */
    [[nodiscard]] const VkDescriptorSetLayoutBinding* data() const { return bindings_.data(); }

    /**
    * @brief 查询绑定点描述符的类型
    * @param binding 绑定点的索引
    * @return 描述符（资源）的类型
    */
    [[nodiscard]] VkDescriptorType getType(uint32_t binding) const;

    /**
     * @brief 查询绑定点的绑定个数
     * @param binding 绑定点的索引
     * @return 指定绑定点的绑定个数
     */
    [[nodiscard]] uint32_t getCount(uint32_t binding) const;

    /**
     * @brief 当描述符的绑定信息被设置、添加，调用当前函数会创建相应的描述符集
     * @param device Vulkan 设备句柄
     * @param flags 用于描述符的创建的 flag
     * @return 根据之前设置的绑定点所创建的描述符
     */
    VkDescriptorSetLayout createLayout(VkDevice device,
                                       VkDescriptorSetLayoutCreateFlags flags = 0) const;

    /**
     * @brief 当绑定信息被设置添加，调用当前函数会创建一个描述符池（descriptor pool）
     * @param device Vulkan 设备句柄
     * @param maxSets 池中描述符集的最大数量
     * @param flags 用于创建描述符池的 flags
     * @return 所创建的描述符池，它会管理所有绑定点的资源，并且为每种资源类型分配足够的描述符集
     */
    VkDescriptorPool createPool(VkDevice device, uint32_t maxSets = 1, VkDescriptorPoolCreateFlags flags = 0) const;

    /**
     * @brief 创建描述符
     * @param device Vulkan 设备句柄
     * @param descriptorPool 用于创建描述符的池
     * @param descriptorSetLayout 用于创建描述符的 layout
     * @return 按照传入的描述符池和布局创建的描述符
     */
    VkDescriptorSet allocSet(VkDevice device, VkDescriptorPool descriptorPool, VkDescriptorSetLayout descriptorSetLayout) const;
    
    /**
     * @brief 按照绑定点的类型，调整相应类型描述符池的大小
     * @param poolSizes 描述符池大小的集合，这个集合的大小和绑定数据类型的数量一致
     * @param numSets 描述符集中描述符的数量
     */
    void addRequiredPoolSizes(std::vector<VkDescriptorPoolSize>& poolSizes, uint32_t numSets) const;

    /**
     * @brief 创建描述符集的写入信息，用于资源的更新
     * @param dstSet 需要写入的描述符集
     * @param dstBinding 需要写入的绑定点
     * @param arrayElement 需要写入的元素在数组（可能的）中的位置，通常为 0
     * @return 如果存在相应的 dstSet 和 dstBinding，则返回创建的 'VkWriteDescriptorSet'
     */
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet, uint32_t dstBinding, uint32_t arrayElement = 0) const;

    /**
     * @brief 创建 *图像* 描述符集的写入信息，用于资源的更新
     * @param dstSet 需要写入的描述符集
     * @param dstBinding 需要写入的绑定点
     * @param pImageInfo 指定写入的图像信息
     * @param arrayElement 需要写入的元素在数组（可能的）中的位置，通常为 0
     * @return 
     */
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkDescriptorImageInfo* pImageInfo,
                                   uint32_t arrayElement = 0) const;

    /**
     * @brief 创建 *缓冲区* 描述符集的写入信息，用于资源的更新
     * @param dstSet 需要写入的描述符集
     * @param dstBinding 需要写入的绑定点
     * @param pBufferInfo 指定写入的缓冲区信息
     * @param arrayElement 需要写入的元素在数组（可能的）中的位置，通常为 0
     * @return 
     */
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkDescriptorBufferInfo* pBufferInfo,
                                   uint32_t arrayElement = 0) const;

    /**
     * @brief 创建 *缓冲区视图* 描述符集的写入信息，用于资源的更新
     * @param dstSet 需要写入的描述符集
     * @param dstBinding 需要写入的绑定点
     * @param pTexelBufferView 指定写入的缓冲区视图信息
     * @param arrayElement 需要写入的元素在数组（可能的）中的位置，通常为 0
     * @return 
     */
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkBufferView* pTexelBufferView,
                                   uint32_t arrayElement = 0) const;

#if VK_NV_ray_tracing
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkWriteDescriptorSetAccelerationStructureNV* pAccel,
                                   uint32_t arrayElement = 0) const;
#endif
#if VK_KHR_acceleration_structure
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkWriteDescriptorSetAccelerationStructureKHR* pAccel,
                                   uint32_t arrayElement = 0) const;
#endif
#if VK_EXT_inline_uniform_block
    VkWriteDescriptorSet makeWrite(VkDescriptorSet dstSet,
                                   uint32_t dstBinding,
                                   const VkWriteDescriptorSetInlineUniformBlockEXT* pInlineUniform,
                                   uint32_t arrayElement = 0) const;
#endif

    /**
     * @brief 为描述符集中所有描述符创建写入信息
     * @param dstSet 指定的描述符集
     * @param dstBinding 指定的绑定点
     * @return 特定描述符集上，特定绑定点中所有描述符资源的写入信息
     */
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding) const;
   
    /**
     * @brief 为描述符集中与 *图像* 相关的描述符创建写入信息
     * @param dstSet 指定的描述符集
     * @param dstBinding 指定的绑定点
     * @param pImageInfo 指定写入的图像信息
     * @return 特定描述符集上，特定绑定点中所有描述符资源的写入信息，并已经设置了图像的写入信息
     */
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding, const VkDescriptorImageInfo* pImageInfo) const;

    /**
     * @brief 为描述符集中与 *缓冲区* 相关的描述符创建写入信息
     * @param dstSet 指定的描述符集
     * @param dstBinding 指定的绑定点
     * @param pBufferInfo 指定写入的缓冲区信息
     * @return 特定描述符集上，特定绑定点中所有描述符资源的写入信息，并已经设置了缓冲区的写入信息
     */
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding, const VkDescriptorBufferInfo* pBufferInfo) const;

    /**
     * @brief 为描述符集中与 *缓冲区视图* 相关的描述符创建写入信息
     * @param dstSet 指定的描述符集
     * @param dstBinding 指定的绑定点
     * @param pTexelBufferView 指定写入的缓冲区视图信息
     * @return 特定描述符集上，特定绑定点中所有描述符资源的写入信息，并已经设置了缓冲区视图的写入信息
     */
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding, const VkBufferView* pTexelBufferView) const;

#if VK_NV_ray_tracing
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet,
                                        uint32_t dstBinding,
                                        const VkWriteDescriptorSetAccelerationStructureNV* pAccel) const;
#endif
#if VK_KHR_acceleration_structure
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet,
                                        uint32_t dstBinding,
                                        const VkWriteDescriptorSetAccelerationStructureKHR* pAccel) const;
#endif
#if VK_EXT_inline_uniform_block
    VkWriteDescriptorSet makeWriteArray(VkDescriptorSet dstSet,
                                        uint32_t dstBinding,
                                        const VkWriteDescriptorSetInlineUniformBlockEXT* pInline) const;
#endif

private:
    std::vector<VkDescriptorSetLayoutBinding> bindings_;
};

} // yu::vk