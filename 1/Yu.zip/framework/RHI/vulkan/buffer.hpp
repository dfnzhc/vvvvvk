﻿//
// Created by 秋鱼 on 2022/6/29.
//

#pragma once

#include <vulkan/vulkan.h>

#define USE_VMA

#ifdef USE_VMA
#include <vk_mem_alloc.h>
#endif

namespace yu::vk {

/**
* @brief 对 vulkan 缓冲区一定程度的封装
*/
struct Buffer
{
    VkDevice device{};

    /** @brief Vulkan 的缓冲区对象 */
    VkBuffer               buffer = VK_NULL_HANDLE;
    /** @brief 缓冲区对象掌管的内存 */
    VkDeviceMemory         memory = VK_NULL_HANDLE;
    /** @brief 缓冲区对应的描述符信息 */
    VkDescriptorBufferInfo descriptor{};

    /** @brief 缓冲区大小 */
    VkDeviceSize size      = 0;
    /** @brief 缓冲区的对齐 */
    VkDeviceSize alignment = 0;

    /** @brief 指向缓冲区对象所映射的地址 */
    void* mapped = nullptr;

    /** @brief 在创建缓冲区的时候设置其用途 */
    VkBufferUsageFlags    usageFlags{};
    /** @brief 在创建缓冲区的时候设置它的属性标志 */
    VkMemoryPropertyFlags memoryPropertyFlags{};

    VkResult map(VkDeviceSize size = VK_WHOLE_SIZE, VkDeviceSize offset = 0);
    void unmap();

    VkResult bind(VkDeviceSize offset = 0);
    void setupDescriptor(VkDeviceSize size = VK_WHOLE_SIZE, VkDeviceSize offset = 0);
    void copyTo(void* data, VkDeviceSize size);
    VkResult flush(VkDeviceSize size = VK_WHOLE_SIZE, VkDeviceSize offset = 0);
    VkResult invalidate(VkDeviceSize size = VK_WHOLE_SIZE, VkDeviceSize offset = 0);

    [[nodiscard]] VkDeviceAddress getDeviceAddress() const;

    void destroy();
};

/**
 * @brief 使用 VMA 创建 vulkan 缓冲区
 * @param usageFlags 缓冲区的用途
 * @param vmaUsageFlags vma 指示用途
 * @param size 缓冲区的大小
 * @param pBuffer 创建的缓冲区对象
 * @param pAllocation 创建的缓冲区 vma 分配
 * @param pData 如果不为空，那么创建的缓冲区映射到该指针
 * @param name 缓冲区的创建名称
 * @param allocationFlags 指示 vma 分配的创建 flag
 * @return 创建的结果，由用户决定创建与否的行为
 */
VkResult CreateBufferVMA(VkBufferUsageFlags usageFlags,
                         VkDeviceSize size,
                         VmaAllocator vmaAllocator,
                         VmaMemoryUsage vmaUsageFlags,
                         VkBuffer* pBuffer,
                         VmaAllocation* pAllocation,
                         void** pData = nullptr,
                         std::string_view name = "",
                         VmaAllocationCreateFlags allocationFlags = VMA_ALLOCATION_CREATE_USER_DATA_COPY_STRING_BIT);

/**
 * @brief 创建 vulkan 缓冲区
 * @param usageFlags 缓冲区的用途
 * @param size 缓冲区的大小
 * @param pBuffer 创建的缓冲区对象
 * @param memory 创建的缓冲区的分配
 * @param pData 如果不为空，那么创建的缓冲区映射到该指针
 * @return 创建的结果，由用户决定创建与否的行为
 */
VkResult CreateBuffer(VkDevice device,
                      VkPhysicalDevice physicalDevice,
                      VkBufferUsageFlags usageFlags,
                      VkMemoryPropertyFlags memoryPropertyFlags,
                      VkDeviceSize size,
                      VkBuffer* pBuffer,
                      VkDeviceMemory* memory,
                      bool bCopyData,
                      void** pData);

/**
 * @brief 创建工具类 yu::vk::Buffer
 * @param usageFlags 指示缓冲区的用途
 * @param memoryPropertyFlags 指示创建缓冲区的属性
 * @param size 缓冲区的大小
 * @param pBuffer 创建的缓冲区对象
 * @param pData 如果不为空，那么创建的缓冲区映射到该指针
 * @return 创建的结果，由用户决定创建与否的行为
 */
VkResult CreateBuffer(VkDevice device,
                      VkPhysicalDevice physicalDevice,
                      VkBufferUsageFlags usageFlags,
                      VkMemoryPropertyFlags memoryPropertyFlags,
                      VkDeviceSize size,
                      Buffer* pBuffer,
                      void* pData = nullptr);

} // yu::vk