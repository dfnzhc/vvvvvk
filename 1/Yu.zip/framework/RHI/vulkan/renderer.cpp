﻿//
// Created by 秋鱼 on 2022/9/2.
//

#include <imgui.h>
#include "renderer.hpp"

namespace yu::vk {

Renderer::~Renderer()
{
    imGui_->destroy();
    gpu_timer_.destroy();

    vkDestroyPipelineCache(context_->getDevice(), pipeline_cache_, nullptr);

    res_alloc_->destroy();
    frame_command_pool_->destroy();
    command_pool_->destroy();
}

void Renderer::create(const Context* context, const MouseTracker* mouseTracker, SwapChain* swapChain)
{
    context_       = context;
    mouse_tracker_ = mouseTracker;
    swap_chain_    = swapChain;

    // 命令列表
    command_pool_ = std::make_unique<CommandPool>();
    command_pool_->create(context->getDevice(), context->getGCTQueue());
    
    // 帧命令列表
    frame_command_pool_ = std::make_unique<FrameCommandPool>();
    frame_command_pool_->create(context->getDevice(), context->getGCTQueue(), swapChain->getImageCount(), 8);

    // 资源分配器
    res_alloc_ = std::make_unique<ResourceAllocator>();
    res_alloc_->create(*context, *swapChain);

    // 创建 UI
    imGui_ = std::make_unique<ImGUI>();

    // 创建 GPU timer
    gpu_timer_.create(context->getDevice(), context->getPhysicalDevice(), swapChain->getImageCount());

    // 创建流水线 cache
    VkPipelineCacheCreateInfo pipelineCacheInfo{VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO};
    VK_CHECK(vkCreatePipelineCache(context->getDevice(), &pipelineCacheInfo, nullptr, &pipeline_cache_));
}

void Renderer::resize(uint32_t width, uint32_t height)
{
    width_  = width;
    height_ = height;

    viewport_ = VkViewport{0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f, 1.0f};

    scissor_ = VkRect2D{{0, 0}, {width, height}};

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize             = ImVec2(static_cast<float>(width), static_cast<float>(height));
    io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
}

void Renderer::createUI(GLFWwindow* window)
{
    imGui_->create(context_->getInstance(),
                   context_->getDevice(),
                   context_->getPhysicalDevice(),
                   context_->getGCTQueue(),
                   swap_chain_->getRenderPass(),
                   pipeline_cache_,
                   window, command_pool_.get());
}

} // yu::vk