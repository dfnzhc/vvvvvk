﻿//
// Created by 秋鱼 on 2022/6/8.
//

#pragma once

#include <vulkan/vulkan_core.h>
namespace yu::vk {

/**
 * @brief 用于创建、提交、回收命令缓冲区
 */
class CommandPool
{
public:
    CommandPool() = default;

    CommandPool(CommandPool&&) = delete;
    CommandPool(const CommandPool&) = delete;
    CommandPool& operator=(CommandPool&&) = delete;
    CommandPool& operator=(const CommandPool&) = delete;

    void create(VkDevice device, uint32_t queueFamilyIndex);
    void destroy();

    // 创建命令缓冲区
    VkCommandBuffer createCommandBuffer(VkCommandBufferLevel level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
                                        bool begin = true,
                                        VkCommandBufferUsageFlags flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT,
                                        const VkCommandBufferInheritanceInfo* pInheritanceInfo = nullptr);

    // 销毁命令缓冲区
    void destroy(size_t count, const VkCommandBuffer* cmds);
    void destroy(const std::vector<VkCommandBuffer>& cmds) { destroy(cmds.size(), cmds.data()); }
    void destroy(VkCommandBuffer cmd) { destroy(1, &cmd); }

    // 结束命令缓冲区的记录，并提交到队列。
    // 如果 fence 不为 VK_NULL_HANDLE，那么当命令缓冲区被执行完毕，fence 将为被唤醒
    // submit 操作不会摧毁命令缓冲区
    void submit(size_t count, const VkCommandBuffer* cmds, VkQueue queue, VkFence fence = VK_NULL_HANDLE);
    void submit(size_t count, const VkCommandBuffer* cmds, VkFence fence = VK_NULL_HANDLE);
    void submit(const std::vector<VkCommandBuffer>& cmds, VkFence fence = VK_NULL_HANDLE);

    // 提交命令缓冲区，并等待其结束执行
    void submitAndWait(size_t count, const VkCommandBuffer* cmds, VkQueue queue);
    void submitAndWait(const std::vector<VkCommandBuffer>& cmds, VkQueue queue)
    {
        submitAndWait(cmds.size(), cmds.data(), queue);
    }
    void submitAndWait(VkCommandBuffer cmd, VkQueue queue) { submitAndWait(1, &cmd, queue); }

    // 使用默认的 queue
    void submitAndWait(size_t count, const VkCommandBuffer* cmds) { submitAndWait(count, cmds, queue_); }
    void submitAndWait(const std::vector<VkCommandBuffer>& cmds) { submitAndWait(cmds.size(), cmds.data(), queue_); }
    void submitAndWait(VkCommandBuffer cmd) { submitAndWait(1, &cmd, queue_); }
    
private:
    VkDevice device_{};
    VkQueue  queue_{};

    /** @brief 这个命令池用于创建命令缓冲区 */
    VkCommandPool command_pool_{};
};

/**
 * @brief 用于创建命令缓冲区，其拥有一系列的 ‘帧命令缓冲区’，在每一帧循环使用
 */
class FrameCommandPool
{
public:
    FrameCommandPool() = default;

    FrameCommandPool(FrameCommandPool&&) = delete;
    FrameCommandPool(const FrameCommandPool&) = delete;
    FrameCommandPool& operator=(FrameCommandPool&&) = delete;
    FrameCommandPool& operator=(const FrameCommandPool&) = delete;

    void create(VkDevice device, uint32_t queueFamilyIndex, uint32_t numberOfFrames, uint32_t commandBufferPerFrame);
    void destroy();

    void beginFrame();
    VkCommandBuffer getFrameCommandBuffer();
    
    VkResult submitSingleCommandBuffer(VkCommandBuffer cmdBuffer);

private:
    VkDevice device_{};
    VkQueue  queue_{};

    uint32_t frame_index_{};
    uint32_t number_of_frames_{};
    uint32_t command_buffer_per_frame_{};

    struct CommandBufferPerFrame
    {
        VkCommandPool                commandPool{};
        std::vector<VkCommandBuffer> commandBuffers{};
        uint32_t                     numberOfUsed{};
    };

    std::vector<CommandBufferPerFrame> frame_command_buffers{};
    CommandBufferPerFrame* current_frame_buffer = nullptr;
};


} // namespace yu::vk