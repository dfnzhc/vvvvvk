﻿//
// Created by 秋鱼 on 2022/6/6.
//

#pragma once

#include "common/common.hpp"
#include "vulkan_utils.hpp"
#include <vulkan/vulkan_core.h>

namespace yu::vk {

// 设置变量的辅助方法
template<class T, class U>
void SetValue(T& target, const U& val)
{
    target = static_cast<T>(val);
}

/**
 * @brief 用来记录流水线的状态
 */
struct GraphicsPipelineState
{
    /**
     * @brief 默认的流水线设置：triangle list topology, depth test enabled, dynamic viewport and scissor, one render target, blending disabled
     */
    GraphicsPipelineState()
    {
        rasterizationState.flags                   = {};
        rasterizationState.depthClampEnable        = {};
        rasterizationState.rasterizerDiscardEnable = {};
        SetValue(rasterizationState.polygonMode, VK_POLYGON_MODE_FILL);
        SetValue(rasterizationState.cullMode, VK_CULL_MODE_BACK_BIT);
        SetValue(rasterizationState.frontFace, VK_FRONT_FACE_COUNTER_CLOCKWISE);

        rasterizationState.depthBiasEnable         = {};
        rasterizationState.depthBiasConstantFactor = {};
        rasterizationState.depthBiasClamp          = {};
        rasterizationState.depthBiasSlopeFactor    = {};
        rasterizationState.lineWidth               = 1.f;

        inputAssemblyState.flags = {};
        SetValue(inputAssemblyState.topology, VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST);
        inputAssemblyState.primitiveRestartEnable = {};

        colorBlendState.flags         = {};
        colorBlendState.logicOpEnable = {};
        SetValue(colorBlendState.logicOp, VK_LOGIC_OP_CLEAR);
        colorBlendState.attachmentCount = {};
        colorBlendState.pAttachments    = {};
        for (float& blendConstant : colorBlendState.blendConstants) {
            blendConstant = 0.f;
        }

        dynamicState.flags             = {};
        dynamicState.dynamicStateCount = {};
        dynamicState.pDynamicStates    = {};

        vertexInputState.flags                           = {};
        vertexInputState.vertexBindingDescriptionCount   = {};
        vertexInputState.pVertexBindingDescriptions      = {};
        vertexInputState.vertexAttributeDescriptionCount = {};
        vertexInputState.pVertexAttributeDescriptions    = {};

        viewportState.flags         = {};
        viewportState.viewportCount = {};
        viewportState.pViewports    = {};
        viewportState.scissorCount  = {};
        viewportState.pScissors     = {};

        depthStencilState.flags            = {};
        depthStencilState.depthTestEnable  = VK_TRUE;
        depthStencilState.depthWriteEnable = VK_TRUE;
        SetValue(depthStencilState.depthCompareOp, VK_COMPARE_OP_LESS_OR_EQUAL);
        depthStencilState.depthBoundsTestEnable = {};
        depthStencilState.stencilTestEnable     = {};
        SetValue(depthStencilState.front, VkStencilOpState());
        SetValue(depthStencilState.back, VkStencilOpState());
        depthStencilState.minDepthBounds = {};
        depthStencilState.maxDepthBounds = {};
    }

    GraphicsPipelineState(const GraphicsPipelineState& src) = default;

    // 使用设置的状态更新流水线设置
    void update()
    {
        colorBlendState.attachmentCount = (uint32_t) blendAttachmentStates.size();
        colorBlendState.pAttachments    = blendAttachmentStates.data();

        dynamicState.dynamicStateCount = (uint32_t) dynamicStateEnables.size();
        dynamicState.pDynamicStates    = dynamicStateEnables.data();

        vertexInputState.vertexAttributeDescriptionCount = static_cast<uint32_t>(attributeDescriptions.size());
        vertexInputState.vertexBindingDescriptionCount   = static_cast<uint32_t>(bindingDescriptions.size());
        vertexInputState.pVertexBindingDescriptions      = bindingDescriptions.data();
        vertexInputState.pVertexAttributeDescriptions    = attributeDescriptions.data();

        if (viewports.empty()) {
            viewportState.viewportCount = 1;
            viewportState.pViewports    = nullptr;
        } else {
            viewportState.viewportCount = (uint32_t) viewports.size();
            viewportState.pViewports    = viewports.data();
        }

        if (scissors.empty()) {
            viewportState.scissorCount = 1;
            viewportState.pScissors    = nullptr;
        } else {
            viewportState.scissorCount = (uint32_t) scissors.size();
            viewportState.pScissors    = scissors.data();
        }
    }

    static inline VkPipelineColorBlendAttachmentState makePipelineColorBlendAttachmentState(
        VkColorComponentFlags colorWriteMask_ = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT
            | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT,
        VkBool32 blendEnable_ = VK_FALSE,
        VkBlendFactor srcColorBlendFactor_ = VK_BLEND_FACTOR_ZERO,
        VkBlendFactor dstColorBlendFactor_ = VK_BLEND_FACTOR_ZERO,
        VkBlendOp colorBlendOp_ = VK_BLEND_OP_ADD,
        VkBlendFactor srcAlphaBlendFactor_ = VK_BLEND_FACTOR_ZERO,
        VkBlendFactor dstAlphaBlendFactor_ = VK_BLEND_FACTOR_ZERO,
        VkBlendOp alphaBlendOp_ = VK_BLEND_OP_ADD)
    {
        VkPipelineColorBlendAttachmentState res;

        res.blendEnable         = blendEnable_;
        res.srcColorBlendFactor = srcColorBlendFactor_;
        res.dstColorBlendFactor = dstColorBlendFactor_;
        res.colorBlendOp        = colorBlendOp_;
        res.srcAlphaBlendFactor = srcAlphaBlendFactor_;
        res.dstAlphaBlendFactor = dstAlphaBlendFactor_;
        res.alphaBlendOp        = alphaBlendOp_;
        res.colorWriteMask      = colorWriteMask_;
        return res;
    }

    static inline VkVertexInputBindingDescription makeVertexInputBinding(uint32_t binding,
                                                                         uint32_t stride,
                                                                         VkVertexInputRate rate = VK_VERTEX_INPUT_RATE_VERTEX)
    {
        VkVertexInputBindingDescription vertexBinding;
        vertexBinding.binding   = binding;
        vertexBinding.inputRate = rate;
        vertexBinding.stride    = stride;
        return vertexBinding;
    }

    static inline VkVertexInputAttributeDescription makeVertexInputAttribute(uint32_t location, uint32_t binding, VkFormat format, uint32_t offset)
    {
        VkVertexInputAttributeDescription attrib;
        attrib.binding  = binding;
        attrib.location = location;
        attrib.format   = format;
        attrib.offset   = offset;
        return attrib;
    }

    void clearBlendAttachmentStates() { blendAttachmentStates.clear(); }
    void setBlendAttachmentCount(uint32_t attachmentCount) { blendAttachmentStates.resize(attachmentCount); }

    void setBlendAttachmentState(uint32_t attachment, const VkPipelineColorBlendAttachmentState& blendState)
    {
        assert(attachment < blendAttachmentStates.size());
        if (attachment <= blendAttachmentStates.size()) {
            blendAttachmentStates[attachment] = blendState;
        }
    }

    uint32_t addBlendAttachmentState(const VkPipelineColorBlendAttachmentState& blendState)
    {
        blendAttachmentStates.push_back(blendState);
        return (uint32_t) (blendAttachmentStates.size() - 1);
    }

    void clearDynamicStateEnables() { dynamicStateEnables.clear(); }
    void setDynamicStateEnablesCount(uint32_t dynamicStateCount) { dynamicStateEnables.resize(dynamicStateCount); }

    void setDynamicStateEnable(uint32_t state, VkDynamicState dynamicState)
    {
        assert(state < dynamicStateEnables.size());
        if (state <= dynamicStateEnables.size()) {
            dynamicStateEnables[state] = dynamicState;
        }
    }

    uint32_t addDynamicStateEnable(VkDynamicState dynamicState)
    {
        dynamicStateEnables.push_back(dynamicState);
        return (uint32_t) (dynamicStateEnables.size() - 1);
    }

    void clearBindingDescriptions() { bindingDescriptions.clear(); }
    void setBindingDescriptionsCount(uint32_t bindingDescriptionCount)
    {
        bindingDescriptions.resize(bindingDescriptionCount);
    }
    void setBindingDescription(uint32_t binding, VkVertexInputBindingDescription bindingDescription)
    {
        assert(binding < bindingDescriptions.size());
        if (binding <= bindingDescriptions.size()) {
            bindingDescriptions[binding] = bindingDescription;
        }
    }

    uint32_t addBindingDescription(const VkVertexInputBindingDescription& bindingDescription)
    {
        bindingDescriptions.push_back(bindingDescription);
        return (uint32_t) (bindingDescriptions.size() - 1);
    }

    void addBindingDescriptions(const std::vector<VkVertexInputBindingDescription>& bindingDescriptions_)
    {
        bindingDescriptions.insert(bindingDescriptions.end(), bindingDescriptions_.begin(), bindingDescriptions_.end());
    }

    void clearAttributeDescriptions() { attributeDescriptions.clear(); }
    void setAttributeDescriptionsCount(uint32_t attributeDescriptionCount)
    {
        attributeDescriptions.resize(attributeDescriptionCount);
    }

    void setAttributeDescription(uint32_t attribute, const VkVertexInputAttributeDescription& attributeDescription)
    {
        assert(attribute < attributeDescriptions.size());
        if (attribute <= attributeDescriptions.size()) {
            attributeDescriptions[attribute] = attributeDescription;
        }
    }

    uint32_t addAttributeDescription(const VkVertexInputAttributeDescription& attributeDescription)
    {
        attributeDescriptions.push_back(attributeDescription);
        return (uint32_t) (attributeDescriptions.size() - 1);
    }

    void addAttributeDescriptions(const std::vector<VkVertexInputAttributeDescription>& attributeDescriptions_)
    {
        attributeDescriptions.insert(attributeDescriptions.end(), attributeDescriptions_.begin(), attributeDescriptions_.end());
    }

    void clearViewports() { viewports.clear(); }
    void setViewportsCount(uint32_t viewportCount) { viewports.resize(viewportCount); }
    void setViewport(uint32_t attribute, VkViewport viewport)
    {
        assert(attribute < viewports.size());
        if (attribute <= viewports.size()) {
            viewports[attribute] = viewport;
        }
    }
    uint32_t addViewport(VkViewport viewport)
    {
        viewports.push_back(viewport);
        return (uint32_t) (viewports.size() - 1);
    }

    void clearScissors() { scissors.clear(); }
    void setScissorsCount(uint32_t scissorCount) { scissors.resize(scissorCount); }
    void setScissor(uint32_t attribute, VkRect2D scissor)
    {
        assert(attribute < scissors.size());
        if (attribute <= scissors.size()) {
            scissors[attribute] = scissor;
        }
    }
    uint32_t addScissor(VkRect2D scissor)
    {
        scissors.push_back(scissor);
        return (uint32_t) (scissors.size() - 1);
    }

    void setDepthTest(VkBool32 bState) { depthStencilState.depthTestEnable = bState; }
    void setDepthWrite(VkBool32 bState) { depthStencilState.depthWriteEnable = bState; }
    void setCullMode(VkCullModeFlagBits cullMode) { SetValue(rasterizationState.cullMode, cullMode); }

    VkPipelineInputAssemblyStateCreateInfo inputAssemblyState{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    VkPipelineRasterizationStateCreateInfo rasterizationState{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    VkPipelineMultisampleStateCreateInfo   multisampleState{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    VkPipelineDepthStencilStateCreateInfo  depthStencilState{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    VkPipelineViewportStateCreateInfo      viewportState{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    VkPipelineDynamicStateCreateInfo       dynamicState{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    VkPipelineColorBlendStateCreateInfo    colorBlendState{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    VkPipelineVertexInputStateCreateInfo   vertexInputState{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};

private:
    std::vector<VkPipelineColorBlendAttachmentState> blendAttachmentStates{makePipelineColorBlendAttachmentState()};
    std::vector<VkDynamicState>                      dynamicStateEnables = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};

    std::vector<VkVertexInputBindingDescription>   bindingDescriptions{};
    std::vector<VkVertexInputAttributeDescription> attributeDescriptions{};

    std::vector<VkViewport> viewports{};
    std::vector<VkRect2D>   scissors{};

};

/**
 * @brief 用来生成渲染流水线
 */
struct GraphicsPipelineGenerator
{
public:
    explicit GraphicsPipelineGenerator(GraphicsPipelineState& pipelineState_)
        : pipelineState(pipelineState_)
    {
        create();
    }

    GraphicsPipelineGenerator(const GraphicsPipelineGenerator& src)
        : createInfo(src.createInfo), device(src.device), pipelineCache(src.pipelineCache), pipelineState(src.pipelineState)
    {
        create();
    }

    GraphicsPipelineGenerator(VkDevice device_, const VkPipelineLayout& layout, const VkRenderPass& renderPass, GraphicsPipelineState& pipelineState_)
        : device(device_), pipelineState(pipelineState_)
    {
        createInfo.layout     = layout;
        createInfo.renderPass = renderPass;
        create();
    }

    GraphicsPipelineGenerator(VkDevice device_,
                              const VkPipelineLayout& layout,
                              const VkPipelineRenderingCreateInfo& pipelineRenderingCreateInfo,
                              GraphicsPipelineState& pipelineState_)
        : device(device_), pipelineState(pipelineState_)
    {
        createInfo.layout = layout;
        setPipelineRenderingCreateInfo(pipelineRenderingCreateInfo);
        create();
    }

    const GraphicsPipelineGenerator& operator=(const GraphicsPipelineGenerator& src)
    {
        device        = src.device;
        pipelineState = src.pipelineState;
        createInfo    = src.createInfo;
        pipelineCache = src.pipelineCache;

        create();
        return *this;
    }

    ~GraphicsPipelineGenerator() { destroyShaderModules(); }

    void setDevice(VkDevice device_) { device = device_; }

    void setRenderPass(VkRenderPass renderPass)
    {
        createInfo.renderPass = renderPass;
        createInfo.pNext      = nullptr;
    }

    void setPipelineRenderingCreateInfo(const VkPipelineRenderingCreateInfo& pipelineRenderingCreateInfo)
    {
        // 深度拷贝创建信息
        assert(pipelineRenderingCreateInfo.sType == VK_STRUCTURE_TYPE_PIPELINE_RENDERING_CREATE_INFO);
        assert(pipelineRenderingCreateInfo.pNext == nullptr);
        dynamicRenderingInfo = pipelineRenderingCreateInfo;
        if (dynamicRenderingInfo.colorAttachmentCount != 0) {
            dynamicRenderingColorFormats.assign(dynamicRenderingInfo.pColorAttachmentFormats,
                                                dynamicRenderingInfo.pColorAttachmentFormats + dynamicRenderingInfo.colorAttachmentCount);
            dynamicRenderingInfo.pColorAttachmentFormats = dynamicRenderingColorFormats.data();
        }

        // 设置 VkGraphicsPipelineCreateInfo 的 pNext
        createInfo.pNext = &dynamicRenderingInfo;
    }

    void setLayout(VkPipelineLayout layout) { createInfo.layout = layout; }

    // 设置流水线的着色器
    VkPipelineShaderStageCreateInfo& addShader(std::string_view fileName,
                                               VkShaderStageFlagBits stage,
                                               const char* entryPoint = "main")
    {
        auto shaderModule = LoadShader(GetSpvShaderFile(fileName.data()), device);
        temporaryModules.push_back(shaderModule);

        return addShader(shaderModule, stage, entryPoint);
    }

    VkPipelineShaderStageCreateInfo& addShader(VkShaderModule shaderModule,
                                               VkShaderStageFlagBits stage,
                                               const char* entryPoint = "main")
    {
        VkPipelineShaderStageCreateInfo shaderStage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
        shaderStage.stage  = (VkShaderStageFlagBits) stage;
        shaderStage.module = shaderModule;
        shaderStage.pName  = entryPoint;

        shaderStages.push_back(shaderStage);
        return shaderStages.back();
    }

    void clearShaders()
    {
        shaderStages.clear();
        destroyShaderModules();
    }

    [[nodiscard]] VkShaderModule getShaderModule(size_t index) const
    {
        if (index < shaderStages.size())
            return shaderStages[index].module;
        return VK_NULL_HANDLE;
    }

    VkPipeline createPipeline(const VkPipelineCache& cache)
    {
        update();
        VkPipeline pipeline;
        vkCreateGraphicsPipelines(device, cache, 1, (VkGraphicsPipelineCreateInfo*) &createInfo, nullptr, &pipeline);
        return pipeline;
    }

    VkPipeline createPipeline() { return createPipeline(pipelineCache); }

    void destroyShaderModules()
    {
        for (const auto& shaderModule : temporaryModules) {
            vkDestroyShaderModule(device, shaderModule, nullptr);
        }
        temporaryModules.clear();
    }
    void update()
    {
        createInfo.stageCount = static_cast<uint32_t>(shaderStages.size());
        createInfo.pStages    = shaderStages.data();
        pipelineState.update();
    }

    VkGraphicsPipelineCreateInfo createInfo{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};

private:
    VkDevice        device{};
    VkPipelineCache pipelineCache{};

    std::vector<VkPipelineShaderStageCreateInfo> shaderStages{};
    std::vector<VkShaderModule>                  temporaryModules{};
    std::vector<VkFormat>                        dynamicRenderingColorFormats{};
    GraphicsPipelineState& pipelineState;
    VkPipelineRenderingCreateInfo dynamicRenderingInfo{};

    void create()
    {
        SetValue(pipelineState.multisampleState.rasterizationSamples, VK_SAMPLE_COUNT_1_BIT);
        createInfo.pRasterizationState = &pipelineState.rasterizationState;
        createInfo.pInputAssemblyState = &pipelineState.inputAssemblyState;
        createInfo.pColorBlendState    = &pipelineState.colorBlendState;
        createInfo.pMultisampleState   = &pipelineState.multisampleState;
        createInfo.pViewportState      = &pipelineState.viewportState;
        createInfo.pDepthStencilState  = &pipelineState.depthStencilState;
        createInfo.pDynamicState       = &pipelineState.dynamicState;
        createInfo.pVertexInputState   = &pipelineState.vertexInputState;
    }
};

/**
 * @brief 将 State 和 Generator 合并，通过继承直接使用上两个类的函数，而不用通过成员变量访问
 */
struct GraphicsPipelineGeneratorCombined : public GraphicsPipelineState, public GraphicsPipelineGenerator
{
    GraphicsPipelineGeneratorCombined(VkDevice device_, const VkPipelineLayout& layout, const VkRenderPass& renderPass)
        : GraphicsPipelineState(), GraphicsPipelineGenerator(device_, layout, renderPass, *this)
    {
    }
};

} // yu::vk