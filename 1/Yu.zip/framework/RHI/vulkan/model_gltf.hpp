﻿//
// Created by 秋鱼 on 2022/9/7.
//

#pragma once

#include "common/gltf_loader.hpp"
#include "resource_allocator.hpp"

#include "../../../data/shaders/gltfDefines.h"
#include "descriptor_sets.hpp"

namespace yu::vk {

struct ModelGltf
{
    void load(std::string_view filename,
              ResourceAllocator* resourceAllocator,
              GltfAttributes loadAttributes = GltfAttributes::Normal | GltfAttributes::Texcoord_0);

    void destroy();

    /**
     * @brief 设置描述符
     */
    void setDescriptorSet(VkDevice device,
                          ResourceAllocator* resourceAllocator,
                          DescriptorSetBindings* descSetBinds,
                          VkDescriptorSet* pDescSet);

    /**
     * @brief 根据加载时指定的顶点属性生成布局
     */
    [[nodiscard]] std::vector<VkVertexInputAttributeDescription> getVertexInputDescriptions(uint32_t startBinding = 0);

    /**
     * @brief 根据加载时指定的顶点属性生成描述符的绑定信息
     */
    [[nodiscard]] std::vector<VkVertexInputBindingDescription> getBindingDescriptions(uint32_t startBinding = 0);
    
    /**
     * @brief 记录 gltf 场景的绘制命令
     */
    void draw(VkCommandBuffer cmdBuffer, VkPipelineLayout pipelineLayout = VK_NULL_HANDLE, PushConstantRasterGLTF* pConstant = nullptr);

    /** @brief 顶点缓冲区的描述符信息 */
    VkDescriptorBufferInfo positionBufferInfo{};

    /** @brief 索引缓冲区的描述符信息 */
    VkDescriptorBufferInfo indexBufferInfo{};

    /** @brief 法线缓冲区的描述符信息 */
    VkDescriptorBufferInfo normalBufferInfo{};
    
    /** @brief 切线缓冲区的描述符信息 */
    VkDescriptorBufferInfo tangentBufferInfo{};
    
    /** @brief uv0 缓冲区的描述符信息 */
    VkDescriptorBufferInfo uv0BufferInfo{};
    
    /** @brief uv1 缓冲区的描述符信息 */
    VkDescriptorBufferInfo uv1BufferInfo{};

    /** @brief 顶点颜色缓冲区的描述符信息 */
    VkDescriptorBufferInfo colorBufferInfo{};
    
    /** @brief 模型的描述符信息缓冲区 */
    Buffer descBuffer{};

    /** @brief 材质的缓冲区 */
    Buffer matBuffer{};

    /** @brief 模型的图片 */
    GltfScene gltfScene;

    /** @brief 模型的图片 */
    std::vector<Texture2D> textures{};

    /** @brief 加载时指定的顶点属性，用来生成顶点布局 */
    GltfAttributes loadedAttributes;
};

} // yu::vk