﻿//
// Created by 秋鱼 on 2022/8/21.
//

#include "texture.hpp"

#include "upload_heap.hpp"
#include "vulkan_utils.hpp"
#include "error.hpp"

#include <San/utils/utils.hpp>

namespace yu::vk {

VkAccessFlags AccessFlagsForImageLayout(VkImageLayout layout)
{
    switch (layout) {
        case VK_IMAGE_LAYOUT_PREINITIALIZED:
            return VK_ACCESS_HOST_WRITE_BIT;
        case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
            return VK_ACCESS_TRANSFER_WRITE_BIT;
        case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
            return VK_ACCESS_TRANSFER_READ_BIT;
        case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
            return VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
            return VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
            return VK_ACCESS_SHADER_READ_BIT;
        default:
            return VkAccessFlags();
    }
}

VkPipelineStageFlags PipelineStageForLayout(VkImageLayout layout)
{
    switch (layout) {
        case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
        case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
            return VK_PIPELINE_STAGE_TRANSFER_BIT;
        case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
            return VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
            return VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;  // We do this to allow queue other than graphic
            // return VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
        case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
            return VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;  // We do this to allow queue other than graphic
            // return VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        case VK_IMAGE_LAYOUT_PREINITIALIZED:
            return VK_PIPELINE_STAGE_HOST_BIT;
        case VK_IMAGE_LAYOUT_UNDEFINED:
            return VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
        default:
            return VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
    }
}

void CmdBarrierImageLayout(VkCommandBuffer cmdbuffer,
                           VkImage image,
                           VkImageLayout oldImageLayout,
                           VkImageLayout newImageLayout,
                           const VkImageSubresourceRange& subresourceRange)
{
    // Create an image barrier to change the layout
    VkImageMemoryBarrier imageMemoryBarrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    imageMemoryBarrier.oldLayout           = oldImageLayout;
    imageMemoryBarrier.newLayout           = newImageLayout;
    imageMemoryBarrier.image               = image;
    imageMemoryBarrier.subresourceRange    = subresourceRange;
    imageMemoryBarrier.srcAccessMask       = AccessFlagsForImageLayout(oldImageLayout);
    imageMemoryBarrier.dstAccessMask       = AccessFlagsForImageLayout(newImageLayout);
    // Fix for a validation issue - should be needed when VkImage sharing mode is VK_SHARING_MODE_EXCLUSIVE
    // and the values of srcQueueFamilyIndex and dstQueueFamilyIndex are equal, no ownership transfer is performed,
    // and the barrier operates as if they were both set to VK_QUEUE_FAMILY_IGNORED.
    imageMemoryBarrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    imageMemoryBarrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    VkPipelineStageFlags srcStageMask  = PipelineStageForLayout(oldImageLayout);
    VkPipelineStageFlags destStageMask = PipelineStageForLayout(newImageLayout);
    vkCmdPipelineBarrier(cmdbuffer, srcStageMask, destStageMask, 0, 0, nullptr, 0, nullptr, 1, &imageMemoryBarrier);
}

void CmdBarrierImageLayout(VkCommandBuffer cmdbuffer,
                           VkImage image,
                           VkImageLayout oldImageLayout,
                           VkImageLayout newImageLayout,
                           VkImageAspectFlags aspectMask)
{
    VkImageSubresourceRange subresourceRange;
    subresourceRange.aspectMask     = aspectMask;
    subresourceRange.levelCount     = VK_REMAINING_MIP_LEVELS;
    subresourceRange.layerCount     = VK_REMAINING_ARRAY_LAYERS;
    subresourceRange.baseMipLevel   = 0;
    subresourceRange.baseArrayLayer = 0;
    CmdBarrierImageLayout(cmdbuffer, image, oldImageLayout, newImageLayout, subresourceRange);
}

// 创建一个图像内存屏障，用于改变图像的布局，并将其放入一个活动的命令缓冲区
VkImageMemoryBarrier SetImageLayout(VkImageLayout oldImageLayout,
                                    VkImageLayout newImageLayout)
{
    // Create an image barrier object
    VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    barrier.oldLayout = oldImageLayout;
    barrier.newLayout = newImageLayout;

    // Source layouts (old)
    // 源访问掩码控制在旧布局上必须完成的动作，然后才会过渡到新布局上
    switch (oldImageLayout) {
        case VK_IMAGE_LAYOUT_UNDEFINED:
            // 图像布局是未定义的（或不重要）
            // 只在初始布局时有效
            // 不需要标志，只是为了完整地列出
            barrier.srcAccessMask = 0;
            break;

        case VK_IMAGE_LAYOUT_PREINITIALIZED:
            // 图像已被预初始化
            // 只对线性图像的初始布局有效，保留了内存内容
            // 确保主机写入已经完成
            barrier.srcAccessMask = VK_ACCESS_HOST_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
            // 图像是一个颜色附件
            // 确保对颜色缓冲区的任何写操作都已完成
            barrier.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
            // 图像是一个深度/模板附件
            // 确保对深度/模板缓冲区的任何写入都已完成
            barrier.srcAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
            // 图像是一个传输源
            // 确保从图像中的任何读取都已完成
            barrier.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
            break;

        case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
            // 图像是一个传输目的地
            // 确保对图像的任何写操作都已完成
            barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
            // 图像被一个着色器读取
            // 确保所有从图像中读取的着色器都已完成
            barrier.srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
            break;
        default:
            // Other source layouts aren't handled (yet)
            break;
    }

    // 目标布局（新）
    // 目标访问掩码控制新图像布局的依赖性
    switch (newImageLayout) {
        case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
            // 图像将被用作传输目的地
            // 确保对图像的任何写入都已完成
            barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
            // 图像将被用作传输源
            // 确保从图像中的任何读取都已完成
            barrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
            break;

        case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
            // 图像将被用作颜色附件
            // 确保对颜色缓冲区的任何写入都已完成
            barrier.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
            // 图像布局将被用作深度/模板附件
            // 确保对深度/模板缓冲区的任何写入都已完成
            barrier.dstAccessMask =
                barrier.dstAccessMask | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
            break;

        case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
            // 图像将在着色器中被读取（采样器，输入附件）
            // 确保对图像的任何写入都已完成
            if (barrier.srcAccessMask == 0) {
                barrier.srcAccessMask = VK_ACCESS_HOST_WRITE_BIT | VK_ACCESS_TRANSFER_WRITE_BIT;
            }
            barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
            break;
        default:
            // Other source layouts aren't handled (yet)
            break;
    }

    return barrier;
}

/**
 * @brief barrier 用于转换图像资源的属性
 * @param image 目标图像
 * @param srcAccess 原始的访问标志
 * @param dstAccess 目标的访问标志
 * @param oldLayout 原始的图像 layout
 * @param newLayout 目标的图像 layout
 * @param aspectMask 
 * @return 生成图像的内存 barrier
 */
VkImageMemoryBarrier MakeImageMemoryBarrier(VkImage image,
                                            VkImageLayout oldLayout,
                                            VkImageLayout newLayout,
                                            VkImageAspectFlags aspectMask)
{
    VkImageMemoryBarrier barrier = SetImageLayout(oldLayout, newLayout);
    barrier.dstQueueFamilyIndex         = VK_QUEUE_FAMILY_IGNORED;
    barrier.srcQueueFamilyIndex         = VK_QUEUE_FAMILY_IGNORED;
    barrier.image                       = image;
    barrier.subresourceRange            = {0};
    barrier.subresourceRange.aspectMask = aspectMask;
    barrier.subresourceRange.levelCount = VK_REMAINING_MIP_LEVELS;
    barrier.subresourceRange.layerCount = VK_REMAINING_ARRAY_LAYERS;

    return barrier;
}

/**
 * @brief 设置图像创建信息
 */
VkImageCreateInfo MakeImage2DCreateInfo(VkExtent2D size, VkFormat format, VkImageUsageFlags usage, uint32_t mipLevels)
{
    VkImageCreateInfo imageCreateInfo = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    imageCreateInfo.imageType     = VK_IMAGE_TYPE_2D;
    imageCreateInfo.format        = format;
    imageCreateInfo.samples       = VK_SAMPLE_COUNT_1_BIT;
    imageCreateInfo.mipLevels     = mipLevels;
    imageCreateInfo.arrayLayers   = 1;
    imageCreateInfo.extent.width  = size.width;
    imageCreateInfo.extent.height = size.height;
    imageCreateInfo.extent.depth  = 1;
    imageCreateInfo.tiling        = VK_IMAGE_TILING_OPTIMAL;
    imageCreateInfo.sharingMode   = VK_SHARING_MODE_EXCLUSIVE;
    imageCreateInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    imageCreateInfo.usage         = usage | VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;

//    if (format == VK_FORMAT_D16_UNORM_S8_UINT || format == VK_FORMAT_D24_UNORM_S8_UINT || format == VK_FORMAT_D32_SFLOAT_S8_UINT) {
//    }

    return imageCreateInfo;
}

/**
 * @brief 设置 cube map 图像的创建信息
 */
VkImageCreateInfo MakeImageCubeCreateInfo(const VkExtent2D& size, VkFormat format, VkImageUsageFlags usage, uint32_t mipLevels)
{
    VkImageCreateInfo imageCreateInfo{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    imageCreateInfo.imageType     = VK_IMAGE_TYPE_2D;
    imageCreateInfo.format        = format;
    imageCreateInfo.mipLevels     = mipLevels;
    imageCreateInfo.arrayLayers   = 6;
    imageCreateInfo.samples       = VK_SAMPLE_COUNT_1_BIT;
    imageCreateInfo.extent.width  = size.width;
    imageCreateInfo.extent.height = size.height;
    imageCreateInfo.extent.depth  = 1;
    imageCreateInfo.tiling        = VK_IMAGE_TILING_OPTIMAL;
    imageCreateInfo.sharingMode   = VK_SHARING_MODE_EXCLUSIVE;
    imageCreateInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    imageCreateInfo.usage         = usage | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    imageCreateInfo.flags         = VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT;
    return imageCreateInfo;
}

/**
 * @brief 设置图像视图的创建信息
 */
VkImageViewCreateInfo MakeImage2DViewCreateInfo(VkImage image,
                                                VkFormat format /*= VK_FORMAT_R8G8B8A8_UNORM*/,
                                                VkImageAspectFlags aspectFlags /*= VK_IMAGE_ASPECT_COLOR_BIT*/,
                                                uint32_t levels /*= 1*/,
                                                const void* pNextImageView /*= nullptr*/)
{
    VkImageViewCreateInfo viewInfo{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    viewInfo.pNext                           = pNextImageView;
    viewInfo.image                           = image;
    viewInfo.viewType                        = VK_IMAGE_VIEW_TYPE_2D;
    viewInfo.format                          = format;
    viewInfo.subresourceRange.aspectMask     = aspectFlags;
    viewInfo.subresourceRange.baseMipLevel   = 0;
    viewInfo.subresourceRange.levelCount     = levels;
    viewInfo.subresourceRange.baseArrayLayer = 0;
    viewInfo.subresourceRange.layerCount     = 1;

    if (format == VK_FORMAT_D16_UNORM_S8_UINT || format == VK_FORMAT_D24_UNORM_S8_UINT || format == VK_FORMAT_D32_SFLOAT_S8_UINT) {
        viewInfo.subresourceRange.aspectMask |= VK_IMAGE_ASPECT_STENCIL_BIT;
    }

    return viewInfo;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Texture::destroy()
{
    if (view != VK_NULL_HANDLE) {
        vkDestroyImageView(device, view, nullptr);
        view = VK_NULL_HANDLE;
    }

    if (sampler) {
        vkDestroySampler(device, sampler, nullptr);
        sampler = VK_NULL_HANDLE;
    }

#ifdef USE_VMA
    if (image != VK_NULL_HANDLE) {
        vmaDestroyImage(allocator, image, imageAlloc);
        image = VK_NULL_HANDLE;
    }
#else
    if (deviceMemory != VK_NULL_HANDLE) {
        vkDestroyImage(device, image, nullptr);
        vkFreeMemory(device, deviceMemory, nullptr);
        deviceMemory = VK_NULL_HANDLE;
    }
#endif
}

void Texture::updateDescriptor()
{
    descriptor.sampler     = sampler;
    descriptor.imageView   = view;
    descriptor.imageLayout = imageLayout;
}

void Texture::upload(UploadHeap* uploadHeap)
{
    // 前置 barrier
    {
        auto barrier = MakeImageMemoryBarrier(image,
                                              VK_IMAGE_LAYOUT_UNDEFINED,
                                              VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                              VK_IMAGE_ASPECT_COLOR_BIT
        );

        barrier.subresourceRange.levelCount = mipLevels;
        barrier.subresourceRange.layerCount = layerCount;
        uploadHeap->addImagePreBarrier(barrier);
    }

    // 上传图片
    auto compsPerPixel = static_cast<uint32_t>(SizeOfFormat(format));

    uint32_t imgDataOffset = 0;

    for (uint32_t layer = 0; layer < layerCount; layer++) {
        for (uint32_t level = 0; level < mipLevels; level++) {
            auto w = std::max<uint32_t>(width >> level, 1);
            auto h = std::max<uint32_t>(height >> level, 1);

            auto uploadSize = static_cast<uint32_t>(w * h * compsPerPixel);
            auto* pixels = uploadHeap->beginAlloc(uploadSize, 512);

            // 如果没有成功从上传堆中分配到足够大小的空间，先把已经暂存的数据上传到设备，再进行尝试分配
            if (!pixels) {
                uploadHeap->flushAndFinish(true);
                pixels = uploadHeap->alloc(uploadSize, 512);

                assert(pixels);
            }

            // 拷贝图片数据到上传堆
            // ...
            const auto* img = bitmap.pixels.data() + imgDataOffset;
            std::memcpy(pixels, img, uploadSize);
            imgDataOffset += static_cast<uint32_t>(w * h * compsPerPixel);

            uploadHeap->endAlloc();

            VkBufferImageCopy bufferCopyRegion{};
            bufferCopyRegion.bufferOffset = static_cast<uint32_t>(pixels - uploadHeap->basePtr());;
            bufferCopyRegion.imageSubresource.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT;
            bufferCopyRegion.imageSubresource.layerCount     = 1;
            bufferCopyRegion.imageSubresource.baseArrayLayer = layer;
            bufferCopyRegion.imageSubresource.mipLevel       = level;
            bufferCopyRegion.imageExtent.width               = w;
            bufferCopyRegion.imageExtent.height              = h;
            bufferCopyRegion.imageExtent.depth               = 1;
            uploadHeap->addImageCopy(image, bufferCopyRegion);
        }
    }

    // 后置 barrier
    {
        auto barrier = MakeImageMemoryBarrier(image,
                                              VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                              imageLayout,
                                              VK_IMAGE_ASPECT_COLOR_BIT
        );

        barrier.subresourceRange.levelCount = mipLevels;
        barrier.subresourceRange.layerCount = layerCount;

        uploadHeap->addImagePostBarrier(barrier);
    }
}

void Texture2D::loadFromFile(std::string_view fileName,
                             VkDevice device_,
                             VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
                             VmaAllocator allocator_,
#endif
                             VkImageUsageFlags imageUsageFlags,
                             VkImageLayout imageLayout_,
                             bool bMipmap)
{
    this->device = device_;

    bitmap = LoadTextureFormFile(fileName, bMipmap);

    format = VK_FORMAT_R8G8B8A8_UNORM;

    mipLevels   = bitmap.mip_level;
    width       = bitmap.width;
    height      = bitmap.height;
    imageLayout = imageLayout_;

    auto imageCreateInfo = MakeImage2DCreateInfo({width, height}, format, imageUsageFlags, mipLevels);

#ifdef USE_VMA
    this->allocator = allocator_;

    VmaAllocationCreateInfo imageAllocCreateInfo = {};
    imageAllocCreateInfo.usage     = VMA_MEMORY_USAGE_GPU_ONLY;
    imageAllocCreateInfo.flags     = VMA_ALLOCATION_CREATE_USER_DATA_COPY_STRING_BIT;
    imageAllocCreateInfo.pUserData = const_cast<char*>(San::GetFileName(fileName).data());
    VmaAllocationInfo gpuImageAllocInfo = {};
    VK_CHECK(vmaCreateImage(allocator,
                            &imageCreateInfo,
                            &imageAllocCreateInfo,
                            &image,
                            &imageAlloc,
                            &gpuImageAllocInfo));
#else
    VK_CHECK(vkCreateImage(device, &imageCreateInfo, nullptr, &image));

    // 创建支持缓冲区句柄的内存
    VkMemoryRequirements memReqs;
    vkGetImageMemoryRequirements(device, image, &memReqs);

    VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAllocInfo.allocationSize  = memReqs.size;
    // 找到一个符合缓冲区属性的内存类型索引
    memAllocInfo.memoryTypeIndex = GetMemoryType(physicalDevice, memReqs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VK_CHECK(vkAllocateMemory(device, &memAllocInfo, nullptr, &deviceMemory));

    VK_CHECK(vkBindImageMemory(device, image, deviceMemory, 0));
#endif

    {
        VkPhysicalDeviceFeatures deviceFeatures;
        vkGetPhysicalDeviceFeatures(physicalDevice, &deviceFeatures);

        VkPhysicalDeviceProperties deviceProperties;
        vkGetPhysicalDeviceProperties(physicalDevice, &deviceProperties);

        // 默认的 sampler
        VkSamplerCreateInfo samplerCreateInfo{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        samplerCreateInfo.magFilter        = VK_FILTER_LINEAR;
        samplerCreateInfo.minFilter        = VK_FILTER_LINEAR;
        samplerCreateInfo.mipmapMode       = VK_SAMPLER_MIPMAP_MODE_LINEAR;
        samplerCreateInfo.addressModeU     = VK_SAMPLER_ADDRESS_MODE_REPEAT;
        samplerCreateInfo.addressModeV     = VK_SAMPLER_ADDRESS_MODE_REPEAT;
        samplerCreateInfo.addressModeW     = VK_SAMPLER_ADDRESS_MODE_REPEAT;
        samplerCreateInfo.mipLodBias       = 0.0f;
        samplerCreateInfo.compareOp        = VK_COMPARE_OP_NEVER;
        samplerCreateInfo.minLod           = 0.0f;
        // maxLod 应该和 mip 等级相同
        samplerCreateInfo.maxLod           = (float) mipLevels;
        // 各异向性需要硬件设备支持
        samplerCreateInfo.maxAnisotropy    = deviceFeatures.samplerAnisotropy ? deviceProperties.limits.maxSamplerAnisotropy : 1.0f;
        samplerCreateInfo.anisotropyEnable = deviceFeatures.samplerAnisotropy;
        samplerCreateInfo.borderColor      = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
        VK_CHECK(vkCreateSampler(device, &samplerCreateInfo, nullptr, &sampler));
    }

    // 创建图像视图
    VkImageViewCreateInfo viewCreateInfo{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    viewCreateInfo.viewType                    = VK_IMAGE_VIEW_TYPE_2D;
    viewCreateInfo.format                      = format;
//    viewCreateInfo.components                  = {VK_COMPONENT_SWIZZLE_R, VK_COMPONENT_SWIZZLE_G, VK_COMPONENT_SWIZZLE_B, VK_COMPONENT_SWIZZLE_A};
    viewCreateInfo.subresourceRange            = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    // Linear tiling usually won't support mip maps
    // Only set mip map count if optimal tiling is used
    viewCreateInfo.subresourceRange.levelCount = mipLevels;
    viewCreateInfo.image                       = image;
    VK_CHECK(vkCreateImageView(device, &viewCreateInfo, nullptr, &view));

    // 更新图像的描述信息，可用于之后设置描述符集
    updateDescriptor();
}

void TextureCube::loadFromFile(std::string_view fileName,
                               VkDevice device_,
                               VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
                               VmaAllocator allocator_,
#endif
                               VkImageUsageFlags imageUsageFlags,
                               VkImageLayout imageLayout_,
                               bool bMipmap)
{
    this->device = device_;

    // 载入 hdr 图像后，转换为十字型状
    auto crossMap = LoadHDRTextureFormFile(fileName, true, bMipmap);

    // 将十字图形裁剪为大小为 6 的数组，
    bitmap = ConvertVerticalCrossToCubeMapFaces(crossMap);

    format = VK_FORMAT_R32G32B32A32_SFLOAT;

    mipLevels   = bitmap.mip_level;
    layerCount  = bitmap.depth;
    width       = bitmap.width;
    height      = bitmap.height;
    imageLayout = imageLayout_;

    auto imageCreateInfo = MakeImageCubeCreateInfo({width, height}, format, imageUsageFlags, mipLevels);

#ifdef USE_VMA
    this->allocator = allocator_;

    VmaAllocationCreateInfo imageAllocCreateInfo = {};
    imageAllocCreateInfo.usage     = VMA_MEMORY_USAGE_GPU_ONLY;
    imageAllocCreateInfo.flags     = VMA_ALLOCATION_CREATE_USER_DATA_COPY_STRING_BIT;
    imageAllocCreateInfo.pUserData = const_cast<char*>(San::GetFileName(fileName).data());
    VmaAllocationInfo gpuImageAllocInfo = {};
    VK_CHECK(vmaCreateImage(allocator,
                            &imageCreateInfo,
                            &imageAllocCreateInfo,
                            &image,
                            &imageAlloc,
                            &gpuImageAllocInfo));
#else
    VK_CHECK(vkCreateImage(device, &imageCreateInfo, nullptr, &image));

    // 创建支持缓冲区句柄的内存
    VkMemoryRequirements memReqs;
    vkGetImageMemoryRequirements(device, image, &memReqs);

    VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAllocInfo.allocationSize  = memReqs.size;
    // 找到一个符合缓冲区属性的内存类型索引
    memAllocInfo.memoryTypeIndex = GetMemoryType(physicalDevice, memReqs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VK_CHECK(vkAllocateMemory(device, &memAllocInfo, nullptr, &deviceMemory));

    VK_CHECK(vkBindImageMemory(device, image, deviceMemory, 0));
#endif

    {
        VkPhysicalDeviceFeatures deviceFeatures;
        vkGetPhysicalDeviceFeatures(physicalDevice, &deviceFeatures);

        VkPhysicalDeviceProperties deviceProperties;
        vkGetPhysicalDeviceProperties(physicalDevice, &deviceProperties);

        // 默认的 sampler
        VkSamplerCreateInfo samplerCreateInfo{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        samplerCreateInfo.magFilter        = VK_FILTER_LINEAR;
        samplerCreateInfo.minFilter        = VK_FILTER_LINEAR;
        samplerCreateInfo.mipmapMode       = VK_SAMPLER_MIPMAP_MODE_LINEAR;
        samplerCreateInfo.addressModeU     = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
        samplerCreateInfo.addressModeV     = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
        samplerCreateInfo.addressModeW     = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
        samplerCreateInfo.mipLodBias       = 0.0f;
        samplerCreateInfo.compareOp        = VK_COMPARE_OP_NEVER;
        samplerCreateInfo.minLod           = 0.0f;
        // maxLod 应该和 mip 等级相同
        samplerCreateInfo.maxLod           = (float) mipLevels;
        // 各异向性需要硬件设备支持
        samplerCreateInfo.maxAnisotropy    = deviceFeatures.samplerAnisotropy ? deviceProperties.limits.maxSamplerAnisotropy : 1.0f;
        samplerCreateInfo.anisotropyEnable = deviceFeatures.samplerAnisotropy;
        samplerCreateInfo.borderColor      = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
        VK_CHECK(vkCreateSampler(device, &samplerCreateInfo, nullptr, &sampler));
    }

    // 创建图像视图
    VkImageViewCreateInfo viewCreateInfo{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    viewCreateInfo.viewType                    = VK_IMAGE_VIEW_TYPE_CUBE;
    viewCreateInfo.format                      = format;
    viewCreateInfo.components                  = {VK_COMPONENT_SWIZZLE_R, VK_COMPONENT_SWIZZLE_G, VK_COMPONENT_SWIZZLE_B, VK_COMPONENT_SWIZZLE_A};
    viewCreateInfo.subresourceRange            = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    // Linear tiling usually won't support mip maps
    // Only set mip map count if optimal tiling is used
    viewCreateInfo.subresourceRange.layerCount = layerCount;
    viewCreateInfo.subresourceRange.levelCount = mipLevels;
    viewCreateInfo.image                       = image;
    VK_CHECK(vkCreateImageView(device, &viewCreateInfo, nullptr, &view));

    // 更新图像的描述信息，可用于之后设置描述符集
    updateDescriptor();
}

void TextureVK::create(
    VkDevice device_,
    VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
    VmaAllocator allocator_,
#endif
    const VkExtent2D& size,
    VkFormat format_,
    VkImageAspectFlags aspectFlags,
    VkImageUsageFlags imageUsageFlags,
    VkImageLayout imageLayout_,
    std::string_view name
)
{
    device      = device_;
    format      = format_;
    width       = size.width;
    height      = size.height;
    imageLayout = imageLayout_;

    auto imageCreateInfo = MakeImage2DCreateInfo({width, height}, format, imageUsageFlags, mipLevels);

#ifdef USE_VMA
    this->allocator = allocator_;

    VmaAllocationCreateInfo imageAllocCreateInfo = {};
    imageAllocCreateInfo.usage     = VMA_MEMORY_USAGE_GPU_ONLY;
    imageAllocCreateInfo.flags     = VMA_ALLOCATION_CREATE_USER_DATA_COPY_STRING_BIT;
    imageAllocCreateInfo.pUserData = const_cast<char*>(name.data());
    VmaAllocationInfo gpuImageAllocInfo = {};
    VK_CHECK(vmaCreateImage(allocator,
                            &imageCreateInfo,
                            &imageAllocCreateInfo,
                            &image,
                            &imageAlloc,
                            &gpuImageAllocInfo));
#else
    VK_CHECK(vkCreateImage(device, &imageCreateInfo, nullptr, &image));

    // 创建支持缓冲区句柄的内存
    VkMemoryRequirements memReqs;
    vkGetImageMemoryRequirements(device, image, &memReqs);

    VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    memAllocInfo.allocationSize  = memReqs.size;
    // 找到一个符合缓冲区属性的内存类型索引
    memAllocInfo.memoryTypeIndex = GetMemoryType(physicalDevice, memReqs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VK_CHECK(vkAllocateMemory(device, &memAllocInfo, nullptr, &deviceMemory));

    VK_CHECK(vkBindImageMemory(device, image, deviceMemory, 0));
#endif

    // 如果图像用途指定了采样，那么就需要创建采样器
    if ((imageUsageFlags & VK_IMAGE_USAGE_SAMPLED_BIT) != 0) {
        // 默认的 sampler
        VkSamplerCreateInfo samplerCreateInfo{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        VK_CHECK(vkCreateSampler(device, &samplerCreateInfo, nullptr, &sampler));
    }

    auto imageViewCreateInfo = MakeImage2DViewCreateInfo(image, format, aspectFlags);
    VK_CHECK(vkCreateImageView(device, &imageViewCreateInfo, nullptr, &view));

    // 更新图像的描述信息，可用于之后设置描述符集
    updateDescriptor();
}

} // yu::vk