﻿//
// Created by 秋鱼 on 2022/9/15.
//

#include "skybox.hpp"
#include "pipeline.hpp"

namespace yu::vk {

void SkyBox::create(std::string_view cubeMapFile, VkDevice device, ResourceAllocator* resAlloc)
{
    device_             = device;
    resource_allocator_ = resAlloc;

    // 加载盒子模型
    cube_model_.load("Cube/Cube.gltf", resAlloc, yu::GltfAttributes::NoAttribs);

    // 加载天空盒图片
    cube_map_ = resAlloc->createTexture<TextureCube>(GetTextureFile(cubeMapFile.data()));

    DescriptorSetBindings descSetBinds;

    // 相机矩阵
    descSetBinds.addBinding(0, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC, 1, VK_SHADER_STAGE_VERTEX_BIT);

    // gltf descriptions
    descSetBinds.addBinding(1, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1, VK_SHADER_STAGE_FRAGMENT_BIT);

    // 创建描述符资源
    descriptor_set_layout_ = descSetBinds.createLayout(device);
    descriptor_pool_       = descSetBinds.createPool(device, 1);
    descriptor_set_        = descSetBinds.allocSet(device, descriptor_pool_, descriptor_set_layout_);

    // 更新天空盒描述符
    {
        resAlloc->getDynamicBuffer().setDescriptorSet(0, sizeof(glm::mat4), descriptor_set_);

        std::vector<VkWriteDescriptorSet> writes;

        writes.emplace_back(descSetBinds.makeWrite(descriptor_set_, 1, &cube_map_.descriptor));

        // Writing the information
        vkUpdateDescriptorSets(device, static_cast<uint32_t>(writes.size()), writes.data(), 0, nullptr);
    }

}

void SkyBox::createPipeline(VkRenderPass renderPass, VkPipelineCache pipelineCache)
{
    // 创建流水线
    VkPipelineLayoutCreateInfo pipelineCreateInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pipelineCreateInfo.setLayoutCount = 1;
    pipelineCreateInfo.pSetLayouts    = &descriptor_set_layout_;
    VK_CHECK(vkCreatePipelineLayout(device_, &pipelineCreateInfo, nullptr, &pipeline_layout_));

    GraphicsPipelineGeneratorCombined pipelineGenerator{device_, pipeline_layout_, renderPass};
    pipelineGenerator.setDepthTest(VK_TRUE);
    pipelineGenerator.setDepthWrite(VK_FALSE);
    pipelineGenerator.setCullMode(VK_CULL_MODE_FRONT_BIT);
    pipelineGenerator.addShader("Skybox.vert", VK_SHADER_STAGE_VERTEX_BIT);
    pipelineGenerator.addShader("Skybox.frag", VK_SHADER_STAGE_FRAGMENT_BIT);
    pipelineGenerator.addBindingDescriptions(cube_model_.getBindingDescriptions());
    pipelineGenerator.addAttributeDescriptions(cube_model_.getVertexInputDescriptions());

    pipeline_ = pipelineGenerator.createPipeline(pipelineCache);
    pipelineGenerator.clearShaders();
}

void SkyBox::destroy()
{
    vkDestroyPipeline(device_, pipeline_, nullptr);
    vkDestroyPipelineLayout(device_, pipeline_layout_, nullptr);

    vkDestroyDescriptorPool(device_, descriptor_pool_, nullptr);
    vkDestroyDescriptorSetLayout(device_, descriptor_set_layout_, nullptr);

    cube_model_.destroy();
    cube_map_.destroy();
}

void SkyBox::draw(VkCommandBuffer cmdBuffer, glm::mat4& projView)
{
    auto constantBufferInfo = resource_allocator_->getDynamicBuffer().allocBuffer(sizeof(glm::mat4), &projView);

    int      numUniformOffsets = 0;
    uint32_t uniformOffset     = 0;

    if (constantBufferInfo.buffer != nullptr) {
        numUniformOffsets = 1;
        uniformOffset     = static_cast<uint32_t>(constantBufferInfo.offset);
    }

    // 绑定流水线
    vkCmdBindPipeline(cmdBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);

    vkCmdBindDescriptorSets(cmdBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_layout_, 0, 1, &descriptor_set_,
                            numUniformOffsets,
                            &uniformOffset);
    
    cube_model_.draw(cmdBuffer);
}

} // yu::vk