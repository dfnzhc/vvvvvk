﻿//
// Created by 秋鱼 on 2022/6/12.
//

#pragma once

#include <common/buffer_ring.hpp>

#include "buffer.hpp"

namespace yu::vk {

/**
 * @brief 一个动态的缓冲区，从一块巨大的内存中分配内存，使用环形缓冲区来实现；其中的内容会在每一帧更新。
 */
class DynamicBuffer
{
public:
    void create(VkDevice device, VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
                VmaAllocator allocator,
#endif
                uint32_t numberOfFrames, uint32_t totalSize, std::string_view name);
    void destroy();

    bool allocBuffer(uint32_t size, void** data, VkDescriptorBufferInfo& descOut);
    VkDescriptorBufferInfo allocBuffer(uint32_t size, void* data);

    [[nodiscard]] VkWriteDescriptorSet setWriteDescriptorSet(uint32_t bindIndex, uint32_t size, VkDescriptorSet descriptorSet);
    void setDescriptorSet(uint32_t bindIndex, uint32_t size, VkDescriptorSet descriptorSet);

    void beginFrame();

private:
    VkDevice device_{};

    BufferRing mem_;
    uint32_t   total_size_{};
    char* data_ = nullptr;

    VkBuffer buffer_{};

#ifdef USE_VMA
    VmaAllocator  allocator_{};
    VmaAllocation buffer_allocation_{};
#else
    VkDeviceMemory device_memory_{};
#endif
};

} // yu::vk