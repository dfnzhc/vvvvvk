﻿//
// Created by 秋鱼 on 2022/8/21.
//

#pragma once

#include "buffer.hpp"
#include "error.hpp"
#include "context.hpp"
#include "swap_chain.hpp"
#include "texture.hpp"
#include "dynamic_buffer.hpp"
#include "upload_heap.hpp"
#include "static_buffer.hpp"
#include "vulkan_utils.hpp"
#include "common/common.hpp"

namespace yu::vk {

/**
 * @brief 记录了一些 Vulkan 对象，专门用于创建资源（如缓冲区、图像等）
 */
class ResourceAllocator
{
public:
    void create(const Context& context, const SwapChain& swapchain);
    void destroy();

    [[nodiscard]] UploadHeap& getUploadHeap() { return upload_heap_; }
    [[nodiscard]] DynamicBuffer& getDynamicBuffer() { return dynamic_buffer_; }
    [[nodiscard]] StaticBuffer& getStaticBuffer() { return static_buffer_; }

    void beginFrame();
    void uploadStaticAllocation();

    template<typename T>
    Buffer createBuffer(const std::vector<T>& data,
                        VkBufferUsageFlags usage,
                        VkMemoryPropertyFlags memProps = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
    {
        Buffer buffer;
        VK_CHECK(CreateBuffer(context_->getDevice(),
                              context_->getPhysicalDevice(),
                              usage,
                              memProps,
                              sizeof(T) * data.size(),
                              &buffer,
                              (void*) data.data()));

        return buffer;
    }

    Buffer createBuffer(VkDeviceSize bufferSize,
                        VkBufferUsageFlags usage,
                        VkMemoryPropertyFlags memProps = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
    {
        Buffer buffer;
        VK_CHECK(CreateBuffer(context_->getDevice(),
                              context_->getPhysicalDevice(),
                              usage,
                              memProps,
                              bufferSize,
                              &buffer));

        return buffer;
    }

    template<typename T>
    requires std::derived_from<T, Texture>
    auto createTexture(std::string_view filename) -> decltype(auto)
    {
        T texture;
        texture.loadFromFile(filename, context_->getDevice(), context_->getPhysicalDevice(),
#ifdef USE_VMA
                             allocator_,
#endif
                             VK_IMAGE_USAGE_SAMPLED_BIT
        );

        texture.upload(&upload_heap_);
        upload_heap_.flushAndFinish();

        return texture;
    }

    TextureVK createTexture(const VkExtent2D& size,
                            VkFormat format,
                            VkImageAspectFlags aspectFlags = VK_IMAGE_ASPECT_COLOR_BIT,
                            VkImageUsageFlags imageUsageFlags = VK_IMAGE_USAGE_SAMPLED_BIT,
                            VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                            std::string_view name = "");

    inline VkFormat getDepthFormat() const { return GetDepthFormat(context_->getPhysicalDevice()); }

private:
    const Context  * context_   = nullptr;
    const SwapChain* swapchain_ = nullptr;

#ifdef USE_VMA
    VmaAllocator allocator_{};
#endif

    DynamicBuffer dynamic_buffer_{};
    StaticBuffer  static_buffer_{};
    UploadHeap    upload_heap_{};
};

} // yu::vk