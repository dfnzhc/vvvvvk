﻿//
// Created by 秋鱼 on 2022/6/17.
//

#include <common/math_utils.hpp>
#include "static_buffer.hpp"
#include "error.hpp"
#include "buffer.hpp"

namespace yu::vk {

void StaticBuffer::create(VkDevice device, VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
                          VmaAllocator allocator,
#endif
                          uint32_t totalSize, bool bUseStaging, std::string_view name, VkBufferUsageFlags extUsageFlag)
{
    device_     = device;
    total_size_ = totalSize;

    use_video_buffer_ = bUseStaging;

    // 在系统上创建缓冲区，绑定并进行映射
    {
        VkBufferUsageFlags usage = extUsageFlag | VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;
        if (bUseStaging)
            usage |= VK_BUFFER_USAGE_TRANSFER_SRC_BIT;

#ifdef USE_VMA
        allocator_ = allocator;
        VK_CHECK(CreateBufferVMA(usage,
                                 total_size_,
                                 allocator_,
                                 VMA_MEMORY_USAGE_CPU_TO_GPU,
                                 &buffer_,
                                 &buffer_allocation_,
                                 (void**) &data_,
                                 name));
#else
        VK_CHECK(CreateBuffer(device, physicalDevice, usage,
                              VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                              total_size_,
                              &buffer_,
                              &device_memory_,
                              false,
                              (void**) &data_));
#endif
    }

    // 创建显存上的缓冲区，前面创建的缓冲区成为暂存缓冲区
    if (bUseStaging) {
#ifdef USE_VMA
        VK_CHECK(CreateBufferVMA(
            extUsageFlag | VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            total_size_,
            allocator_,
            VMA_MEMORY_USAGE_GPU_ONLY,
            &video_buffer_,
            &video_allocation_,
            nullptr,
            name));
#else
        VK_CHECK(CreateBuffer(device,
                              physicalDevice,
                              VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                              VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                              total_size_,
                              &video_buffer_,
                              &video_memory_,
                              false,
                              nullptr));
#endif
    }
}

void StaticBuffer::destroy()
{
    if (use_video_buffer_) {
#ifdef USE_VMA
        vmaDestroyBuffer(allocator_, video_buffer_, video_allocation_);
#else
        vkFreeMemory(device_, video_memory_, nullptr);
        vkDestroyBuffer(device_, video_buffer_, nullptr);
#endif
        video_buffer_ = VK_NULL_HANDLE;
    }

    if (buffer_ != VK_NULL_HANDLE) {
#ifdef USE_VMA
        vmaUnmapMemory(allocator_, buffer_allocation_);
        vmaDestroyBuffer(allocator_, buffer_, buffer_allocation_);
#else
        vkUnmapMemory(device_, device_memory_);
        vkFreeMemory(device_, device_memory_, nullptr);
        vkDestroyBuffer(device_, buffer_, nullptr);
#endif
        buffer_ = VK_NULL_HANDLE;
    }

}
bool StaticBuffer::allocBuffer(uint32_t numberOfElements,
                               uint32_t elementSizeInByte,
                               void** pData,
                               VkDescriptorBufferInfo* pDesc)
{
    std::lock_guard<std::mutex> lock(mutex_);

    uint32_t size = AlignUp(numberOfElements * elementSizeInByte, 256u);
    assert(memory_offset_ + size < total_size_);

    *pData = (void*) (data_ + memory_offset_);

    pDesc->buffer = use_video_buffer_ ? video_buffer_ : buffer_;
    pDesc->offset = memory_offset_;
    pDesc->range  = size;

    memory_offset_ += size;

    return true;
}

bool StaticBuffer::allocBuffer(uint32_t numberOfElements,
                               uint32_t elementSizeInByte,
                               const void* pInitData,
                               VkDescriptorBufferInfo* pDesc)
{
    void* pData;
    if (allocBuffer(numberOfElements, elementSizeInByte, &pData, pDesc)) {
        memcpy(pData, pInitData, numberOfElements * elementSizeInByte);
        return true;
    }

    return false;
}

void StaticBuffer::uploadData(VkCommandBuffer cmdBuf)
{
    if (!use_video_buffer_)
        return;

    VkBufferCopy region;
    region.srcOffset = 0;
    region.dstOffset = 0;
    region.size      = total_size_;

    vkCmdCopyBuffer(cmdBuf, buffer_, video_buffer_, 1, &region);
}

void StaticBuffer::freeUploadHeap()
{
    if (!use_video_buffer_ || buffer_ == VK_NULL_HANDLE)
        return;

#ifdef USE_VMA
    vmaUnmapMemory(allocator_, buffer_allocation_);
    vmaDestroyBuffer(allocator_, buffer_, buffer_allocation_);
#else
    //release upload heap
    vkUnmapMemory(device_, device_memory_);
    vkFreeMemory(device_, device_memory_, nullptr);
    vkDestroyBuffer(device_, buffer_, nullptr);
    device_memory_ = VK_NULL_HANDLE;
#endif
    buffer_ = VK_NULL_HANDLE;
}

} // yu::vk