﻿//
// Created by 秋鱼 on 2022/6/9.
//

#include "appbase.hpp"
#include "imgui_impl_vulkan.h"
#include "error.hpp"
#include <platform.hpp>
#include <logger.hpp>
#include <glfw_window.hpp>
#include <imgui.h>
#include <common/imgui_impl_glfw.h>

#include <GLFW/glfw3.h>
#include <system_utils.hpp>

namespace yu::vk {

bool AppBase::prepare(San::Platform& platform)
{
    return Application::prepare(platform);
}

void AppBase::setup()
{
    Application::setup();

    initVulkan();

    {
        system_info_.CPUName = San::GetCPUNameString();

        auto deviceInfo = context_->getPhysicalDeviceInfo().properties;
        system_info_.GPUName    = deviceInfo.deviceName;
        system_info_.APIVersion = fmt::format("{}.{}.{}",
                                              (deviceInfo.apiVersion >> 22),
                                              ((deviceInfo.apiVersion >> 12) & 0x3ff),
                                              (deviceInfo.apiVersion & 0xfff));
    }

    auto* glfw_window = dynamic_cast<const San::GLFW_Window*>(platform_->getWindow());
    auto [width, height] = glfw_window->getExtent();

    // 创建鼠标的追踪类
    mouse_tracker_ = std::make_unique<yu::MouseTracker>();
    mouse_tracker_->camera_->setFov(glm::radians(60.0f), width, height, 0.1f, 1000.0f);
    mouse_tracker_->camera_->lookAt({0, 0, 5}, {0, 0, 0});

    // 创建渲染器
    initRenderer();
    if (!renderer_) {
        LOG_FATAL("Renderer has not been setup");
    }
    renderer_->create(context_.get(), mouse_tracker_.get(), swap_chain_.get());
    renderer_->createUI(glfw_window->getGLFWHandle());
    renderer_->resize(width, height);
}

void AppBase::update(float delta_time)
{
    Application::update(delta_time);

    ImGui_ImplVulkan_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    if (!renderer_->isLoadingFinish()) {
        renderer_->prepareRender();
    } else {
        buildUI();
        renderer_->setReadyToRender(true);
    }

    renderer_->render();
}

void AppBase::finish()
{
    Application::finish();

    vkDeviceWaitIdle(context_->getDevice());

    renderer_->destroy();
    renderer_.reset();

    swap_chain_->destroy();
    vkDestroySurfaceKHR(context_->getInstance(), surface_, nullptr);

    context_->destroy();
}

bool AppBase::resize(uint32_t width, uint32_t height)
{
    if (!Application::resize(width, height)) {
        return false;
    }

    vkDeviceWaitIdle(context_->getDevice());

    renderer_->resize(width, height);

    return true;
}

void AppBase::input_event(const San::InputEvent& input_event)
{
    Application::input_event(input_event);

    using San::InputEvent;
    using San::EventType;
    using San::KeyInputEvent;
    using San::MouseInputEvent;
    using San::MouseButton;
    using San::MouseAction;

    if (input_event.type == EventType::Keyboard) {
        [[maybe_unused]]
        const auto& key_event = static_cast<const KeyInputEvent&>(input_event);

//        LOG_INFO("[Keyboard] key: {}, action: {}", static_cast<int>(key_event.code), GetActionString(key_event.action));
    } else if (input_event.type == EventType::Mouse) {
        [[maybe_unused]]
        const auto& mouse_event = static_cast<const MouseInputEvent&>(input_event);

        ImGuiIO& io = ImGui::GetIO();
        if (mouse_event.isEvent(MouseButton::Left, MouseAction::Press) ||
            mouse_event.isEvent(MouseButton::Left, MouseAction::PressedMove)) {
            io.AddMouseButtonEvent(ImGuiMouseButton_Left, true);
        }
        if (mouse_event.isEvent(MouseButton::Left, MouseAction::Release)) {
            io.AddMouseButtonEvent(ImGuiMouseButton_Left, false);
        }
        // (2) ONLY forward mouse data to your underlying app/game.
        if (io.WantCaptureMouse) {
            return;
        }

        if (mouse_event.isEvent(MouseButton::Left, MouseAction::PressedMove)) {
            mouse_tracker_->update(static_cast<int>(mouse_event.pos_x),
                                   static_cast<int>(mouse_event.pos_y));
        }

        if (mouse_event.isEvent(MouseButton::Left, MouseAction::Release)) {
            mouse_tracker_->stopTracking();
        }

        if (mouse_event.isEvent(MouseButton::Middle, MouseAction::Scroll)) {
            mouse_tracker_->zoom(mouse_event.scroll_dir);
        }

        if (mouse_event.isEvent(MouseButton::Right, MouseAction::PressedMove)) {
            mouse_tracker_->update(static_cast<int>(mouse_event.pos_x),
                                   static_cast<int>(mouse_event.pos_y),
                                   CameraUpdateOp::Offset);
        }

        if (mouse_event.isEvent(MouseButton::Right, MouseAction::Release)) {
            mouse_tracker_->stopTracking();
        }
//        LOG_INFO("[Mouse] key: {}, action: {} ({}.{} {})",
//                 GetButtonString(mouse_event.button),
//                 GetActionString(mouse_event.action), mouse_event.pos_x, mouse_event.pos_y, mouse_event.scroll_dir);
    }
}

void AppBase::initVulkan()
{
    // 1. 创建 vulkan context
    uint32_t count{0};
    auto     reqExtensions = glfwGetRequiredInstanceExtensions(&count);

    ContextCreateInfo contextInfo;

    for (uint32_t ext_id = 0; ext_id < count; ext_id++)  // Adding required extensions (surface, win32, linux, ..)
        contextInfo.addInstanceExtension(reqExtensions[ext_id]);
    contextInfo.addInstanceExtension(VK_EXT_DEBUG_UTILS_EXTENSION_NAME, true);  // Allow debug names
    contextInfo.addDeviceExtension(VK_KHR_SWAPCHAIN_EXTENSION_NAME);            // Enabling ability to present rendering
    contextInfo.addDeviceExtension(VK_EXT_SCALAR_BLOCK_LAYOUT_EXTENSION_NAME);
    // 子类添加 context 设置
    setVKContextCreateInfo(contextInfo);

    context_ = std::make_unique<Context>();
    context_->create(contextInfo);

    auto* glfw_window = dynamic_cast<const San::GLFW_Window*>(platform_->getWindow());
    auto [width, height] = glfw_window->getExtent();

    // 2. 创建交换链
    VK_CHECK(glfwCreateWindowSurface(context_->getInstance(), glfw_window->getGLFWHandle(), nullptr, &surface_));
    context_->checkGCTQueuePresent(surface_);

    swap_chain_ = std::make_unique<SwapChain>();
    swap_chain_->create(context_->getDevice(), context_->getPhysicalDevice(), context_->getGCTQueue(), context_->getGCTQueue(), surface_);
    swap_chain_->update(width, height);
}

void AppBase::buildUI()
{
    // 渲染性能的 profiler
    auto [W, H] = platform_->getWindow()->getExtent();

    {
        const uint32_t PROFILER_WINDOW_PADDIG_X = 10;
        const uint32_t PROFILER_WINDOW_PADDIG_Y = 10;
        const uint32_t PROFILER_WINDOW_SIZE_X   = 400;
        const uint32_t PROFILER_WINDOW_SIZE_Y   = 450;
        const uint32_t PROFILER_WINDOW_POS_X    = W - PROFILER_WINDOW_PADDIG_X - PROFILER_WINDOW_SIZE_X;
        const uint32_t PROFILER_WINDOW_POS_Y    = PROFILER_WINDOW_PADDIG_Y;

        // track highest frame rate and determine the max value of the graph based on the measured highest value
        static float              RecentHighestFrameTime = 0.0f;
        static float              RecentLowestFrameTime  = 99999.0f;
        constexpr int             RecordCount            = 128;
        static std::vector<float> FrameTimeRecords(RecordCount, 0.0);

        //scrolling data and average FPS computing
        const auto& timeStamps = renderer_->getTimings();
        const bool bTimeStampsAvailable = !timeStamps.empty();
        if (bTimeStampsAvailable) {
            std::rotate(FrameTimeRecords.begin(), FrameTimeRecords.begin() + 1, FrameTimeRecords.end());
            float ms = timeStamps.back().microseconds;
            FrameTimeRecords.back() = ms;

            if (ms < RecentLowestFrameTime) RecentLowestFrameTime   = ms;
            if (ms > RecentHighestFrameTime) RecentHighestFrameTime = ms;
        }
        const float frameTime_us = FrameTimeRecords.back();
        const float frameTime_ms = frameTime_us * 0.001f;
        const int   fps          = bTimeStampsAvailable ? static_cast<int>(1000000.0f / frameTime_us) : 0;

        // UI
        ImGui::SetNextWindowPos(ImVec2((float) PROFILER_WINDOW_POS_X, (float) PROFILER_WINDOW_POS_Y), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(PROFILER_WINDOW_SIZE_X, PROFILER_WINDOW_SIZE_Y), ImGuiCond_FirstUseEver);
        ImGui::Begin("PROFILER");

        ImGui::Text("Resolution : %ix%i", W, H);
        ImGui::Text("API        : %s", system_info_.APIVersion.c_str());
        ImGui::Text("GPU        : %s", system_info_.GPUName.c_str());
        ImGui::Text("CPU        : %s", system_info_.CPUName.c_str());
        ImGui::Text("FPS        : %d (%.2f ms)", fps, frameTime_ms);

        if (ImGui::CollapsingHeader("GPU Timings", ImGuiTreeNodeFlags_DefaultOpen)) {
            // WARNING: If validation layer is switched on, the performance numbers may be inaccurate!

            static bool bShowMilliseconds = true;
            std::string msOrUsButtonText  = bShowMilliseconds ? "Switch to microseconds(us)" : "Switch to milliseconds(ms)";
            if (ImGui::Button(msOrUsButtonText.c_str())) {
                bShowMilliseconds = !bShowMilliseconds;
            }
            ImGui::Spacing();

            ImGui::PlotLines("",
                             FrameTimeRecords.data(),
                             RecordCount,
                             0,
                             "GPU frame time (us)",
                             RecentLowestFrameTime,
                             RecentHighestFrameTime,
                             ImVec2(0, 80));

            for (const auto& timeStamp : timeStamps) {
                float value = bShowMilliseconds ? timeStamp.microseconds * 0.001f : timeStamp.microseconds;
                const char* strUnit = bShowMilliseconds ? "ms" : "us";
                ImGui::Text("%-18s: %7.2f %s", timeStamp.label.c_str(), value, strUnit);
            }
        }
        ImGui::End(); // PROFILER
    }
}

} // yu::vk
