﻿//
// Created by 秋鱼 on 2022/6/12.
//

#include "dynamic_buffer.hpp"
#include "error.hpp"
#include <San/utils/math_utils.hpp>
#include <common/math_utils.hpp>

namespace yu::vk {

void DynamicBuffer::create(VkDevice device, VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
                           VmaAllocator allocator,
#endif
                           uint32_t numberOfFrames, uint32_t totalSize, std::string_view name)
{
    device_ = device;

    total_size_ = static_cast<uint64_t>(AlignUp(totalSize, 256u));

    mem_.create(numberOfFrames, static_cast<uint32_t>(total_size_));

    // 创建一个可用于处理 uniform、索引、顶点数据的缓冲区
#ifdef USE_VMA
    allocator_ = allocator;
    VK_CHECK(CreateBufferVMA(VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                             total_size_,
                             allocator_,
                             VMA_MEMORY_USAGE_CPU_TO_GPU,
                             &buffer_,
                             &buffer_allocation_,
                             (void**) &data_,
                             name));
#else
    VK_CHECK(CreateBuffer(device,
                          physicalDevice,
                          VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                          VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                          total_size_,
                          &buffer_,
                          &device_memory_,
                          false,
                          (void**) &data_));
#endif
}

void DynamicBuffer::destroy()
{
#ifdef USE_VMA
    vmaUnmapMemory(allocator_, buffer_allocation_);
    vmaDestroyBuffer(allocator_, buffer_, buffer_allocation_);

    buffer_            = VK_NULL_HANDLE;
    buffer_allocation_ = VK_NULL_HANDLE;
#else
    vkUnmapMemory(device_, device_memory_);
    vkFreeMemory(device_, device_memory_, nullptr);
    vkDestroyBuffer(device_, buffer_, nullptr);

    buffer_        = VK_NULL_HANDLE;
    device_memory_ = VK_NULL_HANDLE;
#endif

    mem_.destroy();
}

bool DynamicBuffer::allocBuffer(uint32_t size, void** data, VkDescriptorBufferInfo& descOut)
{
    size = AlignUp(size, 256u);

    // 获取分配内存的起始偏移
    uint32_t offset;
    if (!mem_.alloc(size, &offset)) {
        LOG_FATAL("Out of memory of 'Dynamic Buffer', please increase the buffer size.");
        return false;
    }

    // 让 data 指向分配内存的起始位置
    *data = static_cast<void*>(data_ + offset);

    descOut.buffer = buffer_;
    descOut.offset = offset;
    descOut.range  = size;

    return true;
}

VkDescriptorBufferInfo DynamicBuffer::allocBuffer(uint32_t size, void* data)
{
    void* temp = nullptr;
    VkDescriptorBufferInfo descBufferInfo{};
    if (allocBuffer(size, &temp, descBufferInfo)) {
        std::memcpy(temp, data, size);
    }

    return descBufferInfo;
}

void DynamicBuffer::setDescriptorSet(uint32_t bindIndex, uint32_t size, VkDescriptorSet descriptorSet)
{
    VkDescriptorBufferInfo descBufferInfo{};
    descBufferInfo.buffer = buffer_;
    descBufferInfo.offset = 0;
    descBufferInfo.range  = size;

    VkWriteDescriptorSet writeDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    writeDescriptorSet.dstSet          = descriptorSet;
    writeDescriptorSet.descriptorType  = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC;
    writeDescriptorSet.dstBinding      = bindIndex;
    writeDescriptorSet.pBufferInfo     = &descBufferInfo;
    writeDescriptorSet.descriptorCount = 1;

    vkUpdateDescriptorSets(device_, 1, &writeDescriptorSet, 0, nullptr);
}

void DynamicBuffer::beginFrame()
{
    mem_.beginFrame();
}

VkWriteDescriptorSet DynamicBuffer::setWriteDescriptorSet(uint32_t bindIndex, uint32_t size, VkDescriptorSet descriptorSet)
{
    VkDescriptorBufferInfo descBufferInfo{};
    descBufferInfo.buffer = buffer_;
    descBufferInfo.offset = 0;
    descBufferInfo.range  = size;

    VkWriteDescriptorSet writeDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    writeDescriptorSet.dstSet          = descriptorSet;
    writeDescriptorSet.descriptorType  = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC;
    writeDescriptorSet.dstBinding      = bindIndex;
    writeDescriptorSet.pBufferInfo     = &descBufferInfo;
    writeDescriptorSet.descriptorCount = 1;
    
    return writeDescriptorSet;
}

} // yu::vk
