﻿//
// Created by 秋鱼 on 2022/9/25.
//

#pragma once

#include "resource_allocator.hpp"
#include "commands.hpp"
#include "descriptor_sets.hpp"
namespace yu::vk {

/**
 * @brief 不直接渲染到屏幕的后台缓冲区，而是将内容渲染到帧缓冲区后，通过将缓冲区图像渲染到窗口大小的 “面片(Quad)” 上。方便进行后处理、调色等操作。
 */
class OffScreen
{
public:
    void create(VkDevice device, VkPhysicalDevice physicalDevice, ResourceAllocator* resAlloc, CommandPool* commandPool);
    void destroy();

    void createFramebuffer(const VkExtent2D& size);
    void createPipeline(VkRenderPass renderPass);
    void createDescriptor();
    void updateDescriptorSet();
    void draw(VkCommandBuffer cmdBuf, const VkExtent2D& size);

    const VkRenderPass& renderPass() const { return render_pass_; }
    const VkFramebuffer& frameBuffer() const { return framebuffer_; }
    const TextureVK& colorTexture() const { return color_tex_; }

private:
    VkDevice device_{};
    ResourceAllocator* alloc_{};
    CommandPool      * cmd_pool_{};

    TextureVK color_tex_{};
    TextureVK depth_tex_{};

    DescriptorSetBindings descriptor_set_bindings_;
    VkDescriptorPool      descriptor_pool_{VK_NULL_HANDLE};
    VkDescriptorSetLayout set_layout_{VK_NULL_HANDLE};
    VkDescriptorSet       descriptor_set_{VK_NULL_HANDLE};
    VkPipeline            pipeline_{VK_NULL_HANDLE};
    VkPipelineLayout      pipeline_layout_{VK_NULL_HANDLE};
    VkRenderPass          render_pass_{VK_NULL_HANDLE};
    VkFramebuffer         framebuffer_{VK_NULL_HANDLE};
};

} // yu::vk