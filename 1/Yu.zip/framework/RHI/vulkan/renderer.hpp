﻿//
// Created by 秋鱼 on 2022/9/2.
//

#pragma once

#include <common/mouse_tracker.hpp>
#include "commands.hpp"
#include "resource_allocator.hpp"
#include "gpu_time.hpp"
#include "imgui.hpp"

namespace yu::vk {

class Renderer
{
public:
    virtual ~Renderer();

    virtual void create(const Context* context, const MouseTracker* mouseTracker, SwapChain* swapChain);

    // 用于删除子类资源
    virtual void destroy() {};

    virtual void resize(uint32_t width, uint32_t height);

    void createUI(GLFWwindow* window);

    virtual void buildUI() {}
    
    virtual void prepareRender() {}

    virtual void render() {}

    const std::vector<TimeStamp>& getTimings() const { return time_stamps_; }

    [[nodiscard]] bool isLoadingFinish() const { return loadingFinished; }
    void setReadyToRender(bool value) { readyToRender = value; }

protected:
    const Context     * context_       = nullptr;
    const MouseTracker* mouse_tracker_ = nullptr;
    SwapChain         * swap_chain_    = nullptr;

    std::unique_ptr<CommandPool>       command_pool_       = nullptr;
    std::unique_ptr<FrameCommandPool>  frame_command_pool_ = nullptr;
    std::unique_ptr<ResourceAllocator> res_alloc_          = nullptr;

    VkPipelineCache pipeline_cache_{};
    VkRect2D        scissor_{};
    VkViewport      viewport_{};

    uint32_t width_{};
    uint32_t height_{};

    GPUTimeStamp           gpu_timer_{};
    std::vector<TimeStamp> time_stamps_;

    std::unique_ptr<ImGUI> imGui_ = nullptr;

    bool loadingFinished = false;
    bool readyToRender   = false;
};

} // yu::vk