﻿//
// Created by 秋鱼 on 2022/6/4.
//

#include <logger.hpp>
#include "swap_chain.hpp"
#include "error.hpp"
#include "vulkan_utils.hpp"

namespace yu::vk {

bool SwapChain::create(VkDevice device,
                       VkPhysicalDevice physicalDevice,
                       VkQueue queue,
                       uint32_t queueFamilyIndex,
                       VkSurfaceKHR surface,
                       VkFormat format,
                       VkImageUsageFlags imageUsage)
{
    assert(!device_);
    device_             = device;
    physical_device_    = physicalDevice;
    queue_              = queue;
    queue_family_index_ = queueFamilyIndex;
    surface_            = surface;
    image_usage_flags_  = imageUsage;

    // 查询设备中的格式，并设置交换链的格式和颜色空间
    {
        uint32_t formatCount;
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device_, surface_, &formatCount, nullptr));

        std::vector<VkSurfaceFormatKHR> surfFormats(formatCount);
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(physical_device_, surface_, &formatCount, surfFormats.data()));

        bool          found = false;
        for (uint32_t i     = 0; i < formatCount; i++) {
            if (surfFormats[i].format == format) {
                surface_format_ = format;
                surface_color_  = surfFormats[i].colorSpace;
                found           = true;
                break;
            }
        }

        // 设备中没有预期的格式
        if (!found) {
            LOG_ERROR("No proper surface format to create swapchain.");
            return false;
        }
    }

    // 查询并设置交换链中图像的格式
    {
        auto feature = VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT;
        for (const auto& f : {VK_FORMAT_D24_UNORM_S8_UINT, VK_FORMAT_D32_SFLOAT_S8_UINT, VK_FORMAT_D16_UNORM_S8_UINT}) {
            VkFormatProperties formatProp{VK_STRUCTURE_TYPE_FORMAT_PROPERTIES_2};
            vkGetPhysicalDeviceFormatProperties(physical_device_, f, &formatProp);
            if ((formatProp.optimalTilingFeatures & feature) == feature) {
                depth_format_ = f;
                break;
            }
        }
    }

    // 创建每一帧用于同步的 fence 和信号量
    {
        frame_sync_entries_.resize(back_buffer_count_);

        // 让创建的 fence 一开始就是 signal 的状态
        VkFenceCreateInfo fenceCreateInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        fenceCreateInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT;

        VkSemaphoreCreateInfo semaphoreCreateInfo{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};

        for (uint32_t i = 0; i < back_buffer_count_; i++) {
            auto& entry = frame_sync_entries_[i];

            VK_CHECK(vkCreateFence(device_, &fenceCreateInfo, nullptr, &entry.fence));
            VK_CHECK(vkCreateSemaphore(device_, &semaphoreCreateInfo, nullptr, &entry.imageAvailableSemaphore));
            VK_CHECK(vkCreateSemaphore(device_, &semaphoreCreateInfo, nullptr, &entry.renderFinishedSemaphore));
        }
    }

    return true;
}

void SwapChain::destroy()
{
    destroyResource();

    if (swapchain_ != VK_NULL_HANDLE) {
        vkDestroySwapchainKHR(device_, swapchain_, nullptr);
        swapchain_ = VK_NULL_HANDLE;
    }

    for (uint32_t i = 0; i < back_buffer_count_; i++) {
        auto& entry = frame_sync_entries_[i];
        vkDestroyFence(device_, entry.fence, nullptr);
        vkDestroySemaphore(device_, entry.imageAvailableSemaphore, nullptr);
        vkDestroySemaphore(device_, entry.renderFinishedSemaphore, nullptr);
    }
}

void SwapChain::destroyResource()
{
    VK_CHECK(vkDeviceWaitIdle(device_));

    for (auto it : image_entries_) {
        vkDestroyImageView(device_, it.imageView, nullptr);
    }
    image_entries_.clear();

    if (depth_image_) {
        vkDestroyImage(device_, depth_image_, nullptr);
    }

    if (depth_view_) {
        vkDestroyImageView(device_, depth_view_, nullptr);
    }

    if (depth_memory_) {
        vkFreeMemory(device_, depth_memory_, nullptr);
    }

    if (render_pass_ != VK_NULL_HANDLE) {
        vkDestroyRenderPass(device_, render_pass_, nullptr);
        render_pass_ = VK_NULL_HANDLE;
    }

    for (auto& fmBuffer : frame_buffers_) {
        vkDestroyFramebuffer(device_, fmBuffer, nullptr);
    }
    frame_buffers_.clear();
}

VkExtent2D SwapChain::update(uint32_t width, uint32_t height, bool vsync)
{    // 可能会进行一些资源重用
    VkSwapchainKHR oldSwapchain = swapchain_;

    VK_CHECK(vkDeviceWaitIdle(device_));

    // 查询 surface 的一些信息，主要是窗口的大小
    VkSurfaceCapabilitiesKHR surfCapabilities;
    VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physical_device_, surface_, &surfCapabilities));

    // 交换链的大小
    VkExtent2D swapchainExtent;
    if (surfCapabilities.currentExtent.width == (uint32_t) -1) {
        // 如果 surface 的大小没有设置，使用传入的信息
        swapchainExtent.width  = width;
        swapchainExtent.height = height;
    } else {
        // 如果 surface 的大小已经设置，那么其大小作为交换链的大小
        swapchainExtent = surfCapabilities.currentExtent;
    }
    assert(swapchainExtent.width && swapchainExtent.height);
    extent_ = swapchainExtent;

    // 找到一个支持的组合透明度的格式（不是所有设备都支持 alpha 不透明）
    VkCompositeAlphaFlagBitsKHR              compositeAlpha      = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    // 选择第一个可用的组合透明度格式
    std::vector<VkCompositeAlphaFlagBitsKHR> compositeAlphaFlags = {
        VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
        VK_COMPOSITE_ALPHA_PRE_MULTIPLIED_BIT_KHR,
        VK_COMPOSITE_ALPHA_POST_MULTIPLIED_BIT_KHR,
        VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR,
    };
    for (auto& compositeAlphaFlag : compositeAlphaFlags) {
        if (surfCapabilities.supportedCompositeAlpha & compositeAlphaFlag) {
            compositeAlpha = compositeAlphaFlag;
            break;
        }
    }

    // 查询设备中可用的呈现模式
    uint32_t presentModeCount;
    VK_CHECK(vkGetPhysicalDeviceSurfacePresentModesKHR(physical_device_, surface_, &presentModeCount, nullptr));
    std::vector<VkPresentModeKHR> presentModes(presentModeCount);
    VK_CHECK(vkGetPhysicalDeviceSurfacePresentModesKHR(physical_device_, surface_, &presentModeCount, presentModes.data()));

    // 默认使用 FIFO 模式
    VkPresentModeKHR swapchainPresentMode = VK_PRESENT_MODE_FIFO_KHR;
    // 如果不进行同步，尝试使用更高性能的呈现模式
    if (!vsync) {
        for (uint32_t i = 0; i < presentModeCount; i++) {
            if (presentModes[i] == VK_PRESENT_MODE_MAILBOX_KHR) {
                // prefer mailbox due to no tearing
                swapchainPresentMode = VK_PRESENT_MODE_MAILBOX_KHR;
                break;
            }
            if (presentModes[i] == VK_PRESENT_MODE_IMMEDIATE_KHR) {
                swapchainPresentMode = VK_PRESENT_MODE_IMMEDIATE_KHR;
            }
        }
    }

    // 决定交换链中的图像数量
    uint32_t desiredNumberOfSwapchainImages = surfCapabilities.minImageCount + 1;
    if ((surfCapabilities.maxImageCount > 0) && (desiredNumberOfSwapchainImages > surfCapabilities.maxImageCount)) {
        // 图像的数量要在范围内
        desiredNumberOfSwapchainImages = surfCapabilities.maxImageCount;
    }

    // surface 的变换模式
    VkSurfaceTransformFlagBitsKHR preTransform;
    if (surfCapabilities.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR) {
        preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR;
    } else {
        preTransform = surfCapabilities.currentTransform;
    }

    // 创建交换链
    VkSwapchainCreateInfoKHR swapchain = {VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    swapchain.surface               = surface_;
    swapchain.minImageCount         = desiredNumberOfSwapchainImages;
    swapchain.imageFormat           = surface_format_;
    swapchain.imageColorSpace       = surface_color_;
    swapchain.imageExtent           = swapchainExtent;
    swapchain.imageUsage            = image_usage_flags_;
    swapchain.preTransform          = preTransform;
    swapchain.compositeAlpha        = compositeAlpha;
    swapchain.imageArrayLayers      = 1;
    swapchain.imageSharingMode      = VK_SHARING_MODE_EXCLUSIVE;
    swapchain.queueFamilyIndexCount = 1;
    swapchain.pQueueFamilyIndices   = &queue_family_index_;
    swapchain.presentMode           = swapchainPresentMode;
    swapchain.oldSwapchain          = oldSwapchain;
    // 将clipped设置为VK_TRUE，允许实现放弃 surface 区域以外的渲染
    swapchain.clipped               = VK_TRUE;

    VK_CHECK(vkCreateSwapchainKHR(device_, &swapchain, nullptr, &swapchain_));

    // 如果一个现有的交换链被重新创建，那么需要销毁旧的交换链。不过这也会对所有相关资源被清理
    if (oldSwapchain != VK_NULL_HANDLE) {
        destroyResource();

        vkDestroySwapchainKHR(device_, oldSwapchain, nullptr);
    }

    createSwapChainImages();
    createRenderPass();
    createFrameBuffer();

    // 重置一些信息
    vsync_  = vsync;
    extent_ = swapchainExtent;

    image_index_   = 0;
    current_frame_ = 0;

    return swapchainExtent;
}

void SwapChain::createSwapChainImages()
{
    // 创建交换链中的图像
    VK_CHECK(vkGetSwapchainImagesKHR(device_, swapchain_, &image_count_, nullptr));
    image_entries_.resize(image_count_);

    std::vector<VkImage> images(image_count_);
    VK_CHECK(vkGetSwapchainImagesKHR(device_, swapchain_, &image_count_, images.data()));

    // 图像视图
    for (uint32_t i = 0; i < image_count_; i++) {
        ImageEntry& entry = image_entries_[i];

        entry.image = images[i];
        VkImageViewCreateInfo viewCreateInfo = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
                                                nullptr,
                                                0,
                                                entry.image,
                                                VK_IMAGE_VIEW_TYPE_2D,
                                                surface_format_,
                                                {VK_COMPONENT_SWIZZLE_R, VK_COMPONENT_SWIZZLE_G, VK_COMPONENT_SWIZZLE_B, VK_COMPONENT_SWIZZLE_A},
                                                {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1}};

        VK_CHECK(vkCreateImageView(device_, &viewCreateInfo, nullptr, &entry.imageView));
    }

    // 深度图像、视图、内存
    {
        VkImageCreateInfo imageCreateInfo{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        imageCreateInfo.imageType     = VK_IMAGE_TYPE_2D;
        imageCreateInfo.extent.width  = extent_.width;
        imageCreateInfo.extent.height = extent_.height;
        imageCreateInfo.extent.depth  = 1;
        imageCreateInfo.mipLevels     = 1;
        imageCreateInfo.arrayLayers   = 1;
        imageCreateInfo.format        = depth_format_;
        imageCreateInfo.tiling        = VK_IMAGE_TILING_OPTIMAL;
        imageCreateInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        imageCreateInfo.usage         = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        imageCreateInfo.samples       = VK_SAMPLE_COUNT_1_BIT;
        imageCreateInfo.sharingMode   = VK_SHARING_MODE_EXCLUSIVE;

        VK_CHECK(vkCreateImage(device_, &imageCreateInfo, nullptr, &depth_image_));

        VkMemoryRequirements memReqs;
        vkGetImageMemoryRequirements(device_, depth_image_, &memReqs);

        VkMemoryAllocateInfo memAllocInfo{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        memAllocInfo.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        memAllocInfo.allocationSize  = memReqs.size;
        memAllocInfo.memoryTypeIndex = GetMemoryType(physical_device_, memReqs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

        VK_CHECK(vkAllocateMemory(device_, &memAllocInfo, nullptr, &depth_memory_));
        vkBindImageMemory(device_, depth_image_, depth_memory_, 0);

        VkImageViewCreateInfo viewCreateInfo{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        viewCreateInfo.viewType         = VK_IMAGE_VIEW_TYPE_2D;
        viewCreateInfo.format           = depth_format_;
        viewCreateInfo.image            = depth_image_;
        viewCreateInfo.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};

        VK_CHECK(vkCreateImageView(device_, &viewCreateInfo, nullptr, &depth_view_));

    }
}

void SwapChain::createRenderPass()
{
    assert(render_pass_ == VK_NULL_HANDLE);

    std::array<VkAttachmentDescription, 2> attachments{};
    // Color attachment
    attachments[0].format      = surface_format_;
    attachments[0].loadOp      = VK_ATTACHMENT_LOAD_OP_CLEAR;
    attachments[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    attachments[0].samples     = VK_SAMPLE_COUNT_1_BIT;

    // Depth attachment
    attachments[1].format        = depth_format_;
    attachments[1].loadOp        = VK_ATTACHMENT_LOAD_OP_CLEAR;
    attachments[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    attachments[1].finalLayout   = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    attachments[1].samples       = VK_SAMPLE_COUNT_1_BIT;

    // One color, one depth
    const VkAttachmentReference colorReference{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    const VkAttachmentReference depthReference{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};

    std::array<VkSubpassDependency, 1> subpassDependencies{};
    // Transition from final to initial (VK_SUBPASS_EXTERNAL refers to all commands executed outside of the actual renderpass)
    subpassDependencies[0].srcSubpass      = VK_SUBPASS_EXTERNAL;
    subpassDependencies[0].dstSubpass      = 0;
    subpassDependencies[0].srcStageMask    = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
    subpassDependencies[0].dstStageMask    = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    subpassDependencies[0].srcAccessMask   = VK_ACCESS_MEMORY_READ_BIT;
    subpassDependencies[0].dstAccessMask   = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    subpassDependencies[0].dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;

    VkSubpassDescription subpassDescription{};
    subpassDescription.pipelineBindPoint       = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpassDescription.colorAttachmentCount    = 1;
    subpassDescription.pColorAttachments       = &colorReference;
    subpassDescription.pDepthStencilAttachment = &depthReference;

    VkRenderPassCreateInfo renderPassInfo{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    renderPassInfo.attachmentCount = static_cast<uint32_t>(attachments.size());
    renderPassInfo.pAttachments    = attachments.data();
    renderPassInfo.subpassCount    = 1;
    renderPassInfo.pSubpasses      = &subpassDescription;
    renderPassInfo.dependencyCount = static_cast<uint32_t>(subpassDependencies.size());
    renderPassInfo.pDependencies   = subpassDependencies.data();

    vkCreateRenderPass(device_, &renderPassInfo, nullptr, &render_pass_);
}

void SwapChain::createFrameBuffer()
{
    // attachment 数组 (颜色, 深度)
    std::array<VkImageView, 2> attachments{};

    VkFramebufferCreateInfo framebufferCreateInfo{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    framebufferCreateInfo.renderPass      = render_pass_;
    framebufferCreateInfo.attachmentCount = 2;
    framebufferCreateInfo.width           = extent_.width;
    framebufferCreateInfo.height          = extent_.height;
    framebufferCreateInfo.layers          = 1;
    framebufferCreateInfo.pAttachments    = attachments.data();

    // 为每个交换链的图像创建一个帧缓冲区
    frame_buffers_.resize(image_count_);
    for (uint32_t i = 0; i < image_count_; i++) {
        attachments[0] = getImageView(i);
        attachments[1] = depth_view_;
        vkCreateFramebuffer(device_, &framebufferCreateInfo, nullptr, &frame_buffers_[i]);
    }
}

uint32_t SwapChain::acquire(SwapChainAcquireState* pOut)
{
    auto fence = getFence(current_frame_);
    vkWaitForFences(device_, 1, &fence, VK_TRUE, UINT64_MAX);

    auto readSemaphore = getWaitSemaphore(current_frame_);
    VK_CHECK(vkAcquireNextImageKHR(device_,
                                   swapchain_,
                                   UINT64_MAX,
                                   readSemaphore,
                                   VK_NULL_HANDLE,
                                   &image_index_));

    vkResetFences(device_, 1, &fence);

    return image_index_;
}

void SwapChain::submit(VkQueue queue, VkCommandBuffer cmdBuffer, VkPipelineStageFlags submitWaitStage) const
{
    auto waitSemaphore   = getWaitSemaphore();
    auto signalSemaphore = getSignalSemaphore();
    auto fence           = getFence();

    VkSubmitInfo submitInfo{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submitInfo.waitSemaphoreCount   = 1;
    submitInfo.pWaitSemaphores      = &waitSemaphore;
    submitInfo.pWaitDstStageMask    = &submitWaitStage;
    submitInfo.commandBufferCount   = 1;
    submitInfo.pCommandBuffers      = &cmdBuffer;
    submitInfo.signalSemaphoreCount = 1;
    submitInfo.pSignalSemaphores    = &signalSemaphore;

    VK_CHECK(vkQueueSubmit(queue, 1, &submitInfo, fence));
}

/**
 * @brief 向 present 队列提交呈现当帧到屏幕的命令，等待原语的意义是：等到当前帧完成了渲染，那么就把它呈现到屏幕上
 * @return 提交的结果，把提交到队列的结果返回，让调用者决定之后的操作
 */
VkResult SwapChain::present()
{
    auto signalSemaphore = getSignalSemaphore();

    VkPresentInfoKHR presentInfo{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
    presentInfo.pNext              = nullptr;
    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pWaitSemaphores    = &signalSemaphore;
    presentInfo.swapchainCount     = 1;
    presentInfo.pSwapchains        = &swapchain_;
    // image_index 是当前渲染的图像索引
    presentInfo.pImageIndices      = &image_index_;
    presentInfo.pResults           = nullptr;

    // 切换至下一帧
    prev_frame_    = current_frame_;
    current_frame_ = (current_frame_ + 1) % back_buffer_count_;

    VkResult res = vkQueuePresentKHR(queue_, &presentInfo);
    return res;
}

} // yu::vk
