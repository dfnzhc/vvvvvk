﻿//
// Created by 秋鱼 on 2022/9/25.
//

#include "off_screen.hpp"
#include "vulkan_utils.hpp"
#include "pipeline.hpp"

namespace yu::vk {

void OffScreen::create(VkDevice device, VkPhysicalDevice physicalDevice, ResourceAllocator* resAlloc, CommandPool* commandPool)
{
    device_   = device;
    alloc_    = resAlloc;
    cmd_pool_ = commandPool;

    color_tex_.format = VK_FORMAT_R32G32B32A32_SFLOAT;
    depth_tex_.format = GetDepthFormat(physicalDevice);
}

void OffScreen::destroy()
{
    vkDestroyPipeline(device_, pipeline_, nullptr);
    vkDestroyPipelineLayout(device_, pipeline_layout_, nullptr);
    vkDestroyDescriptorPool(device_, descriptor_pool_, nullptr);
    vkDestroyDescriptorSetLayout(device_, set_layout_, nullptr);
    vkDestroyRenderPass(device_, render_pass_, nullptr);
    vkDestroyFramebuffer(device_, framebuffer_, nullptr);

    color_tex_.destroy();
    depth_tex_.destroy();
}

void OffScreen::createFramebuffer(const VkExtent2D& size)
{
    if (color_tex_.image) {
        color_tex_.destroy();
    }
    if (depth_tex_.image) {
        depth_tex_.destroy();
    }

    // 创建颜色图像
    {
        color_tex_ = alloc_->createTexture(size,
                                           color_tex_.format,
                                           VK_IMAGE_ASPECT_COLOR_BIT,
                                           VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT,
                                           VK_IMAGE_LAYOUT_GENERAL,
                                           "Off-Screen color image");
    }


    // Creating the depth buffer
    {
        depth_tex_ = alloc_->createTexture(size,
                                           depth_tex_.format,
                                           VK_IMAGE_ASPECT_DEPTH_BIT,
                                           VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                                           VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                                           "Off-Screen depth image");
    }

    // Creating a renderpass for the offscreen
    if (!render_pass_) {
        render_pass_ = CreateRenderPass(device_, {color_tex_.format}, depth_tex_.format, true, true,
                                        VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_GENERAL);
    }

    // Creating the frame buffer for offscreen
    std::vector<VkImageView> attachments = {color_tex_.descriptor.imageView, depth_tex_.descriptor.imageView};

    if (framebuffer_) {
        vkDestroyFramebuffer(device_, framebuffer_, nullptr);
    }
    VkFramebufferCreateInfo info{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    info.renderPass      = render_pass_;
    info.attachmentCount = 2;
    info.pAttachments    = attachments.data();
    info.width           = size.width;
    info.height          = size.height;
    info.layers          = 1;
    vkCreateFramebuffer(device_, &info, nullptr, &framebuffer_);
}

void OffScreen::createPipeline(VkRenderPass renderPass)
{
    // Push constants in the fragment shader
    VkPushConstantRange pushConstantRanges = {VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(float)};

    // Creating the pipeline layout
    VkPipelineLayoutCreateInfo pipelineLayoutCreateInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pipelineLayoutCreateInfo.setLayoutCount         = 1;
    pipelineLayoutCreateInfo.pSetLayouts            = &set_layout_;
    pipelineLayoutCreateInfo.pushConstantRangeCount = 1;
    pipelineLayoutCreateInfo.pPushConstantRanges    = &pushConstantRanges;
    vkCreatePipelineLayout(device_, &pipelineLayoutCreateInfo, nullptr, &pipeline_layout_);

    // Pipeline: completely generic, no vertices
    GraphicsPipelineGeneratorCombined pipelineGenerator(device_, pipeline_layout_, renderPass);
    pipelineGenerator.addShader("OffScreen.vert", VK_SHADER_STAGE_VERTEX_BIT);
    pipelineGenerator.addShader("OffScreen.frag", VK_SHADER_STAGE_FRAGMENT_BIT);
    pipelineGenerator.rasterizationState.cullMode = VK_CULL_MODE_NONE;

    pipeline_ = pipelineGenerator.createPipeline();
}

void OffScreen::createDescriptor()
{
    descriptor_set_bindings_.addBinding(0, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1, VK_SHADER_STAGE_FRAGMENT_BIT);
    set_layout_      = descriptor_set_bindings_.createLayout(device_);
    descriptor_pool_ = descriptor_set_bindings_.createPool(device_);
    descriptor_set_  = AllocateDescriptorSet(device_, descriptor_pool_, set_layout_);
}

void OffScreen::updateDescriptorSet()
{
    VkWriteDescriptorSet writeDescriptorSets = descriptor_set_bindings_.makeWrite(descriptor_set_, 0, &color_tex_.descriptor);
    vkUpdateDescriptorSets(device_, 1, &writeDescriptorSets, 0, nullptr);
}

void OffScreen::draw(VkCommandBuffer cmdBuf, const VkExtent2D& size)
{
    VkViewport viewport{0, 0, (float) size.width, (float) size.height, 0, 1};
    vkCmdSetViewport(cmdBuf, 0, 1, &viewport);
    VkRect2D scissor{{0, 0}, {size.width, size.height}};
    vkCmdSetScissor(cmdBuf, 0, 1, &scissor);

    auto aspectRatio = static_cast<float>(size.width) / static_cast<float>(size.height);
    vkCmdPushConstants(cmdBuf, pipeline_layout_, VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(float), &aspectRatio);
    vkCmdBindPipeline(cmdBuf, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);
    vkCmdBindDescriptorSets(cmdBuf, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_layout_, 0, 1, &descriptor_set_, 0, nullptr);
    vkCmdDraw(cmdBuf, 3, 1, 0, 0);
}

} // yu::vk