﻿//
// Created by 秋鱼 on 2022/6/25.
//

#pragma once

#include <GLFW/glfw3.h>
#include <vulkan/vulkan_core.h>

namespace yu::vk {

class CommandPool;

class ImGUI
{
public:
    ImGUI();
    ~ImGUI();
    void create(VkInstance instance,
                VkDevice device,
                VkPhysicalDevice physicalDevice,
                VkQueue graphicsQueue,
                VkRenderPass renderPass,
                VkPipelineCache pipelineCache,
                GLFWwindow* window,
                CommandPool* cmdPool);
    void destroy();

    void draw(VkCommandBuffer cmdBuffer);

    bool header(const char* caption);
    bool checkBox(const char* caption, bool* value);
    bool checkBox(const char* caption, int32_t* value);
    bool radioButton(const char* caption, bool value);
    bool inputFloat(const char* caption, float* value, float step, uint32_t precision = 2);
    bool sliderFloat(const char* caption, float* value, float min, float max);
    bool sliderInt(const char* caption, int32_t* value, int32_t min, int32_t max);
    bool comboBox(const char* caption, int32_t* itemindex, std::vector<std::string> items);
    bool button(const char* caption);
    void text(const char* formatstr, ...);

private:
    VkDevice         device_{};
    VkDescriptorPool descriptor_pool_{};

    bool bCreated = false;
};

} // yu::vk