﻿//
// Created by 秋鱼 on 2022/8/11.
//

#pragma once

#include <vulkan/vulkan_core.h>

namespace yu::vk {

struct ContextCreateInfo
{
    ContextCreateInfo();

    std::string engineName = "Yu Engine";
    std::string appName    = "Yu Sample";

    uint32_t apiMajor = 1;
    uint32_t apiMinor = 3;

    struct Entry
    {
        Entry(std::string_view entryName, bool isOptional = false, void* pFeatureStruct = nullptr) : name{entryName},
                                                                                                     optional{isOptional},
                                                                                                     featureStruct{pFeatureStruct} {}

        std::string name;
        bool        optional = false;
        void* featureStruct = nullptr;
    };

    using EntryArray = std::vector<Entry>;

    EntryArray instanceLayers;
    EntryArray instanceExtensions;
    EntryArray deviceExtensions;
    void* deviceCreateInfoExt = nullptr;

    bool verboseUsed = true;

    struct QueueSetup
    {
        VkQueueFlags requiredFlags = 0;
        uint32_t     count         = 0;
        float        priority      = 1.0;
    };
    using QueueArray = std::vector<QueueSetup>;

    QueueArray requestedQueues;

    QueueSetup* queueGCT = nullptr;
    QueueSetup* queueT   = nullptr;
    QueueSetup* queueC   = nullptr;
    
public:
    void setVersion(uint32_t major, uint32_t minor);

    void addInstanceLayer(std::string_view name, bool optional = false);
    void addInstanceExtension(std::string_view name, bool optional = false);
    void addDeviceExtension(std::string_view name, bool optional = false, void* pFeatureStruct = nullptr);
};

/**
 * @brief 包含创建 Vulkan 应用程序的一些基础组件，包括 instance、device 等
 */
class Context
{
public:
    Context() = default;

    Context(Context&&) = delete;
    Context(const Context&) = delete;
    Context& operator=(Context&&) = delete;
    Context& operator=(const Context&) = delete;

    bool create(const ContextCreateInfo& info);
    void destroy();

    struct Queue
    {
        VkQueue  queue       = VK_NULL_HANDLE;
        uint32_t familyIndex = static_cast<uint32_t>(~0);
        uint32_t queueIndex  = static_cast<uint32_t>(~0);
        float    priority    = 1.0f;

        operator VkQueue() const { return queue; }
        operator uint32_t() const { return familyIndex; }
    };

    // 这个结构用来记录物理设备的核心功能特性
    struct PhysicalDeviceInfo
    {
        VkPhysicalDeviceMemoryProperties     memoryProperties{};
        std::vector<VkQueueFamilyProperties> queueProperties{};

        VkPhysicalDeviceFeatures         features10{};
        VkPhysicalDeviceVulkan11Features features11{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES};
        VkPhysicalDeviceVulkan12Features features12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};
        VkPhysicalDeviceVulkan13Features features13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};

        VkPhysicalDeviceProperties         properties{};
        VkPhysicalDeviceVulkan11Properties properties11{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_PROPERTIES};
        VkPhysicalDeviceVulkan12Properties properties12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_PROPERTIES};
        VkPhysicalDeviceVulkan13Properties properties13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_PROPERTIES};
    };

    [[nodiscard]] VkInstance getInstance() const { return instance_; };
    [[nodiscard]] VkDevice getDevice() const { return device_; }
    [[nodiscard]] VkPhysicalDevice getPhysicalDevice() const { return physical_device_; }
    [[nodiscard]] PhysicalDeviceInfo getPhysicalDeviceInfo() const { return physical_info_; }
    [[nodiscard]] bool isEnableDebug() const { return enableDebugUtils; }

    [[nodiscard]] Queue getGCTQueue() const { return queueGCT_; }
    [[nodiscard]] Queue getTransferQueue() const { return queueT_; }
    [[nodiscard]] Queue getComputeQueue() const { return queueC_; }

    [[nodiscard]] void checkGCTQueuePresent(VkSurfaceKHR surface) const;

private:
    bool initInstance(const ContextCreateInfo& info);
    std::vector<VkLayerProperties> getInstanceLayers();
    std::vector<VkExtensionProperties> getInstanceExtensions();

    VkResult filterExtensionArray(std::vector<std::string>& used,
                                  const std::vector<VkExtensionProperties>& properties,
                                  const ContextCreateInfo::EntryArray& requested,
                                  std::vector<void*>& featureStructs);

    bool initDevice(const ContextCreateInfo& info);
    void choseBestPhysicalDevice();
    std::vector<VkExtensionProperties> getDeviceExtensions();
    Queue createQueue(VkQueueFlags requiredFlags, const std::string& debugName, float priority = 1.0f);

private:

    VkInstance         instance_        = VK_NULL_HANDLE;
    VkDevice           device_          = VK_NULL_HANDLE;
    VkPhysicalDevice   physical_device_ = VK_NULL_HANDLE;
    PhysicalDeviceInfo physical_info_{};

    uint32_t apiMajor = 0;
    uint32_t apiMinor = 0;

    bool enableDebugUtils = false;

    std::vector<std::string> used_instance_layers_{};
    std::vector<std::string> used_instance_extensions_{};
    std::vector<std::string> used_device_extensions_{};

    Queue queueGCT_;  // for Graphics/Compute/Transfer
    Queue queueT_;    // for pure async Transfer Queue
    Queue queueC_;    // for async Compute

private:

    /**
     * @brief 用来记录设备队列的分数，分数越低，则表示功能越单一
     */
    struct QueueScore
    {
        uint32_t score       = 0;
        uint32_t familyIndex = static_cast<uint32_t>(~0);
        uint32_t queueIndex  = static_cast<uint32_t>(~0);
        float    priority    = 1.0f;
    };
    using QueueScoreList = std::vector<QueueScore>;

    /**
     * @brief 用来记录设备中所有可用的队列分数，用于之后各种队列的创建
     */
    QueueScoreList available_queues_;

    void initQueueList(QueueScoreList& list, const uint32_t* maxFamilyCounts, const float* priorities, uint32_t maxQueueCount) const;
    QueueScore removeQueueListItem(QueueScoreList& list, VkQueueFlags needFlags, float priority) const;
};

} // yu::vk