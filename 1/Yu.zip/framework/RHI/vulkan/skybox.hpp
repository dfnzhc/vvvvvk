﻿//
// Created by 秋鱼 on 2022/9/15.
//

#pragma once

#include "model_gltf.hpp"

namespace yu::vk {

class SkyBox
{
public:
    void create(std::string_view cubeMapFile, VkDevice device, ResourceAllocator* resAlloc);
    void createPipeline(VkRenderPass renderPass, VkPipelineCache pipelineCache);
    
    void destroy();
    
    /**
     * @brief 传入矩阵为投影矩阵和视角矩阵的乘积
     */
    void draw(VkCommandBuffer cmdBuffer, glm::mat4& projView);
    

private:
    VkDevice device_{};
    ResourceAllocator* resource_allocator_ = nullptr;
    
    VkDescriptorSetLayout descriptor_set_layout_{};
    VkDescriptorPool      descriptor_pool_{};
    VkDescriptorSet       descriptor_set_{};
    
    VkPipeline pipeline_{};
    VkPipelineLayout pipeline_layout_{};
    
    ModelGltf cube_model_;
    TextureCube cube_map_;

};

} // yu::vk