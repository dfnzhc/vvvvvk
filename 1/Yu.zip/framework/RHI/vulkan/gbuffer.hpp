﻿//
// Created by 秋鱼 on 2022/6/23.
//

#pragma once

#include "resource_allocator.hpp"
#include "../../../data/shaders/gltfDefines.h"

namespace yu::vk {

enum GBufferFlagBits
{
    GBUFFER_FLAG_NONE     = 0,
    GBUFFER_FLAG_POSITION = 0x00000001, // world position
    GBUFFER_FLAG_ALBEDO   = 0x00000002,
    GBUFFER_FLAG_NORMAL   = 0x00000004,
    GBUFFER_FLAG_EMISSION = 0x00000008,
    GBUFFER_FLAG_SRMO     = 0x00000010,     // roughness, roughness, metallic, opacity
    GBUFFER_FLAG_DEPTH    = 0x00000020,
    GBUFFER_FLAG_ALL      = 0x7FFFFFFF,
};

using GBufferFlags = uint32_t;

class GBuffer
{
public:
    void create(VkDevice device, ResourceAllocator* resAlloc, const std::map<GBufferFlags, VkFormat>& formats = {});
    void destroy();

    void resize(uint32_t width, uint32_t height);
    VkRenderPass createRenderPass(GBufferFlags flags, bool bClear);
    void getAttachments(GBufferFlags flags, std::vector<VkImageView>* pAttachments, std::vector<VkClearValue>* pClearVal);

    TextureVK position;
    TextureVK albedo;
    TextureVK normal;
    TextureVK depth;
    TextureVK emission;
    TextureVK srmo;
private:
    VkDevice device_{};
    ResourceAllocator* alloc_{};

    VkExtent2D size_{};

    GBufferFlags                     buffer_flags_{};
    std::map<GBufferFlags, VkFormat> formats_;
};

class GBufferRenderPass
{
public:
    void create(VkDevice device, GBuffer* gBuffer, GBufferFlags flags, bool bClear);
    void destroy();

    void resize(uint32_t width, uint32_t height);
    void beginPass(VkCommandBuffer cmdBuffer, VkRect2D renderArea);
    void endPass(VkCommandBuffer cmdBuffer);

    void getAttachmentsDescriptor(std::vector<VkDescriptorImageInfo>& descInfos);
    void setAttachmentsIndex(PushConstantRasterGLTF& constInfo);

    [[nodiscard]] VkRenderPass getRenderPass() { return render_pass_; }
    [[nodiscard]] VkFramebuffer getFrameBuffer() { return frame_buffer_; }
    [[nodiscard]] GBuffer* getGBuffer() { return g_buffer_; }
    [[nodiscard]] uint32_t getAttachmentsCount() { return attachments_count_; }

private:
    VkDevice                  device_{};
    VkRenderPass              render_pass_{};
    VkFramebuffer             frame_buffer_{};
    std::vector<VkClearValue> clear_values_;

    GBuffer* g_buffer_ = nullptr;
    GBufferFlags flags_{};

    uint32_t attachments_count_{};
};

} // yu::vk