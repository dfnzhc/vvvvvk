﻿//
// Created by 秋鱼 on 2022/6/23.
//

#include "gbuffer.hpp"
#include "vulkan_utils.hpp"

namespace yu::vk {

void CreateGBufferAttachment(TextureVK& texture, ResourceAllocator* resAlloc, VkExtent2D size,
                             VkFormat format, VkImageUsageFlagBits usage, std::string_view name)
{
    if (texture.image) {
        texture.destroy();
    }

    VkImageAspectFlags aspectMask{VK_IMAGE_ASPECT_NONE};
    VkImageLayout      imageLayout{};

    if (usage & VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT) {
        aspectMask  = VK_IMAGE_ASPECT_COLOR_BIT;
        imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    } else if (usage & VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT) {
        aspectMask  = VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT;
        imageLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    }

    assert(aspectMask != VK_IMAGE_ASPECT_NONE && "Not support usage.");

    texture = resAlloc->createTexture(size,
                                      format,
                                      aspectMask,
                                      usage | VK_IMAGE_USAGE_SAMPLED_BIT,
                                      imageLayout,
                                      name);
}

////////////////////////////////////////////////////////////////////////////////////////////

void GBuffer::create(VkDevice device, ResourceAllocator* resAlloc, const std::map<GBufferFlags, VkFormat>& formats)
{
    device_ = device;
    alloc_  = resAlloc;

    if (formats.empty()) {
        formats_ = {
            {GBUFFER_FLAG_POSITION, VK_FORMAT_R16G16B16A16_SFLOAT},
            {GBUFFER_FLAG_ALBEDO, VK_FORMAT_R8G8B8A8_UNORM},
            {GBUFFER_FLAG_NORMAL, VK_FORMAT_R16G16B16A16_SFLOAT},
            {GBUFFER_FLAG_DEPTH, resAlloc->getDepthFormat()},
            {GBUFFER_FLAG_EMISSION, VK_FORMAT_R8G8B8A8_UNORM},
            {GBUFFER_FLAG_SRMO, VK_FORMAT_R16G16B16A16_SFLOAT},
        };
    } else {
        formats_ = formats;
    }

    buffer_flags_ = GBUFFER_FLAG_NONE;
    for (auto& ff : formats_) {
        buffer_flags_ |= ff.first;
    }

}

void GBuffer::destroy()
{
    if (position.image) {
        position.destroy();
    }

    if (albedo.image) {
        albedo.destroy();
    }

    if (normal.image) {
        normal.destroy();
    }

    if (depth.image) {
        depth.destroy();
    }

    if (emission.image) {
        emission.destroy();
    }

    if (srmo.image) {
        srmo.destroy();
    }
}

void GBuffer::resize(uint32_t width, uint32_t height)
{
    size_ = {width, height};

    if (buffer_flags_ & GBUFFER_FLAG_POSITION) {
        CreateGBufferAttachment(position, alloc_, size_, formats_[GBUFFER_FLAG_POSITION], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, "Position");
    }

    if (buffer_flags_ & GBUFFER_FLAG_ALBEDO) {
        CreateGBufferAttachment(albedo, alloc_, size_, formats_[GBUFFER_FLAG_ALBEDO], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, "Albedo");
    }

    if (buffer_flags_ & GBUFFER_FLAG_NORMAL) {
        CreateGBufferAttachment(normal, alloc_, size_, formats_[GBUFFER_FLAG_NORMAL], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, "Normal");
    }

    if (buffer_flags_ & GBUFFER_FLAG_EMISSION) {
        CreateGBufferAttachment(emission, alloc_, size_, formats_[GBUFFER_FLAG_EMISSION], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, "Emission");
    }

    if (buffer_flags_ & GBUFFER_FLAG_SRMO) {
        CreateGBufferAttachment(srmo,
                                alloc_,
                                size_,
                                formats_[GBUFFER_FLAG_SRMO],
                                VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
                                "SRMO");
    }

    if (buffer_flags_ & GBUFFER_FLAG_DEPTH) {
        CreateGBufferAttachment(depth, alloc_, size_, formats_[GBUFFER_FLAG_DEPTH], VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, "Depth");
    }
}

VkRenderPass GBuffer::createRenderPass(GBufferFlags flags, bool bClear)
{
    std::vector<VkFormat> colorFormats;
    VkFormat              depthFormat = VK_FORMAT_UNDEFINED;

    if (buffer_flags_ & GBUFFER_FLAG_POSITION) {
        colorFormats.push_back(formats_[GBUFFER_FLAG_POSITION]);
    }

    if (buffer_flags_ & flags & GBUFFER_FLAG_ALBEDO) {
        colorFormats.push_back(formats_[GBUFFER_FLAG_ALBEDO]);
    }

    if (buffer_flags_ & flags & GBUFFER_FLAG_NORMAL) {
        colorFormats.push_back(formats_[GBUFFER_FLAG_NORMAL]);
    }
    
    if (buffer_flags_ & GBUFFER_FLAG_EMISSION) {
        colorFormats.push_back(formats_[GBUFFER_FLAG_EMISSION]);
    }

    if (buffer_flags_ & flags & GBUFFER_FLAG_SRMO) {
        colorFormats.push_back(formats_[GBUFFER_FLAG_SRMO]);
    }

    if (buffer_flags_ & flags & GBUFFER_FLAG_DEPTH) {
        depthFormat = formats_[GBUFFER_FLAG_DEPTH];
    }

    VkImageLayout previousColor = bClear ? VK_IMAGE_LAYOUT_UNDEFINED : VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkRenderPass renderPass = CreateRenderPass(device_, colorFormats, depthFormat, bClear, bClear,
                                               previousColor, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);

    return renderPass;
}

void GBuffer::getAttachments(GBufferFlags flags, std::vector<VkImageView>* pAttachments, std::vector<VkClearValue>* pClearVal)
{
    if (buffer_flags_ & GBUFFER_FLAG_POSITION) {
        pAttachments->push_back(position.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.color = {0.0f, 0.0f, 0.0f, 0.0f};
            pClearVal->push_back(cv);
        }
    }

    if (flags & GBUFFER_FLAG_ALBEDO) {
        pAttachments->push_back(albedo.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.color = {0.0f, 0.0f, 0.0f, 0.0f};
            pClearVal->push_back(cv);
        }
    }

    if (flags & GBUFFER_FLAG_NORMAL) {
        pAttachments->push_back(normal.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.color = {0.0f, 0.0f, 0.0f, 0.0f};
            pClearVal->push_back(cv);
        }
    }

    if (buffer_flags_ & GBUFFER_FLAG_EMISSION) {
        pAttachments->push_back(emission.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.color = {0.0f, 0.0f, 0.0f, 0.0f};
            pClearVal->push_back(cv);
        }
    }

    if (flags & GBUFFER_FLAG_SRMO) {
        pAttachments->push_back(srmo.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.color = {0.0f, 0.0f, 0.0f, 0.0f};
            pClearVal->push_back(cv);
        }
    }

    if (flags & GBUFFER_FLAG_DEPTH) {
        pAttachments->push_back(depth.view);

        if (pClearVal) {
            VkClearValue cv;
            cv.depthStencil = {1.0f, 0};
            pClearVal->push_back(cv);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////

void GBufferRenderPass::create(VkDevice device, GBuffer* gBuffer, GBufferFlags flags, bool bClear)
{
    device_   = device;
    g_buffer_ = gBuffer;
    flags_    = flags;

    render_pass_ = gBuffer->createRenderPass(flags, bClear);
}

void GBufferRenderPass::destroy()
{
    if (render_pass_) {
        vkDestroyRenderPass(device_, render_pass_, nullptr);
        render_pass_ = VK_NULL_HANDLE;
    }

    if (frame_buffer_) {
        vkDestroyFramebuffer(device_, frame_buffer_, nullptr);
        frame_buffer_ = VK_NULL_HANDLE;
    }
}

void GBufferRenderPass::resize(uint32_t width, uint32_t height)
{
    std::vector<VkImageView> attachments;
    clear_values_.clear();
    // TODO：考虑 gBuffer 是否有必要设置 flag
    g_buffer_->getAttachments(GBUFFER_FLAG_ALL, &attachments, &clear_values_);
    attachments_count_ = static_cast<uint32_t>(attachments.size());

    if (frame_buffer_) {
        vkDestroyFramebuffer(device_, frame_buffer_, nullptr);
    }
    frame_buffer_ = CreateFrameBuffer(device_, render_pass_, width, height, &attachments);
}

void GBufferRenderPass::beginPass(VkCommandBuffer cmdBuffer, VkRect2D renderArea)
{
    VkRenderPassBeginInfo renderPassBeginInfo{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    renderPassBeginInfo.renderPass      = render_pass_;
    renderPassBeginInfo.framebuffer     = frame_buffer_;
    renderPassBeginInfo.renderArea      = renderArea;
    renderPassBeginInfo.pClearValues    = clear_values_.data();
    renderPassBeginInfo.clearValueCount = (uint32_t) clear_values_.size();
    vkCmdBeginRenderPass(cmdBuffer, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);

    SetViewportAndScissor(cmdBuffer, renderArea.offset.x, renderArea.offset.y, renderArea.extent.width, renderArea.extent.height);
}

void GBufferRenderPass::endPass(VkCommandBuffer cmdBuffer)
{
    vkCmdEndRenderPass(cmdBuffer);
}

void GBufferRenderPass::getAttachmentsDescriptor(std::vector<VkDescriptorImageInfo>& descInfos)
{
    if (flags_ & GBUFFER_FLAG_POSITION) {
        descInfos.push_back(g_buffer_->position.descriptor);
    }

    if (flags_ & GBUFFER_FLAG_ALBEDO) {
        descInfos.push_back(g_buffer_->albedo.descriptor);
    }

    if (flags_ & GBUFFER_FLAG_NORMAL) {
        descInfos.push_back(g_buffer_->normal.descriptor);
    }

    if (flags_ & GBUFFER_FLAG_EMISSION) {
        descInfos.push_back(g_buffer_->emission.descriptor);
    }

    if (flags_ & GBUFFER_FLAG_SRMO) {
        descInfos.push_back(g_buffer_->srmo.descriptor);
    }
//
//    if (flags_ & GBUFFER_FLAG_DEPTH) {
//        descInfos.push_back(g_buffer_->depth.descriptor);
//    }
}

void GBufferRenderPass::setAttachmentsIndex(PushConstantRasterGLTF& constInfo)
{
    int idx = 0;

    if (flags_ & GBUFFER_FLAG_POSITION) {
        constInfo.gBuffer_position = idx++;
    }

    if (flags_ & GBUFFER_FLAG_ALBEDO) {
        constInfo.gBuffer_albedo = idx++;
    }

    if (flags_ & GBUFFER_FLAG_NORMAL) {
        constInfo.gBuffer_normal = idx++;
    }

    if (flags_ & GBUFFER_FLAG_EMISSION) {
        constInfo.gBuffer_emission = idx++;
    }

    if (flags_ & GBUFFER_FLAG_SRMO) {
        constInfo.gBuffer_srmo = idx++;
    }

//    if (flags_ & GBUFFER_FLAG_DEPTH) {
//        constInfo.gBuffer_depth = idx++;
//    }
}

} // yu::vk
