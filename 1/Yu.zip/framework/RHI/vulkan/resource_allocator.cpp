﻿//
// Created by 秋鱼 on 2022/8/21.
//

#include "resource_allocator.hpp"

namespace yu::vk {

void ResourceAllocator::create(const Context& context, const SwapChain& swapchain)
{
    context_   = &context;
    swapchain_ = &swapchain;

#ifdef USE_VMA
    VmaAllocatorCreateInfo allocator_info = {};
    allocator_info.device         = context_->getDevice();
    allocator_info.physicalDevice = context_->getPhysicalDevice();
    allocator_info.instance       = context_->getInstance();
    vmaCreateAllocator(&allocator_info, &allocator_);
#endif

    dynamic_buffer_.create(context_->getDevice(), context_->getPhysicalDevice(),
#ifdef USE_VMA
                           allocator_,
#endif
                           swapchain_->getBackBufferCount(), 200 * 1024 * 1024, "Dynamic");

    static_buffer_.create(context_->getDevice(), context_->getPhysicalDevice(),
#ifdef USE_VMA
                          allocator_,
#endif
                          128 * 1024 * 1024, true, "Static");

    upload_heap_.create(context_->getDevice(), context_->getPhysicalDevice(), context_->getGCTQueue(), 1000 * 1024 * 1024);

}

void ResourceAllocator::destroy()
{
    dynamic_buffer_.destroy();
    static_buffer_.destroy();
    upload_heap_.destory();

#ifdef USE_VMA
    if (allocator_ != VK_NULL_HANDLE) {
        vmaDestroyAllocator(allocator_);
        allocator_ = VK_NULL_HANDLE;
    }
#endif
}

void ResourceAllocator::beginFrame()
{
    dynamic_buffer_.beginFrame();
}

void ResourceAllocator::uploadStaticAllocation()
{
    static_buffer_.uploadData(upload_heap_.getCommandBuffer());
    upload_heap_.flushAndFinish();
}

TextureVK ResourceAllocator::createTexture(const VkExtent2D& size,
                                           VkFormat format,
                                           VkImageAspectFlags aspectFlags,
                                           VkImageUsageFlags imageUsageFlags,
                                           VkImageLayout imageLayout,
                                           std::string_view name)
{
    TextureVK tex;
    tex.create(context_->getDevice(), context_->getPhysicalDevice(),
#ifdef USE_VMA
               allocator_,
#endif
               size, format, aspectFlags, imageUsageFlags, imageLayout, name);

    return tex;
}

} // yu::vk