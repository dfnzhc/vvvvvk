﻿//
// Created by 秋鱼 on 2022/8/11.
//

#include <logger.hpp>
#include "context.hpp"
#include "error.hpp"
#include "ext_debug.hpp"
#include "extensions_vk.hpp"

namespace yu::vk {

ContextCreateInfo::ContextCreateInfo()
{
#ifdef _DEBUG
    instanceLayers.push_back({"VK_LAYER_KHRONOS_validation", true});
    instanceExtensions.push_back({VK_EXT_DEBUG_UTILS_EXTENSION_NAME, true});
#endif

    // 默认设置三个队列
    {
        VkQueueFlags defaultQueueGCT    = VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT | VK_QUEUE_TRANSFER_BIT;
        VkQueueFlags defaultQueueT      = VK_QUEUE_TRANSFER_BIT;
        VkQueueFlags defaultQueueC      = VK_QUEUE_COMPUTE_BIT;
        float        defaultPriorityGCT = 1.0f;
        float        defaultPriorityT   = 1.0f;
        float        defaultPriorityC   = 1.0f;

        requestedQueues.push_back({defaultQueueGCT, 1, defaultPriorityGCT});
        requestedQueues.push_back({defaultQueueT, 1, defaultPriorityT});
        requestedQueues.push_back({defaultQueueC, 1, defaultPriorityC});

        queueGCT = &requestedQueues[0];
        queueT   = &requestedQueues[1];
        queueC   = &requestedQueues[2];
    }
}

void ContextCreateInfo::setVersion(uint32_t major, uint32_t minor)
{
    apiMajor = major;
    apiMinor = minor;
    assert(apiMajor == 1 && apiMinor >= 1);
}

void ContextCreateInfo::addInstanceLayer(std::string_view name, bool optional)
{
    instanceLayers.emplace_back(name, optional);
}

void ContextCreateInfo::addInstanceExtension(std::string_view name, bool optional)
{
    instanceExtensions.emplace_back(name, optional);
}

void ContextCreateInfo::addDeviceExtension(std::string_view name, bool optional, void* pFeatureStruct)
{
    deviceExtensions.emplace_back(name, optional, pFeatureStruct);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @brief 根据设定的信息，创建 Vulkan 的 Instance 和 Device
 */
bool Context::create(const ContextCreateInfo& info)
{
    if (!initInstance(info)) {
        LOG_ERROR("Vulkan instance initialize failed.");
        return false;
    }

    if (!initDevice(info)) {
        LOG_ERROR("Vulkan device initialize failed.");
        return false;
    }

    return true;
}

void Context::destroy()
{
    if (device_) {
        VK_CHECK(vkDeviceWaitIdle(device_));

        vkDestroyDevice(device_, nullptr);
        device_ = VK_NULL_HANDLE;
    }

    if (enableDebugUtils) {
        DestroyDebugMessenger(instance_);
    }

    if (instance_) {
        vkDestroyInstance(instance_, nullptr);
        instance_ = VK_NULL_HANDLE;
    }

    used_instance_layers_.clear();
    used_instance_extensions_.clear();
    used_device_extensions_.clear();
}

bool Context::initInstance(const ContextCreateInfo& info)
{
    VkApplicationInfo appInfo{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    appInfo.pApplicationName = info.appName.c_str();
    appInfo.pEngineName      = info.engineName.c_str();
    appInfo.apiVersion       = VK_MAKE_VERSION(info.apiMajor, info.apiMinor, 0);

    apiMajor = info.apiMajor;
    apiMinor = info.apiMinor;

    // 设置 instance layers
    {
        auto layers = getInstanceLayers();

        for (const auto& requested : info.instanceLayers) {
            bool found =
                     std::find_if(std::execution::par, layers.cbegin(), layers.cend(), [requested](const VkLayerProperties& layerProperties) -> bool
                     {
                         return std::strcmp(layerProperties.layerName, requested.name.c_str()) == 0;
                     }) != layers.cend();

            if (found) {
                used_instance_layers_.push_back(requested.name);
            } else if (!requested.optional) {
                LOG_ERROR("Requiered layer not found: {}", requested.name);
                return false;
            }
        }
    }

    // 设置 instance extensions
    {
        auto extensions = getInstanceExtensions();

        std::vector<void*> featureStructs;
        if (filterExtensionArray(used_instance_extensions_, extensions, info.instanceExtensions, featureStructs) != VK_SUCCESS) {
            return false;
        }
    }

    if (info.verboseUsed) {
        LOG_INFO("______________________");
        LOG_INFO("Used Instance Layers :");
        for (const auto& item : used_instance_layers_) {
            LOG_INFO("{}", item);
        }
        LOG_INFO("");
        LOG_INFO("Used Instance Extensions :");
        for (const auto& item : used_instance_extensions_) {
            LOG_INFO("{}", item);
        }
    }

    std::vector<const char*> usedInstanceLayers;
    std::vector<const char*> usedInstanceExtensions;
    for (const auto& item : used_instance_layers_) {
        usedInstanceLayers.push_back(item.c_str());
    }
    for (const auto& item : used_instance_extensions_) {
        usedInstanceExtensions.push_back(item.c_str());
    }

    VkInstanceCreateInfo instanceCreateInfo{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    instanceCreateInfo.pApplicationInfo        = &appInfo;
    instanceCreateInfo.enabledExtensionCount   = static_cast<uint32_t>(usedInstanceExtensions.size());
    instanceCreateInfo.ppEnabledExtensionNames = usedInstanceExtensions.data();
    instanceCreateInfo.enabledLayerCount       = static_cast<uint32_t>(usedInstanceLayers.size());
    instanceCreateInfo.ppEnabledLayerNames     = usedInstanceLayers.data();
    instanceCreateInfo.pNext                   = nullptr;

    VK_CHECK(vkCreateInstance(&instanceCreateInfo, nullptr, &instance_));

    // 设置 debug utils
    {
        enableDebugUtils = std::find_if(std::execution::par, usedInstanceExtensions.cbegin(), usedInstanceExtensions.cend(),
                                        [](const char* extension)
                                        {
                                            return std::strcmp(extension, VK_EXT_DEBUG_UTILS_EXTENSION_NAME) == 0;
                                        }) != usedInstanceExtensions.cend();
        if (enableDebugUtils) {
            SetupDebugMessenger(instance_);
        }
    }

    return true;
}

std::vector<VkLayerProperties> Context::getInstanceLayers()
{
    uint32_t                       count;
    std::vector<VkLayerProperties> layerProperties;
    VK_CHECK(vkEnumerateInstanceLayerProperties(&count, nullptr));
    layerProperties.resize(count);
    VK_CHECK(vkEnumerateInstanceLayerProperties(&count, layerProperties.data()));
    layerProperties.resize(std::min(layerProperties.size(), size_t(count)));

    return layerProperties;
}

std::vector<VkExtensionProperties> Context::getInstanceExtensions()
{
    uint32_t                           count;
    std::vector<VkExtensionProperties> extensionProperties;
    VK_CHECK(vkEnumerateInstanceExtensionProperties(nullptr, &count, nullptr));
    extensionProperties.resize(count);
    VK_CHECK(vkEnumerateInstanceExtensionProperties(nullptr, &count, extensionProperties.data()));
    extensionProperties.resize(std::min(extensionProperties.size(), size_t(count)));

    return extensionProperties;
}

std::vector<VkExtensionProperties> Context::getDeviceExtensions()
{
    uint32_t                           count;
    std::vector<VkExtensionProperties> extensionProperties;
    VK_CHECK(vkEnumerateDeviceExtensionProperties(physical_device_, nullptr, &count, nullptr));
    extensionProperties.resize(count);
    VK_CHECK(vkEnumerateDeviceExtensionProperties(physical_device_, nullptr, &count, extensionProperties.data()));
    extensionProperties.resize(std::min(extensionProperties.size(), size_t(count)));

    return extensionProperties;
}

/**
 * @brief 从给定的扩展中筛选出所请求的扩展
 * @param used 通过筛选的扩展名称
 * @param properties 给定的扩展
 * @param requested 所请求的扩展
 * @param featureStructs 一些附加的功能结构
 * @return 如果所有请求的扩展都筛选成功，返回 VK_SUCCESS，否则返回 VK_ERROR_EXTENSION_NOT_PRESENT
 */
VkResult Context::filterExtensionArray(std::vector<std::string>& used,
                                       const std::vector<VkExtensionProperties>& properties,
                                       const ContextCreateInfo::EntryArray& requested,
                                       std::vector<void*>& featureStructs)
{
    for (const auto& entry : requested) {
        bool found =
                 std::find_if(std::execution::par, properties.begin(), properties.end(),
                              [entry](const VkExtensionProperties& extensionProps) -> bool
                              {
                                  return std::strcmp(extensionProps.extensionName, entry.name.c_str()) == 0;
                              }) != properties.end();

        if (found) {
            used.push_back(entry.name);

            if (entry.featureStruct) {
                featureStructs.push_back(entry.featureStruct);
            }
        } else if (!entry.optional) {
            LOG_ERROR("VK_ERROR_EXTENSION_NOT_PRESENT: {}", entry.name);
            return VK_ERROR_EXTENSION_NOT_PRESENT;
        }
    }

    return VK_SUCCESS;
}

bool Context::initDevice(const ContextCreateInfo& info)
{
    choseBestPhysicalDevice();

    // 设置物理设备的特性
    {
        vkGetPhysicalDeviceMemoryProperties(physical_device_, &physical_info_.memoryProperties);
        uint32_t count;
        vkGetPhysicalDeviceQueueFamilyProperties(physical_device_, &count, nullptr);
        physical_info_.queueProperties.resize(count);
        vkGetPhysicalDeviceQueueFamilyProperties(physical_device_, &count, physical_info_.queueProperties.data());

        // for queries and device creation
        VkPhysicalDeviceFeatures2   features2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
        VkPhysicalDeviceProperties2 properties2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2};

        if (apiMajor == 1 && apiMinor >= 2) {
            features2.pNext                 = &physical_info_.features11;
            physical_info_.features11.pNext = &physical_info_.features12;
            physical_info_.features12.pNext = nullptr;

            physical_info_.properties12.driverID                     = VK_DRIVER_ID_NVIDIA_PROPRIETARY;
            physical_info_.properties12.supportedDepthResolveModes   = VK_RESOLVE_MODE_MAX_BIT;
            physical_info_.properties12.supportedStencilResolveModes = VK_RESOLVE_MODE_MAX_BIT;

            properties2.pNext                 = &physical_info_.properties11;
            physical_info_.properties11.pNext = &physical_info_.properties12;
            physical_info_.properties12.pNext = nullptr;
        }

        if (apiMajor == 1 && apiMinor >= 3) {
            physical_info_.features12.pNext   = &physical_info_.features13;
            physical_info_.features13.pNext   = nullptr;
            physical_info_.properties12.pNext = &physical_info_.properties13;
            physical_info_.properties13.pNext = nullptr;
        }

        vkGetPhysicalDeviceFeatures2(physical_device_, &features2);
        vkGetPhysicalDeviceProperties2(physical_device_, &properties2);

        physical_info_.properties = properties2.properties;
        physical_info_.features10 = features2.features;
    }

    // 设置设备的队列
    std::vector<VkDeviceQueueCreateInfo> queueCreateInfos;
    std::vector<float>                   priorities;

    {
        QueueScoreList queueScoresTemp;

        uint32_t maxQueueCount = 0;

        for (auto& it : physical_info_.queueProperties) {
            maxQueueCount = std::max(maxQueueCount, it.queueCount);
        }
        // 优先度的数量假设每个 family 都有最大的队列数量，方便之后进行操作
        priorities.resize(physical_info_.queueProperties.size() * maxQueueCount);

        // 遍历所有队列，设置相关信息
        initQueueList(queueScoresTemp, nullptr, nullptr, 0);

        // 每种 family 的队列各需要多少个
        std::vector<uint32_t> queueFamilyCounts(physical_info_.queueProperties.size(), 0);

        for (auto& it : info.requestedQueues) {
            for (uint32_t i = 0; i < it.count; i++) {
                QueueScore queue = removeQueueListItem(queueScoresTemp, it.requiredFlags, 1.0f);
                if (!queue.score) {
                    // 所请求的 flag 队列没有足够的数量
                    LOG_ERROR("Could not setup requested queue configuration");
                    return false;
                }

                priorities[queue.familyIndex * maxQueueCount + queueFamilyCounts[queue.familyIndex]] = it.priority;
                queueFamilyCounts[queue.familyIndex]++;
            }
        }

        // 对于所请求的队列 family，设置相应的队列数量、优先度
        for (uint32_t i = 0; i < physical_info_.queueProperties.size(); ++i) {
            if (queueFamilyCounts[i]) {
                VkDeviceQueueCreateInfo queueInfo{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
                queueInfo.queueFamilyIndex = i;
                queueInfo.queueCount       = queueFamilyCounts[i];
                queueInfo.pQueuePriorities = priorities.data() + (i * maxQueueCount);

                queueCreateInfos.push_back(queueInfo);
            }
        }

        // 设置实际的请求队列的 QueueScore，用于之后的队列创建
        initQueueList(available_queues_, queueFamilyCounts.data(), priorities.data(), maxQueueCount);
    }

    VkDeviceCreateInfo deviceCreateInfo{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    deviceCreateInfo.queueCreateInfoCount = static_cast<uint32_t>(queueCreateInfos.size());
    deviceCreateInfo.pQueueCreateInfos    = queueCreateInfos.data();

    // 设置各种功能和扩展
    VkPhysicalDeviceFeatures2 features2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
    std::vector<void*>        featureStructs;

    features2.features = physical_info_.features10;
    if (info.apiMajor == 1 && info.apiMinor >= 2) {
        features2.pNext                 = &physical_info_.features11;
        physical_info_.features11.pNext = &physical_info_.features12;
        physical_info_.features12.pNext = nullptr;
    }

    if (info.apiMajor == 1 && info.apiMinor >= 3) {
        physical_info_.features12.pNext = &physical_info_.features13;
        physical_info_.features13.pNext = nullptr;
    }

    auto extensionProperties = getDeviceExtensions();

    if (filterExtensionArray(used_device_extensions_, extensionProperties, info.deviceExtensions, featureStructs) != VK_SUCCESS) {
        destroy();
        return false;
    }

    LOG_INFO("________________________");
    LOG_INFO("Used Device Extensions :");
    for (const auto& it : used_device_extensions_) {
        LOG_INFO("{}", it);
    }

    // 用来将功能扩展链接起来
    struct ExtensionHeader
    {
        VkStructureType sType;
        void* pNext;
    };

    if (!featureStructs.empty()) {
        // 对所有启用的功能和扩展，把它们链接起来
        for (size_t i = 0; i < featureStructs.size(); i++) {
            auto* header = reinterpret_cast<ExtensionHeader*>(featureStructs[i]);
            header->pNext = i < featureStructs.size() - 1 ? featureStructs[i + 1] : nullptr;
        }

        // 将功能扩展的 pNext 接到 feature2 的后面
        auto* lastCoreFeature = (ExtensionHeader*) &features2;
        while (lastCoreFeature->pNext != nullptr) {
            lastCoreFeature = (ExtensionHeader*) lastCoreFeature->pNext;
        }
        lastCoreFeature->pNext = featureStructs[0];

        vkGetPhysicalDeviceFeatures2(physical_device_, &features2);
    }

    std::vector<const char*> usedDeviceExtensions;
    for (const auto& it : used_device_extensions_) {
        usedDeviceExtensions.push_back(it.c_str());
    }

    deviceCreateInfo.enabledExtensionCount   = static_cast<uint32_t>(usedDeviceExtensions.size());
    deviceCreateInfo.ppEnabledExtensionNames = usedDeviceExtensions.data();
    deviceCreateInfo.pEnabledFeatures        = nullptr;
    deviceCreateInfo.pNext                   = &features2;

    ExtensionHeader* deviceCreateChain = nullptr;
    if (info.deviceCreateInfoExt) {
        deviceCreateChain = (ExtensionHeader*) info.deviceCreateInfoExt;
        while (deviceCreateChain->pNext != nullptr) {
            deviceCreateChain = (ExtensionHeader*) deviceCreateChain->pNext;
        }
        // override last of external chain
        deviceCreateChain->pNext = (void*) deviceCreateInfo.pNext;
        deviceCreateInfo.pNext   = info.deviceCreateInfoExt;
    }

    VkResult result = vkCreateDevice(physical_device_, &deviceCreateInfo, nullptr, &device_);

    if (deviceCreateChain) {
        // reset last of external chain
        deviceCreateChain->pNext = nullptr;
    }

    if (result != VK_SUCCESS) {
        destroy();
        return false;
    }

    queueGCT_ = createQueue(info.queueGCT->requiredFlags, "queueGCT", info.queueGCT->priority);
    queueT_   = createQueue(info.queueT->requiredFlags, "queueT", info.queueT->priority);
    queueC_   = createQueue(info.queueC->requiredFlags, "queueC", info.queueC->priority);

    load_VK_EXTENSIONS(instance_, vkGetInstanceProcAddr, device_, vkGetDeviceProcAddr);

    return true;
}

void Context::choseBestPhysicalDevice()
{
    auto getDeviceScore = [](VkPhysicalDevice physicalDevice)
    {
        uint32_t score = 0;

        VkPhysicalDeviceProperties deviceProperties;
        vkGetPhysicalDeviceProperties(physicalDevice, &deviceProperties);
        // 选择使用 feature 可以评估更多的设备信息，从而选择更优的设备
        // VkPhysicalDeviceFeatures deviceFeatures;
        // vkGetPhysicalDeviceFeatures(physicalDevice, &deviceFeatures);
        switch (deviceProperties.deviceType) {
            case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU:
                score += 1000;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:
                score += 10000;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:
                score += 100;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_CPU:
                score += 10;
                break;
            default:
                break;
        }
        return score;
    };

    uint32_t physicalDeviceCount = 1;
    VK_CHECK(vkEnumeratePhysicalDevices(instance_, &physicalDeviceCount, nullptr));
    assert(physicalDeviceCount > 0 && "No GPU found");

    std::vector<VkPhysicalDevice> physicalDevices;
    physicalDevices.resize(physicalDeviceCount);
    VK_CHECK(vkEnumeratePhysicalDevices(instance_, &physicalDeviceCount, physicalDevices.data()));
    assert(!physicalDevices.empty() && "No GPU found");

    std::multimap<uint32_t, VkPhysicalDevice> ratings;
    for (auto                                 it = physicalDevices.begin(); it != physicalDevices.end(); ++it)
        ratings.insert(std::make_pair(getDeviceScore(*it), *it));

    physical_device_ = ratings.rbegin()->second;
}

/**
 * @brief 按照物理设备的信息设置 QueueScoreList
 */
void Context::initQueueList(Context::QueueScoreList& list, const uint32_t* maxFamilyCounts, const float* priorities, uint32_t maxQueueCount) const
{
    for (uint32_t qF = 0; qF < physical_info_.queueProperties.size(); ++qF) {
        const auto& queueFamily = physical_info_.queueProperties[qF];
        QueueScore score{0, qF, 0, 1.0f};

        // 每符合一种 flag，分数就会增加
        for (uint32_t i = 0; i < 32; i++) {
            if (queueFamily.queueFlags & (1 << i)) {
                score.score++;
            }
        }

        // 队列在其家族中的序列
        for (uint32_t qI = 0; qI < (maxFamilyCounts ? maxFamilyCounts[qF] : queueFamily.queueCount); ++qI) {
            score.queueIndex = qI;

            if (priorities) {
                score.priority = priorities[qF * maxQueueCount + qI];
            }

            list.emplace_back(score);
        }
    }

    // 按照分数对队列进行排序，越专一化的队列，分数越低
    std::sort(list.begin(), list.end(), [](const QueueScore& lhs, const QueueScore& rhs)
    {
        if (lhs.score < rhs.score)
            return true;
        if (lhs.score > rhs.score)
            return false;
        if (lhs.priority > rhs.priority)
            return true;
        if (lhs.priority < rhs.priority)
            return false;
        return lhs.queueIndex < rhs.queueIndex;
    });
}

/**
 * @brief 从 QueueScoreList 中移除相关 flag 队列的记录，这表示该队列被选取创建
 */
Context::QueueScore Context::removeQueueListItem(Context::QueueScoreList& list, VkQueueFlags needFlags, float priority) const
{
    for (uint32_t q = 0; q < list.size(); ++q) {
        const QueueScore& score  = list[q];
        auto            & family = physical_info_.queueProperties[score.familyIndex];
        if ((family.queueFlags & needFlags) == needFlags && score.priority == priority) {
            QueueScore queue = score;
            queue.familyIndex = score.familyIndex;
            queue.queueIndex  = score.queueIndex;
            list.erase(list.begin() + q);
            return queue;
        }
    }

    return {};
}

Context::Queue Context::createQueue(VkQueueFlags requiredFlags, const std::string& debugName, float priority)
{
    if (!requiredFlags || available_queues_.empty()) {
        return {};
    }

    QueueScore score = removeQueueListItem(available_queues_, requiredFlags, priority);
    if (!score.score) {
        return {};
    }

    Queue queue;
    queue.familyIndex = score.familyIndex;
    queue.queueIndex  = score.queueIndex;
    queue.priority    = score.priority;
    vkGetDeviceQueue(device_, queue.familyIndex, queue.queueIndex, &queue.queue);

    return queue;
}

void Context::checkGCTQueuePresent(VkSurfaceKHR surface) const
{
    VkBool32 supportsPresent;
    vkGetPhysicalDeviceSurfaceSupportKHR(physical_device_, queueGCT_.familyIndex, surface, &supportsPresent);

    assert(supportsPresent);
}

} // yu::vk