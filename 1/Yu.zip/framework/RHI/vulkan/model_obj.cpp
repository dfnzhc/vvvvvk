﻿//
// Created by 秋鱼 on 2022/7/8.
//

#include <logger.hpp>
#include "model_obj.hpp"

#include "common/obj_loader.hpp"

#include <San/base/timer.hpp>

namespace yu::vk {

void ObjModel::load(std::string_view fileName, ResourceAllocator* resourceAllocator, std::vector<Texture2D>& textures)
{
    ObjLoader loader;
    loader.load(fileName);

    // 将颜色由 srgb 转换到线性
    for (auto& m : loader.materials) {
        m.ambient  = glm::pow(m.ambient, glm::vec3{2.2f});
        m.diffuse  = glm::pow(m.diffuse, glm::vec3{2.2f});
        m.specular = glm::pow(m.specular, glm::vec3{2.2f});
    }

    nbIndices  = static_cast<uint32_t>(loader.indices.size());
    nbVertices = static_cast<uint32_t>(loader.vertices.size());

    VkBufferUsageFlags flag = VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT;

    // 创建缓冲区
    resourceAllocator->getStaticBuffer().allocBuffer(loader.vertices, &vertexBufferInfo);
    resourceAllocator->getStaticBuffer().allocBuffer(loader.indices, &indexBufferInfo);
    resourceAllocator->uploadStaticAllocation();

    matColorBuffer = resourceAllocator->createBuffer(loader.materials, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | flag);
    matIndexBuffer = resourceAllocator->createBuffer(loader.matIndex, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | flag);

    descInfo = {static_cast<int>(textures.size()), matColorBuffer.getDeviceAddress(), matIndexBuffer.getDeviceAddress()};
    
    // 加载纹理
    for (const auto& imgFile : loader.textures) {
        Texture2D tex = resourceAllocator->createTexture<Texture2D>(loader.basePath + imgFile);
        textures.push_back(tex);
    }
}

void ObjModel::destroy()
{
    matColorBuffer.destroy();
    matIndexBuffer.destroy();
}

VkVertexInputBindingDescription GetBindingDescOBJ()
{
    return {0, sizeof(VertexObj), VK_VERTEX_INPUT_RATE_VERTEX};
}

std::vector<VkVertexInputAttributeDescription> GetVertexInputDescOBJ()
{
    return {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, static_cast<uint32_t>(offsetof(VertexObj, pos))},
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT, static_cast<uint32_t>(offsetof(VertexObj, normal))},
        {2, 0, VK_FORMAT_R32G32B32_SFLOAT, static_cast<uint32_t>(offsetof(VertexObj, color))},
        {3, 0, VK_FORMAT_R32G32_SFLOAT, static_cast<uint32_t>(offsetof(VertexObj, texCoord))},
    };
}

} // yu::vk