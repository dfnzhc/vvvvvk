﻿//
// Created by 秋鱼 on 2022/6/8.
//

#include "commands.hpp"
#include "error.hpp"

namespace yu::vk {

void CommandPool::create(VkDevice device, uint32_t queueFamilyIndex)
{
    device_ = device;

    vkGetDeviceQueue(device, queueFamilyIndex, 0, &queue_);

    {
        VkCommandPoolCreateInfo cmdPoolCreateInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        cmdPoolCreateInfo.queueFamilyIndex = queueFamilyIndex;
        cmdPoolCreateInfo.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;

        VK_CHECK(vkCreateCommandPool(device_, &cmdPoolCreateInfo, nullptr, &command_pool_));
    }
}

void CommandPool::destroy()
{
    if (command_pool_ != VK_NULL_HANDLE) {
        vkDestroyCommandPool(device_, command_pool_, nullptr);
        command_pool_ = VK_NULL_HANDLE;
    }
}

VkCommandBuffer CommandPool::createCommandBuffer(VkCommandBufferLevel level,
                                                 bool begin,
                                                 VkCommandBufferUsageFlags flags,
                                                 const VkCommandBufferInheritanceInfo* pInheritanceInfo)
{
    VkCommandBufferAllocateInfo allocInfo = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    allocInfo.level              = level;
    allocInfo.commandPool        = command_pool_;
    allocInfo.commandBufferCount = 1;

    VkCommandBuffer cmd;
    vkAllocateCommandBuffers(device_, &allocInfo, &cmd);

    if (begin) {
        VkCommandBufferBeginInfo beginInfo = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        beginInfo.flags            = flags;
        beginInfo.pInheritanceInfo = pInheritanceInfo;

        vkBeginCommandBuffer(cmd, &beginInfo);
    }

    return cmd;
}
void CommandPool::destroy(size_t count, const VkCommandBuffer* cmds)
{
    vkFreeCommandBuffers(device_, command_pool_, (uint32_t) count, cmds);
}

void CommandPool::submit(size_t count, const VkCommandBuffer* cmds, VkQueue queue, VkFence fence)
{
    for (size_t i = 0; i < count; i++) {
        vkEndCommandBuffer(cmds[i]);
    }

    VkSubmitInfo submit = {VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submit.pCommandBuffers    = cmds;
    submit.commandBufferCount = (uint32_t) count;
    vkQueueSubmit(queue, 1, &submit, fence);
}

void CommandPool::submit(size_t count, const VkCommandBuffer* cmds, VkFence fence)
{
    submit(count, cmds, queue_, fence);
}

void CommandPool::submit(const std::vector<VkCommandBuffer>& cmds, VkFence fence)
{
    submit(cmds.size(), cmds.data(), queue_, fence);
}

void CommandPool::submitAndWait(size_t count, const VkCommandBuffer* cmds, VkQueue queue)
{
    submit(count, cmds, queue);
    VK_CHECK(vkQueueWaitIdle(queue));
    vkFreeCommandBuffers(device_, command_pool_, (uint32_t) count, cmds);
}


/// ==================================================================================================================================
/// FrameCommandPool

void FrameCommandPool::create(VkDevice device, uint32_t queueFamilyIndex, uint32_t numberOfFrames, uint32_t commandBufferPerFrame)
{
    device_                   = device;
    number_of_frames_         = numberOfFrames;
    command_buffer_per_frame_ = commandBufferPerFrame;

    vkGetDeviceQueue(device, queueFamilyIndex, 0, &queue_);

    // 为每一帧创建独立命令池，让命令池能够各自分配命令缓冲区
    frame_command_buffers.resize(number_of_frames_);

    for (auto& buf : frame_command_buffers) {
        // 创建命令池
        VkCommandPoolCreateInfo cmdPoolCreateInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        cmdPoolCreateInfo.queueFamilyIndex = queueFamilyIndex;
        cmdPoolCreateInfo.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT | VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;

        VK_CHECK(vkCreateCommandPool(device_, &cmdPoolCreateInfo, nullptr, &buf.commandPool));

        // 创建命令缓冲区
        buf.commandBuffers.resize(command_buffer_per_frame_, VK_NULL_HANDLE);

        VkCommandBufferAllocateInfo cmdBufferAllocateInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cmdBufferAllocateInfo.commandPool        = buf.commandPool;
        cmdBufferAllocateInfo.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        cmdBufferAllocateInfo.commandBufferCount = command_buffer_per_frame_;

        VK_CHECK(vkAllocateCommandBuffers(device_, &cmdBufferAllocateInfo, buf.commandBuffers.data()));

        buf.numberOfUsed = 0;
    }

    frame_index_ = 0;
}

void FrameCommandPool::destroy()
{
    for (auto& buf : frame_command_buffers) {
        vkFreeCommandBuffers(device_, buf.commandPool, command_buffer_per_frame_, buf.commandBuffers.data());
        vkDestroyCommandPool(device_, buf.commandPool, nullptr);
    }
}

void FrameCommandPool::beginFrame()
{
    current_frame_buffer = &frame_command_buffers[frame_index_ % number_of_frames_];
    current_frame_buffer->numberOfUsed = 0;

    frame_index_ += 1;
}

/**
 * @brief 返回一个为每帧分配的命令缓冲区，每一帧请求的个数不能超出 command_buffer_per_frame_
 * @return 
 */
VkCommandBuffer FrameCommandPool::getFrameCommandBuffer()
{
    auto cmdBuffer = current_frame_buffer->commandBuffers[current_frame_buffer->numberOfUsed++];
    
    assert(current_frame_buffer->numberOfUsed < command_buffer_per_frame_);

    return cmdBuffer;
}

VkResult FrameCommandPool::submitSingleCommandBuffer(VkCommandBuffer cmdBuffer)
{
    VK_CHECK(vkEndCommandBuffer(cmdBuffer));
    
    VkSubmitInfo submit_info;
    submit_info.sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit_info.pNext                = nullptr;
    submit_info.waitSemaphoreCount   = 0;
    submit_info.pWaitSemaphores      = nullptr;
    submit_info.pWaitDstStageMask    = nullptr;
    submit_info.commandBufferCount   = 1;
    submit_info.pCommandBuffers      = &cmdBuffer;
    submit_info.signalSemaphoreCount = 0;
    submit_info.pSignalSemaphores    = nullptr;
    
    return  vkQueueSubmit(queue_, 1, &submit_info, VK_NULL_HANDLE);
}

} // namespace yu::vk
