﻿//
// Created by 秋鱼 on 2022/8/4.
//

#include "descriptor_sets.hpp"

namespace yu::vk {

VkDescriptorSetLayout DescriptorSetBindings::createLayout(VkDevice device,
                                                          VkDescriptorSetLayoutCreateFlags flags) const
{
    VkDescriptorSetLayoutCreateInfo createInfo = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    createInfo.bindingCount = uint32_t(bindings_.size());
    createInfo.pBindings    = bindings_.data();
    createInfo.flags        = flags;
    createInfo.pNext        = nullptr;

    VkDescriptorSetLayout descriptorSetLayout;
    VK_CHECK(vkCreateDescriptorSetLayout(device, &createInfo, nullptr, &descriptorSetLayout));

    return descriptorSetLayout;
}

void DescriptorSetBindings::addRequiredPoolSizes(std::vector<VkDescriptorPoolSize>& poolSizes, uint32_t numSets) const
{
    for (auto it = bindings_.cbegin(); it != bindings_.cend(); ++it) {
        bool      found  = false;
        for (auto itpool = poolSizes.begin(); itpool != poolSizes.end(); ++itpool) {
            if (itpool->type == it->descriptorType) {
                itpool->descriptorCount += it->descriptorCount * numSets;
                found = true;
                break;
            }
        }
        if (!found) {
            VkDescriptorPoolSize poolSize;
            poolSize.type            = it->descriptorType;
            poolSize.descriptorCount = it->descriptorCount * numSets;
            poolSizes.push_back(poolSize);
        }
    }
}

VkDescriptorPool DescriptorSetBindings::createPool(VkDevice device, uint32_t maxSets /*= 1*/, VkDescriptorPoolCreateFlags flags /*= 0*/) const
{
    // setup poolSizes for each descriptorType
    std::vector<VkDescriptorPoolSize> poolSizes;
    addRequiredPoolSizes(poolSizes, maxSets);

    VkDescriptorPool           descrPool;
    VkDescriptorPoolCreateInfo descrPoolInfo = {};
    descrPoolInfo.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    descrPoolInfo.pNext         = nullptr;
    descrPoolInfo.maxSets       = maxSets;
    descrPoolInfo.poolSizeCount = uint32_t(poolSizes.size());
    descrPoolInfo.pPoolSizes    = poolSizes.data();
    descrPoolInfo.flags         = flags;

    // scene pool
    VK_CHECK(vkCreateDescriptorPool(device, &descrPoolInfo, nullptr, &descrPool));
    return descrPool;
}

VkDescriptorSet DescriptorSetBindings::allocSet(VkDevice device, VkDescriptorPool descriptorPool, VkDescriptorSetLayout descriptorSetLayout) const
{
    return AllocateDescriptorSet(device, descriptorPool, descriptorSetLayout);
}

VkDescriptorType DescriptorSetBindings::getType(uint32_t binding) const
{
    for (const auto& i : bindings_) {
        if (i.binding == binding) {
            return i.descriptorType;
        }
    }
    assert(0 && "binding not found");
    return VK_DESCRIPTOR_TYPE_MAX_ENUM;
}

uint32_t DescriptorSetBindings::getCount(uint32_t binding) const
{
    for (const auto& i : bindings_) {
        if (i.binding == binding) {
            return i.descriptorCount;
        }
    }
    assert(0 && "binding not found");
    return ~0;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet, uint32_t dstBinding, uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    writeSet.descriptorType = VK_DESCRIPTOR_TYPE_MAX_ENUM;
    for (const auto& binding : bindings_) {
        if (binding.binding == dstBinding) {
            writeSet.descriptorCount = 1;
            writeSet.descriptorType  = binding.descriptorType;
            writeSet.dstBinding      = dstBinding;
            writeSet.dstSet          = dstSet;
            writeSet.dstArrayElement = arrayElement;
            return writeSet;
        }
    }
    assert(0 && "binding not found");
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding) const
{
    VkWriteDescriptorSet writeSet = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    writeSet.descriptorType = VK_DESCRIPTOR_TYPE_MAX_ENUM;
    for (const auto& binding : bindings_) {
        if (binding.binding == dstBinding) {
            writeSet.descriptorCount = binding.descriptorCount;
            writeSet.descriptorType  = binding.descriptorType;
            writeSet.dstBinding      = dstBinding;
            writeSet.dstSet          = dstSet;
            writeSet.dstArrayElement = 0;
            return writeSet;
        }
    }
    assert(0 && "binding not found");
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkDescriptorImageInfo* pImageInfo,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_SAMPLER || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT);

    writeSet.pImageInfo = pImageInfo;
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkDescriptorBufferInfo* pBufferInfo,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC);

    writeSet.pBufferInfo = pBufferInfo;
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkBufferView* pTexelBufferView,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER);

    writeSet.pTexelBufferView = pTexelBufferView;
    return writeSet;
}

#if VK_NV_ray_tracing
VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkWriteDescriptorSetAccelerationStructureNV* pAccel,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_NV);

    writeSet.pNext = pAccel;
    return writeSet;
}
#endif
#if VK_KHR_acceleration_structure
VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkWriteDescriptorSetAccelerationStructureKHR* pAccel,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR);

    writeSet.pNext = pAccel;
    return writeSet;
}
#endif

#if VK_EXT_inline_uniform_block
VkWriteDescriptorSet DescriptorSetBindings::makeWrite(VkDescriptorSet dstSet,
                                                      uint32_t dstBinding,
                                                      const VkWriteDescriptorSetInlineUniformBlockEXT* pInline,
                                                      uint32_t arrayElement) const
{
    VkWriteDescriptorSet writeSet = makeWrite(dstSet, dstBinding, arrayElement);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_INLINE_UNIFORM_BLOCK_EXT);

    writeSet.pNext = pInline;
    return writeSet;
}
#endif
VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet,
                                                           uint32_t dstBinding,
                                                           const VkDescriptorImageInfo* pImageInfo) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_SAMPLER || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT);

    writeSet.pImageInfo = pImageInfo;
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet,
                                                           uint32_t dstBinding,
                                                           const VkDescriptorBufferInfo* pBufferInfo) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
               || writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC);

    writeSet.pBufferInfo = pBufferInfo;
    return writeSet;
}

VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet, uint32_t dstBinding, const VkBufferView* pTexelBufferView) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER);

    writeSet.pTexelBufferView = pTexelBufferView;
    return writeSet;
}

#if VK_NV_ray_tracing
VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet,
                                                           uint32_t dstBinding,
                                                           const VkWriteDescriptorSetAccelerationStructureNV* pAccel) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_NV);

    writeSet.pNext = pAccel;
    return writeSet;
}
#endif
#if VK_KHR_acceleration_structure
VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet,
                                                           uint32_t dstBinding,
                                                           const VkWriteDescriptorSetAccelerationStructureKHR* pAccel) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR);

    writeSet.pNext = pAccel;
    return writeSet;
}
#endif
#if VK_EXT_inline_uniform_block
VkWriteDescriptorSet DescriptorSetBindings::makeWriteArray(VkDescriptorSet dstSet,
                                                           uint32_t dstBinding,
                                                           const VkWriteDescriptorSetInlineUniformBlockEXT* pInline) const
{
    VkWriteDescriptorSet writeSet = makeWriteArray(dstSet, dstBinding);
    assert(writeSet.descriptorType == VK_DESCRIPTOR_TYPE_INLINE_UNIFORM_BLOCK_EXT);

    writeSet.pNext = pInline;
    return writeSet;
}
#endif
} // yu::vk