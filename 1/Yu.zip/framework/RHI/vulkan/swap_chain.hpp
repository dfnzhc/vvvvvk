﻿//
// Created by 秋鱼 on 2022/6/4.
//

#pragma once

#include <vulkan/vulkan_core.h>

namespace yu::vk {

/**
 * @brief 交换链在每一帧获取时的状态
 */
struct SwapChainAcquireState
{
    // 图像、视图、以及该图像在缓冲区中的索引
    VkImage     image;
    VkImageView view;
    uint32_t    index;

    /** @brief 在写入图像前(渲染之前)，必须等待此信号完成(图像被呈现到屏幕上) */
    VkSemaphore waitSem;

    /** @brief 当写入图像后(渲染完成)发出完成信号，系统在收到此信号后将图像呈现到屏幕 */
    VkSemaphore signalSem;
};

class SwapChain
{
public:
    SwapChain() = default;
    explicit SwapChain(uint32_t backBufCount) : back_buffer_count_{backBufCount} {}

    SwapChain(SwapChain const&) = delete;
    SwapChain& operator=(SwapChain const&) = delete;

    bool create(VkDevice device,
                VkPhysicalDevice physicalDevice,
                VkQueue queue,
                uint32_t queueFamilyIndex,
                VkSurfaceKHR surface,
                VkFormat format = VK_FORMAT_B8G8R8A8_UNORM,
                VkImageUsageFlags imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT);

    void destroy();

    /**
     * @brief 删除交换链拥有的一些资源，方便重建或删除
     */
    void destroyResource();

    /**
     * @brief 更新交换链的信息，在创建之后应该执行一次。会返回交换链实际上的大小，这可能与所请求的不一致
     */
    VkExtent2D update(uint32_t width, uint32_t height, bool vsync);
    VkExtent2D update(uint32_t width, uint32_t height) { return update(width, height, vsync_); }

    uint32_t acquire(SwapChainAcquireState* pOut = nullptr);
    void submit(VkQueue queue, VkCommandBuffer cmdBuffer, VkPipelineStageFlags submitWaitStage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT) const;
    VkResult present();

    [[nodiscard]] uint32_t getWidth() const { return extent_.width; }
    [[nodiscard]] uint32_t getHeight() const { return extent_.height; }
    [[nodiscard]] VkExtent2D getExtent() const { return extent_; }

    [[nodiscard]] VkImageView getImageView(uint32_t i) const { return image_entries_[i].imageView; }

    [[nodiscard]] VkFramebuffer getFrameBuffer(int i) const { return frame_buffers_[i]; }
    [[nodiscard]] VkFramebuffer getFrameBuffer() const { return frame_buffers_[image_index_]; }

    [[nodiscard]] bool getVsync() const { return vsync_; }

    [[nodiscard]] VkFence getFence(uint32_t i) const { return frame_sync_entries_[i].fence; }
    [[nodiscard]] VkFence getFence() const { return frame_sync_entries_[current_frame_].fence; }

    [[nodiscard]] VkSemaphore getWaitSemaphore(uint32_t i) const { return frame_sync_entries_[i].imageAvailableSemaphore; }
    [[nodiscard]] VkSemaphore getWaitSemaphore() const { return frame_sync_entries_[current_frame_].imageAvailableSemaphore; }

    [[nodiscard]] VkSemaphore getSignalSemaphore(uint32_t i) const { return frame_sync_entries_[i].renderFinishedSemaphore; }
    [[nodiscard]] VkSemaphore getSignalSemaphore() const { return frame_sync_entries_[current_frame_].renderFinishedSemaphore; }

    [[nodiscard]] VkSwapchainKHR getHandle() const { return swapchain_; }

    [[nodiscard]] uint32_t getBackBufferCount() const { return back_buffer_count_; }

    [[nodiscard]] VkRenderPass getRenderPass() const { return render_pass_; }
    
    [[nodiscard]] uint32_t    getImageCount() const { return image_count_; }
    [[nodiscard]] uint32_t    getActiveImageIndex() const { return image_index_; }

private:
    /**
     * @brief 创建交换链的 render pass
     */
    void createRenderPass();

    /**
     * @brief 创建交换链的图像和深度图像
     */
    void createSwapChainImages();

    /**
     * @brief 为交换链创建帧缓冲区
     */
    void createFrameBuffer();

private:
    VkSwapchainKHR swapchain_{};
    uint32_t       back_buffer_count_ = 2;

    VkDevice         device_{};
    VkPhysicalDevice physical_device_{};

    VkQueue  queue_{};
    uint32_t queue_family_index_ = 0;

    VkSurfaceKHR    surface_{};
    VkFormat        surface_format_{};
    VkColorSpaceKHR surface_color_{};

    VkRenderPass render_pass_{};

    struct ImageEntry
    {
        VkImage     image{};
        VkImageView imageView{};
    };

    std::vector<ImageEntry> image_entries_{};
    uint32_t                image_count_ = 0;
    uint32_t                image_index_ = 0;

    VkImage        depth_image_{};
    VkImageView    depth_view_{};
    VkDeviceMemory depth_memory_{};
    VkFormat       depth_format_{};

    uint32_t                   current_frame_ = 0;
    uint32_t                   prev_frame_    = 0;
    std::vector<VkFramebuffer> frame_buffers_{};

    /** @brief 当前交换链的图像大小 */
    VkExtent2D extent_{0, 0};

    /** @brief 是否使用同步的显示模式 */
    bool vsync_ = false;

    VkImageUsageFlags           image_usage_flags_{};

    struct FrameSyncEntry
    {
        /** @brief 用于当前后台缓冲区的命令缓冲区 */
        VkFence fence{};

        /** @brief 在写入图像前(渲染之前)，必须等待此信号完成(图像被呈现到屏幕上) */
        VkSemaphore imageAvailableSemaphore{};

        /** @brief 当写入图像后(渲染完成)发出完成信号，系统在收到此信号后将图像呈现到屏幕 */
        VkSemaphore renderFinishedSemaphore{};
    };
    std::vector<FrameSyncEntry> frame_sync_entries_{};
};

} // yu::vk