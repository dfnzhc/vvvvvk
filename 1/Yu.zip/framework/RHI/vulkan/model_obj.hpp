﻿//
// Created by 秋鱼 on 2022/7/8.
//

#pragma once

#include "buffer.hpp"

#include <glm/glm.hpp>

#include "../../../data/shaders/objDefines.h"
#include "resource_allocator.hpp"
#include "texture.hpp"

namespace yu::vk {

struct ObjInstance
{
    /** @brief 实例的变换矩阵 */
    glm::mat4 transform{};

    /** @brief 模型的索引 */
    uint32_t objIndex{0};
};

struct ObjModel
{
    /** @brief 索引的个数 */
    uint32_t nbIndices{0};

    /** @brief 顶点的个数 */
    uint32_t nbVertices{0};

    /** @brief 顶点缓冲区的描述符信息 */
    VkDescriptorBufferInfo vertexBufferInfo{};

    /** @brief 索引缓冲区的描述符信息 */
    VkDescriptorBufferInfo indexBufferInfo{};

    /** @brief 材质颜色的缓冲区 */
    Buffer matColorBuffer{};

    /** @brief 材质索引的缓冲区 */
    Buffer matIndexBuffer{};

    /** @brief 模型的描述符信息 */
    DescOBJ descInfo{};

    void load(std::string_view fileName, ResourceAllocator* resourceAllocator, std::vector<Texture2D>& textures);
    void destroy();

    [[nodiscard]] DescOBJ getObjDesc() const { return descInfo; }
};

[[nodiscard]] VkVertexInputBindingDescription GetBindingDescOBJ();

[[nodiscard]] std::vector<VkVertexInputAttributeDescription> GetVertexInputDescOBJ();
} // yu::vk