﻿//
// Created by 秋鱼 on 2022/6/3.
//

#pragma once

#include <vulkan/vulkan.h>

namespace yu::vk {

VkShaderStageFlagBits GetShaderType(std::string_view fileName);
VkShaderModule LoadShader(std::string_view fileName, VkDevice device);
uint32_t SizeOfFormat(VkFormat format);
uint32_t BitSizeOfFormat(VkFormat format);

template<typename T>
requires std::same_as<decltype(T::sType), VkStructureType>
bool EntityNotSet(T t)
{
    if (t.sType == VK_STRUCTURE_TYPE_APPLICATION_INFO) {
        return true;
    }

    return false;
}

uint32_t GetMemoryType(VkPhysicalDevice physicalDevice, uint32_t typeBits, const VkMemoryPropertyFlags& properties);

VkFormat GetSupportedFormat(VkPhysicalDevice physicalDevice,
                            const std::vector<VkFormat>& candidates,
                            VkImageTiling tiling,
                            VkFormatFeatureFlags features);

VkFormat GetDepthFormat(VkPhysicalDevice physicalDevice);

VkRenderPass CreateRenderPass(VkDevice device,
                              const std::vector<VkFormat>& colorAttachmentFormats,
                              VkFormat depthAttachmentFormat,
                              bool clearColor,
                              bool clearDepth,
                              VkImageLayout initialLayout,
                              VkImageLayout finalLayout);

VkFramebuffer CreateFrameBuffer(VkDevice device,
                                VkRenderPass renderPass,
                                uint32_t width,
                                uint32_t height,
                                const std::vector<VkImageView>* pAttachments);

void SetViewportAndScissor(VkCommandBuffer cmdBuffer, uint32_t topX, uint32_t topY, uint32_t width, uint32_t height);
} // namespace yu::vk