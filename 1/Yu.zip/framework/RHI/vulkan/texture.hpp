﻿//
// Created by 秋鱼 on 2022/8/21.
//

#pragma once

#include <vulkan/vulkan_core.h>
#include <common/Bitmap.hpp>
#include "buffer.hpp"

namespace yu::vk {

/// ==================================================================
/// 一些工具函数
/// ==================================================================

VkAccessFlags AccessFlagsForImageLayout(VkImageLayout layout);
VkPipelineStageFlags PipelineStageForLayout(VkImageLayout layout);

void CmdBarrierImageLayout(VkCommandBuffer cmdbuffer,
                           VkImage image,
                           VkImageLayout oldImageLayout,
                           VkImageLayout newImageLayout,
                           const VkImageSubresourceRange& subresourceRange);

void CmdBarrierImageLayout(VkCommandBuffer cmdbuffer,
                           VkImage image,
                           VkImageLayout oldImageLayout,
                           VkImageLayout newImageLayout,
                           VkImageAspectFlags aspectMask);

inline void CmdBarrierImageLayout(VkCommandBuffer cmdBuffer, VkImage image, VkImageLayout oldImageLayout, VkImageLayout newImageLayout)
{
    CmdBarrierImageLayout(cmdBuffer, image, oldImageLayout, newImageLayout, VK_IMAGE_ASPECT_COLOR_BIT);
}

VkImageMemoryBarrier MakeImageMemoryBarrier(VkImage image,
                                            VkImageLayout oldLayout,
                                            VkImageLayout newLayout,
                                            VkImageAspectFlags aspectMask = VK_IMAGE_ASPECT_COLOR_BIT);

VkImageCreateInfo MakeImage2DCreateInfo(VkExtent2D size, VkFormat format, VkImageUsageFlags usage, uint32_t mipLevels = 1);

VkImageCreateInfo MakeImageCubeCreateInfo(const VkExtent2D& size,
                                          VkFormat format = VK_FORMAT_R8G8B8A8_UNORM,
                                          VkImageUsageFlags usage = VK_IMAGE_USAGE_SAMPLED_BIT,
                                          uint32_t mipLevels = 1);

VkImageViewCreateInfo MakeImage2DViewCreateInfo(VkImage image,
                                                VkFormat format = VK_FORMAT_R8G8B8A8_UNORM,
                                                VkImageAspectFlags aspectFlags = VK_IMAGE_ASPECT_COLOR_BIT,
                                                uint32_t levels = VK_REMAINING_MIP_LEVELS,
                                                const void* pNextImageView = nullptr);

/// ==================================================================
/// 图像纹理类定义
/// ==================================================================
class UploadHeap;

struct Texture
{
    VkDevice              device{};
    VkImage               image{};
    VkImageLayout         imageLayout{};
    VkImageView           view{};
    VkFormat              format{};
    uint32_t              width{}, height{};
    uint32_t              mipLevels  = 1;
    uint32_t              layerCount = 1;
    VkDescriptorImageInfo descriptor{};
    VkSampler             sampler{};
    Bitmap                bitmap{};

#ifdef USE_VMA
    VmaAllocator  allocator{};
    VmaAllocation imageAlloc{};
#else
    VkDeviceMemory deviceMemory{};
#endif

    void destroy();
    void updateDescriptor();
    void upload(UploadHeap* uploadHeap);

    virtual void loadFromFile(
        std::string_view fileName,
        VkDevice device,
        VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
        VmaAllocator allocator,
#endif
        VkImageUsageFlags imageUsageFlags = VK_IMAGE_USAGE_SAMPLED_BIT,
        VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
        bool bMipmap = true
    ) {}
};

struct Texture2D : public Texture
{
    void loadFromFile(
        std::string_view fileName,
        VkDevice device,
        VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
        VmaAllocator allocator,
#endif
        VkImageUsageFlags imageUsageFlags = VK_IMAGE_USAGE_SAMPLED_BIT,
        VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
        bool bMipmap = true
    ) override;
};

struct TextureCube : public Texture
{
    void loadFromFile(
        std::string_view fileName,
        VkDevice device,
        VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
        VmaAllocator allocator,
#endif
        VkImageUsageFlags imageUsageFlags = VK_IMAGE_USAGE_SAMPLED_BIT,
        VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
        bool bMipmap = true
    ) override;
};

/**
 * @brief 用来管理渲染过程中的 vulkan 图像，并非从文件读取创建
 */
struct TextureVK : public Texture
{
    void create(
        VkDevice device,
        VkPhysicalDevice physicalDevice,
#ifdef USE_VMA
        VmaAllocator allocator,
#endif
        const VkExtent2D& size,
        VkFormat format,
        VkImageAspectFlags aspectFlags = VK_IMAGE_ASPECT_COLOR_BIT,
        VkImageUsageFlags imageUsageFlags = VK_IMAGE_USAGE_SAMPLED_BIT,
        VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
        std::string_view name = ""
    );
};

} // yu::vk