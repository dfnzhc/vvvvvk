﻿//
// Created by 秋鱼 on 2022/6/1.
//

#pragma once

#include <vulkan/vulkan_core.h>

namespace yu::vk {

void SetupDebugMessenger(VkInstance instance);
void DestroyDebugMessenger(VkInstance instance);

class DebugUtil
{
public:
    DebugUtil() = default;
    DebugUtil(VkDevice device)
        : device_(device)
    {
    }

    static void setEnabled(bool state) { enabled_ = state; }

    void setup(VkDevice device) { device_ = device; }

    void setObjectName(const uint64_t object, const std::string& name, VkObjectType t)
    {
        if (enabled_) {
            VkDebugUtilsObjectNameInfoEXT s{VK_STRUCTURE_TYPE_DEBUG_UTILS_OBJECT_NAME_INFO_EXT, nullptr, t, object, name.c_str()};
            vkSetDebugUtilsObjectNameEXT(device_, &s);
        }
    }

    // clang-format off
    void setObjectName(VkBuffer object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_BUFFER); }
    void setObjectName(VkBufferView object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_BUFFER_VIEW); }
    void setObjectName(VkCommandBuffer object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_COMMAND_BUFFER); }
    void setObjectName(VkCommandPool object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_COMMAND_POOL); }
    void setObjectName(VkDescriptorPool object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_DESCRIPTOR_POOL); }
    void setObjectName(VkDescriptorSet object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_DESCRIPTOR_SET); }
    void setObjectName(VkDescriptorSetLayout object, const std::string& name)
    {
        setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_DESCRIPTOR_SET_LAYOUT);
    }
    void setObjectName(VkDevice object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_DEVICE); }
    void setObjectName(VkDeviceMemory object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_DEVICE_MEMORY); }
    void setObjectName(VkFramebuffer object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_FRAMEBUFFER); }
    void setObjectName(VkImage object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_IMAGE); }
    void setObjectName(VkImageView object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_IMAGE_VIEW); }
    void setObjectName(VkPipeline object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_PIPELINE); }
    void setObjectName(VkPipelineLayout object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_PIPELINE_LAYOUT); }
    void setObjectName(VkQueryPool object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_QUERY_POOL); }
    void setObjectName(VkQueue object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_QUEUE); }
    void setObjectName(VkRenderPass object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_RENDER_PASS); }
    void setObjectName(VkSampler object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_SAMPLER); }
    void setObjectName(VkSemaphore object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_SEMAPHORE); }
    void setObjectName(VkShaderModule object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_SHADER_MODULE); }
    void setObjectName(VkSwapchainKHR object, const std::string& name) { setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_SWAPCHAIN_KHR); }

#if VK_NV_ray_tracing
    void setObjectName(VkAccelerationStructureNV object, const std::string& name)
    {
        setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_ACCELERATION_STRUCTURE_NV);
    }
#endif
#if VK_KHR_acceleration_structure
    void setObjectName(VkAccelerationStructureKHR object, const std::string& name)
    {
        setObjectName((uint64_t) object, name, VK_OBJECT_TYPE_ACCELERATION_STRUCTURE_KHR);
    }
#endif
    // clang-format on

    //
    //---------------------------------------------------------------------------
    //
    void beginLabel(VkCommandBuffer cmdBuf, const std::string& label)
    {
        if (enabled_) {
            VkDebugUtilsLabelEXT s{VK_STRUCTURE_TYPE_DEBUG_UTILS_LABEL_EXT, nullptr, label.c_str(), {1.0f, 1.0f, 1.0f, 1.0f}};
            vkCmdBeginDebugUtilsLabelEXT(cmdBuf, &s);
        }
    }
    void endLabel(VkCommandBuffer cmdBuf)
    {
        if (enabled_) {
            vkCmdEndDebugUtilsLabelEXT(cmdBuf);
        }
    }
    void insertLabel(VkCommandBuffer cmdBuf, const std::string& label)
    {
        if (enabled_) {
            VkDebugUtilsLabelEXT s{VK_STRUCTURE_TYPE_DEBUG_UTILS_LABEL_EXT, nullptr, label.c_str(), {1.0f, 1.0f, 1.0f, 1.0f}};
            vkCmdInsertDebugUtilsLabelEXT(cmdBuf, &s);
        }
    }
    //
    // Begin and End Command Label MUST be balanced, this helps as it will always close the opened label
    //
    struct ScopedCmdLabel
    {
        ScopedCmdLabel(VkCommandBuffer cmdBuf, const std::string& label)
            : m_cmdBuf(cmdBuf)
        {
            if (enabled_) {
                VkDebugUtilsLabelEXT s{VK_STRUCTURE_TYPE_DEBUG_UTILS_LABEL_EXT, nullptr, label.c_str(), {1.0f, 1.0f, 1.0f, 1.0f}};
                vkCmdBeginDebugUtilsLabelEXT(cmdBuf, &s);
            }
        }
        ~ScopedCmdLabel()
        {
            if (enabled_) {
                vkCmdEndDebugUtilsLabelEXT(m_cmdBuf);
            }
        }
        void setLabel(const std::string& label)
        {
            if (enabled_) {
                VkDebugUtilsLabelEXT s{VK_STRUCTURE_TYPE_DEBUG_UTILS_LABEL_EXT, nullptr, label.c_str(), {1.0f, 1.0f, 1.0f, 1.0f}};
                vkCmdInsertDebugUtilsLabelEXT(m_cmdBuf, &s);
            }
        }

    private:
        VkCommandBuffer m_cmdBuf;
    };

    ScopedCmdLabel scopeLabel(VkCommandBuffer cmdBuf, const std::string& label) { return ScopedCmdLabel(cmdBuf, label); }

private:
    VkDevice           device_{VK_NULL_HANDLE};
    inline static bool enabled_ = false;
};

} // namespace yu::vk
