﻿//
// Created by 秋鱼 on 2022/8/4.
//

#include "obj_loader.hpp"
#include "common.hpp"

#define TINYOBJLOADER_IMPLEMENTATION
#include <tiny_obj_loader.h>
#include <logger.hpp>
#include <glm/gtx/dual_quaternion.hpp>
#include <glm/gtx/hash.hpp>

namespace std {
template<>
struct ::std::hash<yu::VertexObj>
{
    size_t operator()(yu::VertexObj const& vertex) const
    {
        return ((hash<glm::vec3>()(vertex.pos) ^ (hash<glm::vec3>()(vertex.normal) << 1)) >> 1)
            ^ (hash<glm::vec3>()(vertex.color) << 1) ^ (hash<glm::vec2>()(vertex.texCoord) << 1);
    }
};
}

namespace yu {

void ObjLoader::load(std::string_view fileName)
{
    auto fullPath = yu::GetModelFile(fileName.data());

    basePath = fullPath.substr(0, fullPath.find_last_of('/') + 1);

    tinyobj::ObjReader reader;
    reader.ParseFromFile(fullPath);

    if (!reader.Valid()) {
        LOG_FATAL("Error: {} \nFailed to load/parse .obj file: {}.", reader.Error(), fileName);
    }

    // 材质信息
    std::unordered_set<std::string> uniqueTextures{};
    for (auto const& material : reader.GetMaterials()) {
        MaterialObj m;
        m.ambient       = glm::vec3(material.ambient[0], material.ambient[1], material.ambient[2]);
        m.diffuse       = glm::vec3(material.diffuse[0], material.diffuse[1], material.diffuse[2]);
        m.specular      = glm::vec3(material.specular[0], material.specular[1], material.specular[2]);
        m.emission      = glm::vec3(material.emission[0], material.emission[1], material.emission[2]);
        m.transmittance = glm::vec3(material.transmittance[0], material.transmittance[1], material.transmittance[2]);
        m.dissolve      = material.dissolve;
        m.ior           = material.ior;
        m.shininess     = material.shininess;
        m.illum         = material.illum;

        if (!material.diffuse_texname.empty() && uniqueTextures.count(material.diffuse_texname) == 0) {
            uniqueTextures.insert(material.diffuse_texname);
            textures.push_back(material.diffuse_texname);
            m.textureID = static_cast<int>(textures.size()) - 1;
        }

        materials.emplace_back(m);
    }

    // 如果没有材质，那么就添加默认材质
    if (materials.empty()) {
        materials.emplace_back(MaterialObj());
    }

    const tinyobj::attrib_t& attrib = reader.GetAttrib();

    std::unordered_map<VertexObj, uint32_t> uniqueVertices{};
    for (const auto& shape : reader.GetShapes()) {
        matIndex.insert(matIndex.end(), shape.mesh.material_ids.begin(), shape.mesh.material_ids.end());

        for (const auto& index : shape.mesh.indices) {
            VertexObj vertex = {};
            const float* vp = &attrib.vertices[3 * index.vertex_index];
            vertex.pos = {*(vp + 0), *(vp + 1), *(vp + 2)};

            if (!attrib.normals.empty() && index.normal_index >= 0) {
                const float* np = &attrib.normals[3 * index.normal_index];
                vertex.normal = {*(np + 0), *(np + 1), *(np + 2)};
            }

            if (!attrib.texcoords.empty() && index.texcoord_index >= 0) {
                const float* tp = &attrib.texcoords[2 * index.texcoord_index + 0];
                vertex.texCoord = {*tp, 1.0f - *(tp + 1)};
            }

            if (!attrib.colors.empty()) {
                const float* vc = &attrib.colors[3 * index.vertex_index];
                vertex.color = {*(vc + 0), *(vc + 1), *(vc + 2)};
            }

            if (uniqueVertices.count(vertex) == 0) {
                uniqueVertices[vertex] = static_cast<uint32_t>(vertices.size());
                vertices.push_back(vertex);
            }

            indices.push_back(uniqueVertices[vertex]);
        }
    }

    // 如果材质纹理索引无效，则设为第一个材质
    for (auto& mi : matIndex) {
        if (mi < 0 || mi > materials.size())
            mi = 0;
    }


    // 如果没有顶点法线，那么使用面法线作为三角形三个顶点的法线
    if (attrib.normals.empty()) {
        for (size_t i = 0; i < indices.size(); i += 3) {
            VertexObj& v0 = vertices[indices[i + 0]];
            VertexObj& v1 = vertices[indices[i + 1]];
            VertexObj& v2 = vertices[indices[i + 2]];

            glm::vec3 n = glm::normalize(glm::cross((v1.pos - v0.pos), (v2.pos - v0.pos)));
            v0.normal = n;
            v1.normal = n;
            v2.normal = n;
        }
    }
}

} // yu