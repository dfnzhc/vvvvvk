﻿//
// Created by 秋鱼 on 2022/9/6.
//

#define TINYGLTF_IMPLEMENTATION
#include <logger.hpp>
#include "gltf_loader.hpp"
#include "common.hpp"

#include <glm/gtc/type_ptr.hpp>

namespace yu {

#define EXTENSION_ATTRIB_IRAY "NV_attributes_iray"

struct Bbox
{
    Bbox() = default;
    Bbox(vec3 _min, vec3 _max)
        : min_(_min), max_(_max)
    {
    }
    Bbox(const std::vector<vec3>& corners)
    {
        for (auto& c : corners) {
            insert(c);
        }
    }

    void insert(const vec3& v)
    {
        min_ = {std::min(min_.x, v.x), std::min(min_.y, v.y), std::min(min_.z, v.z)};
        max_ = {std::max(max_.x, v.x), std::max(max_.y, v.y), std::max(max_.z, v.z)};
    }

    void insert(const Bbox& b)
    {
        insert(b.min_);
        insert(b.max_);
    }

    inline Bbox& operator+=(float v)
    {
        min_ -= v;
        max_ += v;
        return *this;
    }

    inline bool isEmpty() const
    {
        return min_ == vec3{std::numeric_limits<float>::max()}
            || max_ == vec3{std::numeric_limits<float>::lowest()};
    }

    inline uint32_t rank() const
    {
        uint32_t result{0};
        result += min_.x < max_.x;
        result += min_.y < max_.y;
        result += min_.z < max_.z;
        return result;
    }
    inline bool isPoint() const { return min_ == max_; }
    inline bool isLine() const { return rank() == 1u; }
    inline bool isPlane() const { return rank() == 2u; }
    inline bool isVolume() const { return rank() == 3u; }
    inline vec3 min() { return min_; }
    inline vec3 max() { return max_; }
    inline vec3 extents() { return max_ - min_; }
    inline vec3 center() { return (min_ + max_) * 0.5f; }
    inline float radius() { return glm::length(max_ - min_) * 0.5f; }

    Bbox transform(glm::mat4 mat)
    {
        std::vector<vec3> corners(8);
        corners[0] = vec3{mat * vec4(min_.x, min_.y, min_.z, 1.0f)};
        corners[1] = vec3{mat * vec4(min_.x, min_.y, max_.z, 1.0f)};
        corners[2] = vec3{mat * vec4(min_.x, max_.y, min_.z, 1.0f)};
        corners[3] = vec3{mat * vec4(min_.x, max_.y, max_.z, 1.0f)};
        corners[4] = vec3{mat * vec4(max_.x, min_.y, min_.z, 1.0f)};
        corners[5] = vec3{mat * vec4(max_.x, min_.y, max_.z, 1.0f)};
        corners[6] = vec3{mat * vec4(max_.x, max_.y, min_.z, 1.0f)};
        corners[7] = vec3{mat * vec4(max_.x, max_.y, max_.z, 1.0f)};

        Bbox result(corners);
        return result;
    }

private:
    vec3 min_{std::numeric_limits<float>::max()};
    vec3 max_{-std::numeric_limits<float>::max()};
};

template<typename T, typename TFlag>
inline bool hasFlag(T a, TFlag flag)
{
    return (a & flag) == flag;
}

//--------------------------------------------------------------------------------------------------
// Collect the value of all materials
//
void GltfScene::importMaterials(const tinygltf::Model& tmodel)
{
    materials.reserve(tmodel.materials.size());

    for (auto& tmat : tmodel.materials) {
        GltfMaterial gmat;
        gmat.tmaterial = &tmat;  // Reference

        gmat.alphaCutoff              = static_cast<float>(tmat.alphaCutoff);
        gmat.alphaMode                = tmat.alphaMode == "MASK" ? 1 : (tmat.alphaMode == "BLEND" ? 2 : 0);
        gmat.doubleSided              = tmat.doubleSided ? 1 : 0;
        gmat.emissiveFactor           = tmat.emissiveFactor.size() == 3 ?
                                        vec3(tmat.emissiveFactor[0], tmat.emissiveFactor[1], tmat.emissiveFactor[2]) :
                                        vec3(0.f);
        gmat.emissiveTexture          = tmat.emissiveTexture.index;
        gmat.normalTexture            = tmat.normalTexture.index;
        gmat.normalTextureScale       = static_cast<float>(tmat.normalTexture.scale);
        gmat.occlusionTexture         = tmat.occlusionTexture.index;
        gmat.occlusionTextureStrength = static_cast<float>(tmat.occlusionTexture.strength);

        // PbrMetallicRoughness
        auto& tpbr = tmat.pbrMetallicRoughness;
        gmat.baseColorFactor =
            vec4(tpbr.baseColorFactor[0], tpbr.baseColorFactor[1], tpbr.baseColorFactor[2], tpbr.baseColorFactor[3]);
        gmat.baseColorTexture         = tpbr.baseColorTexture.index;
        gmat.metallicFactor           = static_cast<float>(tpbr.metallicFactor);
        gmat.metallicRoughnessTexture = tpbr.metallicRoughnessTexture.index;
        gmat.roughnessFactor          = static_cast<float>(tpbr.roughnessFactor);

        // KHR_materials_pbrSpecularGlossiness
        if (tmat.extensions.find(KHR_MATERIALS_PBRSPECULARGLOSSINESS_EXTENSION_NAME) != tmat.extensions.end()) {
            gmat.shadingModel = 1;

            const auto& ext = tmat.extensions.find(KHR_MATERIALS_PBRSPECULARGLOSSINESS_EXTENSION_NAME)->second;
            getVec4(ext, "diffuseFactor", gmat.specularGlossiness.diffuseFactor);
            getFloat(ext, "glossinessFactor", gmat.specularGlossiness.glossinessFactor);
            getVec3(ext, "specularFactor", gmat.specularGlossiness.specularFactor);
            getTexId(ext, "diffuseTexture", gmat.specularGlossiness.diffuseTexture);
            getTexId(ext, "specularGlossinessTexture", gmat.specularGlossiness.specularGlossinessTexture);
        }

        // KHR_texture_transform
        if (tpbr.baseColorTexture.extensions.find(KHR_TEXTURE_TRANSFORM_EXTENSION_NAME) != tpbr.baseColorTexture.extensions.end()) {
            const auto& ext = tpbr.baseColorTexture.extensions.find(KHR_TEXTURE_TRANSFORM_EXTENSION_NAME)->second;
            auto      & tt  = gmat.textureTransform;
            getVec2(ext, "offset", tt.offset);
            getVec2(ext, "scale", tt.scale);
            getFloat(ext, "rotation", tt.rotation);
            getInt(ext, "texCoord", tt.texCoord);

            // Computing the transformation
            auto translation = glm::mat3(1, 0, tt.offset.x, 0, 1, tt.offset.y, 0, 0, 1);
            auto rotation    = glm::mat3(cos(tt.rotation), sin(tt.rotation), 0, -sin(tt.rotation), cos(tt.rotation), 0, 0, 0, 1);
            auto scale       = glm::mat3(tt.scale.x, 0, 0, 0, tt.scale.y, 0, 0, 0, 1);
            tt.uvTransform = scale * rotation * translation;
        }

        // KHR_materials_unlit
        if (tmat.extensions.find(KHR_MATERIALS_UNLIT_EXTENSION_NAME) != tmat.extensions.end()) {
            gmat.unlit.active = 1;
        }

        // KHR_materials_anisotropy
        if (tmat.extensions.find(KHR_MATERIALS_ANISOTROPY_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_ANISOTROPY_EXTENSION_NAME)->second;
            getFloat(ext, "anisotropy", gmat.anisotropy.factor);
            getVec3(ext, "anisotropyDirection", gmat.anisotropy.direction);
            getTexId(ext, "anisotropyTexture", gmat.anisotropy.texture);
        }

        // KHR_materials_clearcoat
        if (tmat.extensions.find(KHR_MATERIALS_CLEARCOAT_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_CLEARCOAT_EXTENSION_NAME)->second;
            getFloat(ext, "clearcoatFactor", gmat.clearcoat.factor);
            getTexId(ext, "clearcoatTexture", gmat.clearcoat.texture);
            getFloat(ext, "clearcoatRoughnessFactor", gmat.clearcoat.roughnessFactor);
            getTexId(ext, "clearcoatRoughnessTexture", gmat.clearcoat.roughnessTexture);
            getTexId(ext, "clearcoatNormalTexture", gmat.clearcoat.normalTexture);
        }

        // KHR_materials_sheen
        if (tmat.extensions.find(KHR_MATERIALS_SHEEN_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_SHEEN_EXTENSION_NAME)->second;
            getVec3(ext, "sheenColorFactor", gmat.sheen.colorFactor);
            getTexId(ext, "sheenColorTexture", gmat.sheen.colorTexture);
            getFloat(ext, "sheenRoughnessFactor", gmat.sheen.roughnessFactor);
            getTexId(ext, "sheenRoughnessTexture", gmat.sheen.roughnessTexture);
        }

        // KHR_materials_transmission
        if (tmat.extensions.find(KHR_MATERIALS_TRANSMISSION_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_TRANSMISSION_EXTENSION_NAME)->second;
            getFloat(ext, "transmissionFactor", gmat.transmission.factor);
            getTexId(ext, "transmissionTexture", gmat.transmission.texture);
        }

        // KHR_materials_ior
        if (tmat.extensions.find(KHR_MATERIALS_IOR_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_IOR_EXTENSION_NAME)->second;
            getFloat(ext, "ior", gmat.ior.ior);
        }

        // KHR_materials_volume
        if (tmat.extensions.find(KHR_MATERIALS_VOLUME_EXTENSION_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_VOLUME_EXTENSION_NAME)->second;
            getFloat(ext, "thicknessFactor", gmat.volume.thicknessFactor);
            getTexId(ext, "thicknessTexture", gmat.volume.thicknessTexture);
            getFloat(ext, "attenuationDistance", gmat.volume.attenuationDistance);
            getVec3(ext, "attenuationColor", gmat.volume.attenuationColor);
        };

        // KHR_materials_displacement
        if (tmat.extensions.find(KHR_MATERIALS_DISPLACEMENT_NAME) != tmat.extensions.end()) {
            const auto& ext = tmat.extensions.find(KHR_MATERIALS_DISPLACEMENT_NAME)->second;
            getTexId(ext, "displacementGeometryTexture", gmat.displacement.displacementGeometryTexture);
            getFloat(ext, "displacementGeometryFactor", gmat.displacement.displacementGeometryFactor);
            getFloat(ext, "displacementGeometryOffset", gmat.displacement.displacementGeometryOffset);
        }

        materials.emplace_back(gmat);
    }

    // Make default
    if (materials.empty()) {
        GltfMaterial gmat;
        gmat.metallicFactor = 0;
        materials.emplace_back(gmat);
    }

    auto& images = tmodel.images;
    textures.resize(images.size());
    std::transform(std::execution::par, images.begin(), images.end(), textures.begin(),
                   [](const tinygltf::Image& image)
                   {
                       return image.uri;
                   });
}

//--------------------------------------------------------------------------------------------------
// Linearize the scene graph to world space nodes.
//
void GltfScene::importDrawableNodes(const tinygltf::Model& tmodel,
                                    GltfAttributes requestedAttributes,
                                    GltfAttributes forceRequested /*= GltfAttributes::All*/)
{
    checkRequiredExtensions(tmodel);

    int defaultScene = tmodel.defaultScene > -1 ? tmodel.defaultScene : 0;
    const auto& tscene = tmodel.scenes[defaultScene];

    // Finding only the mesh that are used in the scene
    std::set<uint32_t> usedMeshes;

    for (auto nodeIdx : tscene.nodes) {
        findUsedMeshes(tmodel, usedMeshes, nodeIdx);
    }

    // Find the number of vertex(attributes) and index
    //uint32_t nbVert{0};
    uint32_t nbIndex{0};
    uint32_t primCnt{0};  //  "   "  "  "
    for (const auto& m : usedMeshes) {
        auto& tmesh = tmodel.meshes[m];
        std::vector<uint32_t> vprim;
        for (const auto& primitive : tmesh.primitives) {
            if (primitive.mode != 4)  // Triangle
                continue;
            const auto& posAccessor = tmodel.accessors[primitive.attributes.find("POSITION")->second];
            //nbVert += static_cast<uint32_t>(posAccessor.count);
            if (primitive.indices > -1) {
                const auto& indexAccessor = tmodel.accessors[primitive.indices];
                nbIndex += static_cast<uint32_t>(indexAccessor.count);
            } else {
                nbIndex += static_cast<uint32_t>(posAccessor.count);
            }
            vprim.emplace_back(primCnt++);
        }
        meshToPrimMeshes[m] = std::move(vprim);  // mesh-id = { prim0, prim1, ... }
    }

    // Reserving memory
    indices.reserve(nbIndex);

    // Convert all mesh/primitives+ to a single primitive per mesh
    for (const auto& m : usedMeshes) {
        auto& tmesh = tmodel.meshes[m];

        for (const auto& tprimitive : tmesh.primitives) {
            processMesh(tmodel, tprimitive, requestedAttributes, forceRequested, tmesh.name);
            primMeshes.back().tmesh = &tmesh;
            primMeshes.back().tprim = &tprimitive;
        }
    }

    // Transforming the scene hierarchy to a flat list
    for (auto nodeIdx : tscene.nodes) {
        processNode(tmodel, nodeIdx, glm::mat4(1));
    }

    computeSceneDimensions();

    meshToPrimMeshes.clear();
    primitiveIndices32u.clear();
    primitiveIndices16u.clear();
    primitiveIndices8u.clear();
}

//--------------------------------------------------------------------------------------------------
//
//
void GltfScene::processNode(const tinygltf::Model& tmodel, int& nodeIdx, const glm::mat4& parentMatrix)
{
    const auto& tnode = tmodel.nodes[nodeIdx];

    glm::mat4 matrix      = getLocalMatrix(tnode);
    glm::mat4 worldMatrix = parentMatrix * matrix;

    if (tnode.mesh > -1) {
        const auto& meshes = meshToPrimMeshes[tnode.mesh];  // A mesh could have many primitives

        for (const auto& mesh : meshes) {
            GltfNode node;
            node.primMesh    = mesh;
            node.worldMatrix = worldMatrix;
            node.tnode       = &tnode;
            nodes.emplace_back(node);
        }
    } else if (tnode.camera > -1) {
        GltfCamera camera;
        camera.worldMatrix = worldMatrix;
        camera.cam         = tmodel.cameras[tmodel.nodes[nodeIdx].camera];

        // If the node has the Iray extension, extract the camera information.
        if (hasExtension(tnode.extensions, EXTENSION_ATTRIB_IRAY)) {
            auto& iray_ext   = tnode.extensions.at(EXTENSION_ATTRIB_IRAY);
            auto& attributes = iray_ext.Get("attributes");
            for (size_t idx = 0; idx < attributes.ArrayLen(); idx++) {
                auto& attrib = attributes.Get((int) idx);
                std::string attName = attrib.Get("name").Get<std::string>();
                auto& attValue = attrib.Get("value");
                if (attValue.IsArray()) {
                    auto vec = getVector<float>(attValue);
                    if (attName == "iview:position")
                        camera.eye = {vec[0], vec[1], vec[2]};
                    else if (attName == "iview:interest")
                        camera.center = {vec[0], vec[1], vec[2]};
                    else if (attName == "iview:up")
                        camera.up = {vec[0], vec[1], vec[2]};
                }
            }
        }

        cameras.emplace_back(camera);
    } else if (tnode.extensions.find(KHR_LIGHTS_PUNCTUAL_EXTENSION_NAME) != tnode.extensions.end()) {
        GltfLight light;
        const auto& ext = tnode.extensions.find(KHR_LIGHTS_PUNCTUAL_EXTENSION_NAME)->second;
        auto lightIdx = ext.Get("light").GetNumberAsInt();
        light.light       = tmodel.lights[lightIdx];
        light.worldMatrix = worldMatrix;
        lights.emplace_back(light);
    }

    // Recursion for all children
    for (auto child : tnode.children) {
        processNode(tmodel, child, worldMatrix);
    }
}

//--------------------------------------------------------------------------------------------------
// Extracting the values to a linear buffer
//
void GltfScene::processMesh(const tinygltf::Model& tmodel,
                            const tinygltf::Primitive& tmesh,
                            GltfAttributes requestedAttributes,
                            GltfAttributes forceRequested,
                            const std::string& name)
{
    // Only triangles are supported
    // 0:point, 1:lines, 2:line_loop, 3:line_strip, 4:triangles, 5:triangle_strip, 6:triangle_fan
    if (tmesh.mode != 4)
        return;

    GltfPrimMesh resultMesh;
    resultMesh.name          = name;
    resultMesh.materialIndex = std::max(0, tmesh.material);
    resultMesh.vertexOffset  = static_cast<uint32_t>(positions.size());
    resultMesh.firstIndex    = static_cast<uint32_t>(indices.size());

    // Create a key made of the attributes, to see if the primitive was already
    // processed. If it is, we will re-use the cache, but allow the material and
    // indices to be different.
    std::stringstream o;
    for (auto& a : tmesh.attributes) {
        o << a.first << a.second;
    }
    std::string key            = o.str();
    bool        primMeshCached = false;

    // Found a cache - will not need to append vertex
    auto it = cachePrimMesh.find(key);
    if (it != cachePrimMesh.end()) {
        primMeshCached         = true;
        GltfPrimMesh cacheMesh = it->second;
        resultMesh.vertexCount  = cacheMesh.vertexCount;
        resultMesh.vertexOffset = cacheMesh.vertexOffset;
    }


    // INDICES
    if (tmesh.indices > -1) {
        const tinygltf::Accessor  & indexAccessor = tmodel.accessors[tmesh.indices];
        const tinygltf::BufferView& bufferView    = tmodel.bufferViews[indexAccessor.bufferView];
        const tinygltf::Buffer    & buffer        = tmodel.buffers[bufferView.buffer];

        resultMesh.indexCount = static_cast<uint32_t>(indexAccessor.count);

        switch (indexAccessor.componentType) {
            case TINYGLTF_PARAMETER_TYPE_UNSIGNED_INT: {
                primitiveIndices32u.resize(indexAccessor.count);
                memcpy(primitiveIndices32u.data(), &buffer.data[indexAccessor.byteOffset + bufferView.byteOffset],
                       indexAccessor.count * sizeof(uint32_t));
                indices.insert(indices.end(), primitiveIndices32u.begin(), primitiveIndices32u.end());
                break;
            }
            case TINYGLTF_PARAMETER_TYPE_UNSIGNED_SHORT: {
                primitiveIndices16u.resize(indexAccessor.count);
                memcpy(primitiveIndices16u.data(), &buffer.data[indexAccessor.byteOffset + bufferView.byteOffset],
                       indexAccessor.count * sizeof(uint16_t));
                indices.insert(indices.end(), primitiveIndices16u.begin(), primitiveIndices16u.end());
                break;
            }
            case TINYGLTF_PARAMETER_TYPE_UNSIGNED_BYTE: {
                primitiveIndices8u.resize(indexAccessor.count);
                memcpy(primitiveIndices8u.data(), &buffer.data[indexAccessor.byteOffset + bufferView.byteOffset],
                       indexAccessor.count * sizeof(uint8_t));
                indices.insert(indices.end(), primitiveIndices8u.begin(), primitiveIndices8u.end());
                break;
            }
            default:
                std::cerr << "Index component type " << indexAccessor.componentType << " not supported!" << std::endl;
                return;
        }
    } else {
        // Primitive without indices, creating them
        const auto& accessor = tmodel.accessors[tmesh.attributes.find("POSITION")->second];
        for (auto i = 0; i < accessor.count; i++)
            indices.push_back(i);
        resultMesh.indexCount = static_cast<uint32_t>(accessor.count);
    }

    if (primMeshCached == false)  // Need to add this primitive
    {
        // POSITION
        {
            bool result = getAttribute<vec3>(tmodel, tmesh, positions, "POSITION");

            // Keeping the size of this primitive (Spec says this is required information)
            const auto& accessor = tmodel.accessors[tmesh.attributes.find("POSITION")->second];
            resultMesh.vertexCount = static_cast<uint32_t>(accessor.count);
            if (!accessor.minValues.empty()) {
                resultMesh.posMin = vec3(accessor.minValues[0], accessor.minValues[1], accessor.minValues[2]);
            } else {
                resultMesh.posMin = vec3(std::numeric_limits<float>::max());
                for (const auto& p : positions) {
                    for (int i = 0; i < 3; i++) {
                        if (p[i] < resultMesh.posMin[i])
                            resultMesh.posMin[i] = p[i];
                    }
                }
            }
            if (!accessor.maxValues.empty()) {
                resultMesh.posMax = vec3(accessor.maxValues[0], accessor.maxValues[1], accessor.maxValues[2]);
            } else {
                resultMesh.posMax = vec3(-std::numeric_limits<float>::max());
                for (const auto& p : positions)
                    for (int i = 0; i < 3; i++) {
                        if (p[i] > resultMesh.posMax[i])
                            resultMesh.posMax[i] = p[i];
                    }
            }
        }

        // NORMAL
        if (hasFlag(requestedAttributes, GltfAttributes::Normal)) {
            bool normalCreated = getAttribute<vec3>(tmodel, tmesh, normals, "NORMAL");

            if (!normalCreated && hasFlag(forceRequested, GltfAttributes::Normal))
                createNormals(resultMesh);
        }

        // TEXCOORD_0
        if (hasFlag(requestedAttributes, GltfAttributes::Texcoord_0)) {
            bool texcoordCreated = getAttribute<glm::vec2>(tmodel, tmesh, texcoords0, "TEXCOORD_0");
            if (!texcoordCreated)
                texcoordCreated = getAttribute<glm::vec2>(tmodel, tmesh, texcoords0, "TEXCOORD");
            if (!texcoordCreated && hasFlag(forceRequested, GltfAttributes::Texcoord_0))
                createTexcoords(resultMesh);
        }


        // TANGENT
        if (hasFlag(requestedAttributes, GltfAttributes::Tangent)) {
            bool tangentCreated = getAttribute<vec4>(tmodel, tmesh, tangents, "TANGENT");

            if (!tangentCreated && hasFlag(forceRequested, GltfAttributes::Tangent))
                createTangents(resultMesh);
        }

        // COLOR_0
        if (hasFlag(requestedAttributes, GltfAttributes::Color_0)) {
            bool colorCreated = getAttribute<vec4>(tmodel, tmesh, colors0, "COLOR_0");
            if (!colorCreated && hasFlag(forceRequested, GltfAttributes::Color_0))
                createColors(resultMesh);
        }
    }

    // Keep result in cache
    cachePrimMesh[key] = resultMesh;

    // Append prim mesh to the list of all primitive meshes
    primMeshes.emplace_back(resultMesh);
}  // namespace nvh


void GltfScene::createNormals(GltfPrimMesh& resultMesh)
{
    // Need to compute the normals
    std::vector<vec3> geonormal(resultMesh.vertexCount);
    for (size_t       i = 0; i < resultMesh.indexCount; i += 3) {
        uint32_t ind0 = indices[resultMesh.firstIndex + i + 0];
        uint32_t ind1 = indices[resultMesh.firstIndex + i + 1];
        uint32_t ind2 = indices[resultMesh.firstIndex + i + 2];
        const auto& pos0 = positions[ind0 + resultMesh.vertexOffset];
        const auto& pos1 = positions[ind1 + resultMesh.vertexOffset];
        const auto& pos2 = positions[ind2 + resultMesh.vertexOffset];
        const auto v1 = glm::normalize(pos1 - pos0);  // Many normalize, but when objects are really small the
        const auto v2 = glm::normalize(pos2 - pos0);  // cross will go below nv_eps and the normal will be (0,0,0)
        const auto n  = glm::cross(v2, v1);
        geonormal[ind0] += n;
        geonormal[ind1] += n;
        geonormal[ind2] += n;
    }
    for (auto& n : geonormal)
        n = glm::normalize(n);
    normals.insert(normals.end(), geonormal.begin(), geonormal.end());
}

void GltfScene::createTexcoords(GltfPrimMesh& resultMesh)
{

    // Set them all to zero
    //      m_texcoords0.insert(m_texcoords0.end(), resultMesh.vertexCount, glm::vec2(0, 0));

    // Cube map projection
    for (uint32_t i = 0; i < resultMesh.vertexCount; i++) {
        const auto& pos = positions[resultMesh.vertexOffset + i];
        float absX = fabs(pos.x);
        float absY = fabs(pos.y);
        float absZ = fabs(pos.z);

        int isXPositive = pos.x > 0 ? 1 : 0;
        int isYPositive = pos.y > 0 ? 1 : 0;
        int isZPositive = pos.z > 0 ? 1 : 0;

        float maxAxis, uc, vc;

        // POSITIVE X
        if (isXPositive && absX >= absY && absX >= absZ) {
            // u (0 to 1) goes from +z to -z
            // v (0 to 1) goes from -y to +y
            maxAxis = absX;
            uc      = -pos.z;
            vc      = pos.y;
        }
        // NEGATIVE X
        if (!isXPositive && absX >= absY && absX >= absZ) {
            // u (0 to 1) goes from -z to +z
            // v (0 to 1) goes from -y to +y
            maxAxis = absX;
            uc      = pos.z;
            vc      = pos.y;
        }
        // POSITIVE Y
        if (isYPositive && absY >= absX && absY >= absZ) {
            // u (0 to 1) goes from -x to +x
            // v (0 to 1) goes from +z to -z
            maxAxis = absY;
            uc      = pos.x;
            vc      = -pos.z;
        }
        // NEGATIVE Y
        if (!isYPositive && absY >= absX && absY >= absZ) {
            // u (0 to 1) goes from -x to +x
            // v (0 to 1) goes from -z to +z
            maxAxis = absY;
            uc      = pos.x;
            vc      = pos.z;
        }
        // POSITIVE Z
        if (isZPositive && absZ >= absX && absZ >= absY) {
            // u (0 to 1) goes from -x to +x
            // v (0 to 1) goes from -y to +y
            maxAxis = absZ;
            uc      = pos.x;
            vc      = pos.y;
        }
        // NEGATIVE Z
        if (!isZPositive && absZ >= absX && absZ >= absY) {
            // u (0 to 1) goes from +x to -x
            // v (0 to 1) goes from -y to +y
            maxAxis = absZ;
            uc      = -pos.x;
            vc      = pos.y;
        }

        // Convert range from -1 to 1 to 0 to 1
        float u = 0.5f * (uc / maxAxis + 1.0f);
        float v = 0.5f * (vc / maxAxis + 1.0f);

        texcoords0.emplace_back(u, v);
    }
}

void GltfScene::createTangents(GltfPrimMesh& resultMesh)
{

    // #TODO - Should calculate tangents using default MikkTSpace algorithms
    // See: https://github.com/mmikk/MikkTSpace

    std::vector<vec3> tangent(resultMesh.vertexCount);
    std::vector<vec3> bitangent(resultMesh.vertexCount);

    // Current implementation
    // http://foundationsofgameenginedev.com/FGED2-sample.pdf
    for (size_t i = 0; i < resultMesh.indexCount; i += 3) {
        // local index
        uint32_t i0 = indices[resultMesh.firstIndex + i + 0];
        uint32_t i1 = indices[resultMesh.firstIndex + i + 1];
        uint32_t i2 = indices[resultMesh.firstIndex + i + 2];
        assert(i0 < resultMesh.vertexCount);
        assert(i1 < resultMesh.vertexCount);
        assert(i2 < resultMesh.vertexCount);


        // global index
        uint32_t gi0 = i0 + resultMesh.vertexOffset;
        uint32_t gi1 = i1 + resultMesh.vertexOffset;
        uint32_t gi2 = i2 + resultMesh.vertexOffset;

        const auto& p0 = positions[gi0];
        const auto& p1 = positions[gi1];
        const auto& p2 = positions[gi2];

        const auto& uv0 = texcoords0[gi0];
        const auto& uv1 = texcoords0[gi1];
        const auto& uv2 = texcoords0[gi2];

        vec3 e1 = p1 - p0;
        vec3 e2 = p2 - p0;

        glm::vec2 duvE1 = uv1 - uv0;
        glm::vec2 duvE2 = uv2 - uv0;

        float r = 1.0F;
        float a = duvE1.x * duvE2.y - duvE2.x * duvE1.y;
        if (fabs(a) > 0)  // Catch degenerated UV
        {
            r = 1.0f / a;
        }

        vec3 t = (e1 * duvE2.y - e2 * duvE1.y) * r;
        vec3 b = (e2 * duvE1.x - e1 * duvE2.x) * r;

        tangent[i0] += t;
        tangent[i1] += t;
        tangent[i2] += t;

        bitangent[i0] += b;
        bitangent[i1] += b;
        bitangent[i2] += b;
    }

    for (uint32_t a = 0; a < resultMesh.vertexCount; a++) {
        const auto& t = tangent[a];
        const auto& b = bitangent[a];
        const auto& n = normals[resultMesh.vertexOffset + a];

        // Gram-Schmidt orthogonalize
        vec3 otangent = glm::normalize(t - (glm::dot(n, t) * n));

        // In case the tangent is invalid
        if (otangent == vec3(0, 0, 0)) {
            if (abs(n.x) > abs(n.y))
                otangent = vec3(n.z, 0, -n.x) / sqrt(n.x * n.x + n.z * n.z);
            else
                otangent = vec3(0, -n.z, n.y) / sqrt(n.y * n.y + n.z * n.z);
        }

        // Calculate handedness
        float handedness = (glm::dot(glm::cross(n, t), b) < 0.0F) ? -1.0F : 1.0F;
        tangents.emplace_back(otangent.x, otangent.y, otangent.z, handedness);
    }
}

void GltfScene::createColors(GltfPrimMesh& resultMesh)
{
    // Set them all to one
    colors0.insert(colors0.end(), resultMesh.vertexCount, vec4(1, 1, 1, 1));
}

//--------------------------------------------------------------------------------------------------
// Return the matrix of the node
//
glm::mat4 getLocalMatrix(const tinygltf::Node& tnode)
{
    glm::mat4 mtranslation{1};
    glm::mat4 mrot{1};
    glm::mat4 mscale{1};
    glm::mat4 matrix{1};

    // 模型的本地转换矩阵
    if (tnode.translation.size() == 3) {
        vec3 translation = glm::make_vec3(tnode.translation.data());
        mtranslation = glm::translate(glm::identity<mat4>(), translation);
    }

    if (tnode.rotation.size() == 4) {
        vec3 rotation = glm::make_vec3(tnode.rotation.data());
        mrot = glm::translate(glm::identity<mat4>(), rotation);
    }

    if (tnode.scale.size() == 3) {
        vec3 scale = glm::make_vec3(tnode.scale.data());
        mscale = glm::translate(glm::identity<mat4>(), scale);
    }

    if (tnode.matrix.size() == 16) {
        matrix = glm::make_mat4x4(tnode.matrix.data());
    };

    return mtranslation * mrot * mscale * matrix;
}

void GltfScene::destroy()
{
    materials.clear();
    nodes.clear();
    primMeshes.clear();
    cameras.clear();
    lights.clear();

    positions.clear();
    indices.clear();
    normals.clear();
    tangents.clear();
    texcoords0.clear();
    texcoords1.clear();
    colors0.clear();
    cameras.clear();
    
    dimensions = {};
    meshToPrimMeshes.clear();
    primitiveIndices32u.clear();
    primitiveIndices16u.clear();
    primitiveIndices8u.clear();
    cachePrimMesh.clear();
}

//--------------------------------------------------------------------------------------------------
// Get the dimension of the scene
//
void GltfScene::computeSceneDimensions()
{
    Bbox scnBbox;

    for (const auto& node : nodes) {
        const auto& mesh = primMeshes[node.primMesh];

        Bbox bbox(mesh.posMin, mesh.posMax);
        bbox = bbox.transform(node.worldMatrix);
        scnBbox.insert(bbox);
    }

    if (scnBbox.isEmpty() || !scnBbox.isVolume()) {
        LOG_ERROR("glTF: Scene bounding box invalid, Setting to: [-1,-1,-1], [1,1,1]");
        scnBbox.insert({-1.0f, -1.0f, -1.0f});
        scnBbox.insert({1.0f, 1.0f, 1.0f});
    }

    dimensions.min    = scnBbox.min();
    dimensions.max    = scnBbox.max();
    dimensions.size   = scnBbox.extents();
    dimensions.center = scnBbox.center();
    dimensions.radius = scnBbox.radius();
}

static uint32_t recursiveTriangleCount(const tinygltf::Model& model, int nodeIdx, const std::vector<uint32_t>& meshTriangle)
{
    auto& node = model.nodes[nodeIdx];
    uint32_t        nbTriangles{0};
    for (const auto child : node.children) {
        nbTriangles += recursiveTriangleCount(model, child, meshTriangle);
    }

    if (node.mesh >= 0)
        nbTriangles += meshTriangle[node.mesh];

    return nbTriangles;
}

//--------------------------------------------------------------------------------------------------
// Retrieving information about the scene
//
GltfStats GltfScene::getStatistics(const tinygltf::Model& tinyModel)
{
    GltfStats stats;

    stats.nbCameras   = static_cast<uint32_t>(tinyModel.cameras.size());
    stats.nbImages    = static_cast<uint32_t>(tinyModel.images.size());
    stats.nbTextures  = static_cast<uint32_t>(tinyModel.textures.size());
    stats.nbMaterials = static_cast<uint32_t>(tinyModel.materials.size());
    stats.nbSamplers  = static_cast<uint32_t>(tinyModel.samplers.size());
    stats.nbNodes     = static_cast<uint32_t>(tinyModel.nodes.size());
    stats.nbMeshes    = static_cast<uint32_t>(tinyModel.meshes.size());
    stats.nbLights    = static_cast<uint32_t>(tinyModel.lights.size());

    // Computing the memory usage for images
    for (const auto& image : tinyModel.images) {
        stats.imageMem += image.width * image.height * image.component * image.bits / 8;
    }

    // Computing the number of triangles
    std::vector<uint32_t> meshTriangle(tinyModel.meshes.size());
    uint32_t              meshIdx{0};
    for (const auto& mesh : tinyModel.meshes) {
        for (const auto& primitive : mesh.primitives) {
            if (primitive.indices > -1) {
                const tinygltf::Accessor& indexAccessor = tinyModel.accessors[primitive.indices];
                meshTriangle[meshIdx] += static_cast<uint32_t>(indexAccessor.count) / 3;
            } else {
                const auto& posAccessor = tinyModel.accessors[primitive.attributes.find("POSITION")->second];
                meshTriangle[meshIdx] += static_cast<uint32_t>(posAccessor.count) / 3;
            }
        }
        meshIdx++;
    }

    stats.nbUniqueTriangles = std::accumulate(meshTriangle.begin(), meshTriangle.end(), 0, std::plus<>());
    for (auto& node : tinyModel.scenes[0].nodes) {
        stats.nbTriangles += recursiveTriangleCount(tinyModel, node, meshTriangle);
    }

    return stats;
}

void GltfScene::checkRequiredExtensions(const tinygltf::Model& tmodel)
{
    std::set<std::string> supportedExtensions{
        KHR_LIGHTS_PUNCTUAL_EXTENSION_NAME,
        KHR_TEXTURE_TRANSFORM_EXTENSION_NAME,
        KHR_MATERIALS_PBRSPECULARGLOSSINESS_EXTENSION_NAME,
        KHR_MATERIALS_UNLIT_EXTENSION_NAME,
        KHR_MATERIALS_ANISOTROPY_EXTENSION_NAME,
        KHR_MATERIALS_IOR_EXTENSION_NAME,
        KHR_MATERIALS_VOLUME_EXTENSION_NAME,
        KHR_MATERIALS_TRANSMISSION_EXTENSION_NAME,
        KHR_TEXTURE_BASISU_NAME,
    };

    for (auto& e : tmodel.extensionsRequired) {
        if (supportedExtensions.find(e) == supportedExtensions.end()) {
            LOG_ERROR(
                "\n---------------------------------------\n"
                "The extension {} is REQUIRED and not supported \n",
                e.c_str());
        }
    }
}

void GltfScene::findUsedMeshes(const tinygltf::Model& tmodel, std::set<uint32_t>& usedMeshes, int nodeIdx)
{
    const auto& node = tmodel.nodes[nodeIdx];
    if (node.mesh >= 0)
        usedMeshes.insert(node.mesh);
    for (const auto& c : node.children)
        findUsedMeshes(tmodel, usedMeshes, c);
}

} // yu