﻿//
// Created by 秋鱼 on 2022/8/4.
//

#pragma once

#include <glm/vec3.hpp>
#include <glm/vec2.hpp>

namespace yu {

struct MaterialObj
{
    glm::vec3 ambient       = glm::vec3(0.1f, 0.1f, 0.1f);
    glm::vec3 diffuse       = glm::vec3(0.7f, 0.7f, 0.7f);
    glm::vec3 specular      = glm::vec3(1.0f, 1.0f, 1.0f);
    glm::vec3 transmittance = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 emission      = glm::vec3(0.0f, 0.0f, 0.10);

    float shininess = 0.f;
    float ior       = 1.0f;               // index of refraction
    float dissolve  = 1.f;            // 1 == opaque; 0 == fully transparent

    // illumination model (see http://www.fileformat.info/format/material/)
    //    0 Color on and Ambient off
    //    1 Color on and Ambient on
    //    2 Highlight on
    //    3 Reflection on and Ray trace on
    //    4 Transparency: Glass on
    //    Reflection: Ray trace on
    //    5 Reflection: Fresnel on and Ray trace on
    //    6 Transparency: Refraction on
    //    Reflection: Fresnel off and Ray trace on
    //    7 Transparency: Refraction on
    //    Reflection: Fresnel on and Ray trace on
    //    8 Reflection on and Ray trace off
    //    9 Transparency: Glass on
    //    Reflection: Ray trace off
    //    10 Casts shadows onto invisible surfaces
    int illum = 0;

    // texture 索引
    int textureID = -1;
};

struct VertexObj
{
    glm::vec3 pos;
    glm::vec3 normal;
    glm::vec3 color;
    glm::vec2 texCoord;

    bool operator==(const VertexObj& other) const
    {
        return pos == other.pos && normal == other.normal && color == other.color && texCoord == other.texCoord;
    }
};

struct ObjLoader
{
    void load(std::string_view fileName);

    std::vector<VertexObj>   vertices;
    std::vector<MaterialObj> materials;
    std::vector<std::string> textures;
    std::vector<uint32_t>    indices;
    std::vector<int32_t>     matIndex;

    std::string basePath = "";
};

} // yu