﻿//
// Created by 秋鱼 on 2022/6/2.
//

#include "logger.hpp"
#include "win_platform.hpp"
#include "RHI/vulkan/swap_chain.hpp"
#include "RHI/vulkan/pipeline.hpp"
#include "RHI/vulkan/error.hpp"
#include "RHI/vulkan/commands.hpp"
#include "RHI/vulkan/appbase.hpp"
#include "common/Bitmap.hpp"
#include "utils.hpp"
#include "RHI/vulkan/texture.hpp"
#include "RHI/vulkan/imgui.hpp"
#include "common/imgui_impl_glfw.h"
#include "RHI/vulkan/model_obj.hpp"
#include "RHI/vulkan/descriptor_sets.hpp"

#include <glm/glm.hpp>
#include <imgui.h>
#include <imgui_internal.h>
#include <RHI/vulkan/model_gltf.hpp>
#include <RHI/vulkan/skybox.hpp>
#include <RHI/vulkan/off_screen.hpp>
#include <RHI/vulkan/gbuffer.hpp>
#include <RHI/vulkan/imgui_impl_vulkan.h>

#include "../../data/shaders/gltfDefines.h"

using namespace yu;
using namespace yu::vk;

PushConstantRasterGLTF pcRaster{
    glm::identity<glm::mat4>(),                 // Identity matrix
    {15.f, 15.f, 8.f},   // light position
    0,                   // instance index
    10.f,                // light intensity
    0,                   // light typ
    0,                   // material index

    -1,                   // Gbuffer position
    -1,                   // Gbuffer albedo
    -1,                   // Gbuffer normal
    -1,                   // Gbuffer emission
    -1,                   // Gbuffer roughness
    -1,                   // Gbuffer depth
};

class RendererSample : public Renderer
{
public:
    void create(const Context* context, const MouseTracker* mouseTracker, SwapChain* swapChain) override
    {
        Renderer::create(context, mouseTracker, swapChain);

        offScreen.create(context->getDevice(), context->getPhysicalDevice(), res_alloc_.get(), command_pool_.get());
        offScreen.createDescriptor();
        offScreen.createPipeline(swapChain->getRenderPass());
    }

    void resize(uint32_t width, uint32_t height) override
    {
        Renderer::resize(width, height);

        offScreen.createFramebuffer({width, height});
        offScreen.updateDescriptorSet();
    }

    void prepareRender() override
    {
        // 加载资源
        if (!loadingFinished) {
            static int loadingStage = 0;
            loadingStage = loadAssets(loadingStage);

            // 资源没有加载完毕，还需要在下一次 update 中加载
            if (loadingStage != 0) {
                return;
            }
        }


        // 描述符及流水线设置
        // gltf 模型
        {
            DescriptorSetBindings descSetBinds;
            // 设置描述符
            {
                // 相机矩阵
                descSetBinds.addBinding(static_cast<uint32_t>(SceneBindingsGLTF::eGlobals),
                                        VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC,
                                        1,
                                        VK_SHADER_STAGE_VERTEX_BIT);

                // gltf descriptions
                descSetBinds.addBinding(static_cast<uint32_t>(SceneBindingsGLTF::eGltfDescs), VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1,
                                        VK_SHADER_STAGE_FRAGMENT_BIT);
                // Textures
                if (!model1.textures.empty())
                    descSetBinds.addBinding(static_cast<uint32_t>(SceneBindingsGLTF::eTextures),
                                            VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                                            static_cast<uint32_t>(model1.textures.size()),
                                            VK_SHADER_STAGE_FRAGMENT_BIT);

                // 创建描述符资源
                pass_off.descSetLayout = descSetBinds.createLayout(context_->getDevice());
                pass_off.descPool      = descSetBinds.createPool(context_->getDevice(), 1);
                pass_off.descSet       = descSetBinds.allocSet(context_->getDevice(), pass_off.descPool, pass_off.descSetLayout);

                // 更新描述符信息
                res_alloc_->getDynamicBuffer().setDescriptorSet(static_cast<uint32_t>(SceneBindingsGLTF::eGlobals),
                                                                sizeof(GlobalUniforms),
                                                                pass_off.descSet);

                std::vector<VkWriteDescriptorSet> writes;

                VkDescriptorBufferInfo sceneDesc{model1.descBuffer.buffer, 0, VK_WHOLE_SIZE};
                writes.emplace_back(descSetBinds.makeWrite(pass_off.descSet, static_cast<uint32_t>(SceneBindingsGLTF::eGltfDescs), &sceneDesc));

                // All texture samplers
                std::vector<VkDescriptorImageInfo> diit;
                for (auto& texture : model1.textures) {
                    diit.push_back(texture.descriptor);
                }
                if (!model1.textures.empty()) {
                    writes.emplace_back(descSetBinds.makeWriteArray(pass_off.descSet,
                                                                    static_cast<uint32_t>(SceneBindingsGLTF::eTextures),
                                                                    diit.data()));
                }

                // Writing the information
                vkUpdateDescriptorSets(context_->getDevice(), static_cast<uint32_t>(writes.size()), writes.data(), 0, nullptr);
            }

            // 创建流水线
            {
                VkPushConstantRange pushConstantRanges = {VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT,
                                                          0, sizeof(PushConstantRasterGLTF)};

                VkPipelineLayoutCreateInfo pipelineCreateInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
                pipelineCreateInfo.setLayoutCount         = 1;
                pipelineCreateInfo.pSetLayouts            = &(pass_off.descSetLayout);
                pipelineCreateInfo.pushConstantRangeCount = 1;
                pipelineCreateInfo.pPushConstantRanges    = &pushConstantRanges;
                VK_CHECK(vkCreatePipelineLayout(context_->getDevice(), &pipelineCreateInfo, nullptr, &pass_off.pipelineLayout));

                // 渲染到离屏图像中
                GraphicsPipelineGeneratorCombined pipelineGenerator
                                                      {context_->getDevice(), pass_off.pipelineLayout, offScreen.renderPass()};
                pipelineGenerator.setDepthTest(VK_TRUE);
                pipelineGenerator.setCullMode(VK_CULL_MODE_NONE);
                pipelineGenerator.addShader("modelGltf.vert", VK_SHADER_STAGE_VERTEX_BIT);
                pipelineGenerator.addShader("modelGltf.frag", VK_SHADER_STAGE_FRAGMENT_BIT);
                pipelineGenerator.addBindingDescriptions(model1.getBindingDescriptions());
                pipelineGenerator.addAttributeDescriptions(model1.getVertexInputDescriptions());

                pass_off.pipeline = pipelineGenerator.createPipeline(pipeline_cache_);
            }
        }

        // 天空盒子
        skyBox.createPipeline(offScreen.renderPass(), pipeline_cache_);

        loadingFinished = true;
    }

    void render() override
    {
        // 切换命令列表到当前帧
        frame_command_pool_->beginFrame();
        res_alloc_->beginFrame();

        // 取到一个命令缓冲区，然后开始记录
        auto cmdBuffer1 = frame_command_pool_->getFrameCommandBuffer();
        {
            VkCommandBufferBeginInfo cmdBufferBeginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            cmdBufferBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            VK_CHECK(vkBeginCommandBuffer(cmdBuffer1, &cmdBufferBeginInfo));
        }

        gpu_timer_.beginFrame(cmdBuffer1, time_stamps_);

        // Pass 1 ///////////////////////////////////// 

        {
            VkRenderPassBeginInfo renderPassBeginInfo{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
            renderPassBeginInfo.renderPass        = offScreen.renderPass();
            renderPassBeginInfo.framebuffer       = offScreen.frameBuffer();
            renderPassBeginInfo.renderArea.offset = {0, 0};
            renderPassBeginInfo.renderArea.extent = {width_, height_};

            std::vector<VkClearValue> clearColor(2);
            clearColor[0].color                 = {0.1f, 0.1f, 0.1f, 1.0f};
            clearColor[1].depthStencil          = {1.0f, 0};
            renderPassBeginInfo.clearValueCount = static_cast<uint32_t>(clearColor.size());
            renderPassBeginInfo.pClearValues    = clearColor.data();

            vkCmdBeginRenderPass(cmdBuffer1, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);
        }

        // 动态更新视口和裁剪矩形
        vkCmdSetScissor(cmdBuffer1, 0, 1, &scissor_);
        vkCmdSetViewport(cmdBuffer1, 0, 1, &viewport_);

        // 绑定流水线
        if (readyToRender) {
            // render pass 一些默认设置
            // 先渲染到离屏图像

            // 物体的绘制
            {
                GlobalUniforms hostUBO{};
                const auto     view = mouse_tracker_->camera_->view_mat;
                glm::mat4      proj = mouse_tracker_->camera_->proj_mat;

                hostUBO.viewProj    = proj * view;
                hostUBO.viewInverse = glm::inverse(view);
                hostUBO.projInverse = glm::inverse(proj);

                auto constantBufferInfo = res_alloc_->getDynamicBuffer().allocBuffer(sizeof(GlobalUniforms), &hostUBO);

                int      numUniformOffsets = 0;
                uint32_t uniformOffset     = 0;
                if (constantBufferInfo.buffer != nullptr) {
                    numUniformOffsets = 1;
                    uniformOffset     = static_cast<uint32_t>(constantBufferInfo.offset);
                }

                vkCmdBindDescriptorSets(cmdBuffer1, VK_PIPELINE_BIND_POINT_GRAPHICS, pass_off.pipelineLayout, 0, 1, &pass_off.descSet,
                                        numUniformOffsets,
                                        &uniformOffset);

                vkCmdBindPipeline(cmdBuffer1, VK_PIPELINE_BIND_POINT_GRAPHICS, pass_off.pipeline);

                model1.draw(cmdBuffer1, pass_off.pipelineLayout, &pcRaster);

                gpu_timer_.getTimeStamp(cmdBuffer1, "Draw Model");
            }

            // 天空盒绘制
            {
                glm::mat4  ubo{};
                const auto view = glm::mat4{glm::mat3{mouse_tracker_->camera_->view_mat}};
                const auto proj = mouse_tracker_->camera_->proj_mat;

                ubo = proj * view;

                skyBox.draw(cmdBuffer1, ubo);

                gpu_timer_.getTimeStamp(cmdBuffer1, "Draw sky box");
            }

        }
        // 停止 render pass 的记录
        vkCmdEndRenderPass(cmdBuffer1);

        frame_command_pool_->submitSingleCommandBuffer(cmdBuffer1);

        // Pass 2 ///////////////////////////////////// 

        // 取得当前帧缓冲区的索引
        auto imageIndex = swap_chain_->acquire();

        auto cmdBuffer2 = frame_command_pool_->getFrameCommandBuffer();
        {
            VkCommandBufferBeginInfo cmdBufferBeginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            cmdBufferBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            VK_CHECK(vkBeginCommandBuffer(cmdBuffer2, &cmdBufferBeginInfo));
        }
        // 离屏渲染
        {
            VkRenderPassBeginInfo renderPassBeginInfo{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
            renderPassBeginInfo.renderPass        = swap_chain_->getRenderPass();
            renderPassBeginInfo.framebuffer       = swap_chain_->getFrameBuffer(static_cast<int>(imageIndex));
            renderPassBeginInfo.renderArea.offset = {0, 0};
            renderPassBeginInfo.renderArea.extent = {width_, height_};

            std::vector<VkClearValue> clearColor(2);
            clearColor[0].color                 = {0.1f, 0.1f, 0.1f, 1.0f};
            clearColor[1].depthStencil          = {1.0f, 0};
            renderPassBeginInfo.clearValueCount = static_cast<uint32_t>(clearColor.size());
            renderPassBeginInfo.pClearValues    = clearColor.data();

            vkCmdBeginRenderPass(cmdBuffer2, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);
        }

        offScreen.draw(cmdBuffer2, {width_, height_});

        imGui_->draw(cmdBuffer2);
        gpu_timer_.getTimeStamp(cmdBuffer2, "ImGui Rendering");

        // 停止 render pass 的记录
        vkCmdEndRenderPass(cmdBuffer2);

        // 停止记录，并提交命令缓冲区
        VK_CHECK(vkEndCommandBuffer(cmdBuffer2));
        swap_chain_->submit(context_->getGCTQueue(), cmdBuffer2);

        // 交换链提交显示当前帧的命令，并转到下一帧
        VK_CHECK(swap_chain_->present());

        // 切换至下一帧的记录
        gpu_timer_.endFrame();
    }

    void destroy() override
    {
        model1.destroy();
        skyBox.destroy();

        pass_off.destroy(context_->getDevice());

        offScreen.destroy();
    }

    int loadAssets(int loadingStage)
    {
        const int stages = 12;
        // show loading progress
        ImGui::OpenPopup("Loading");
        if (ImGui::BeginPopupModal("Loading", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            float progress = static_cast<float>(loadingStage) / static_cast<float>(stages);
            ImGui::ProgressBar(progress, ImVec2(0.f, 0.f), nullptr);
            ImGui::EndPopup();
        }

        if (loadingStage == 0) {
        } else if (loadingStage == 4) {
            model1.load("glTF/Sponza/glTF/Sponza.gltf", res_alloc_.get());
        } else if (loadingStage == 5) {
            skyBox.create("immenstadter_horn_2k.hdr", context_->getDevice(), res_alloc_.get());

        } else if (loadingStage == 9) {
            // flush 内存，释放暂存堆
            res_alloc_->getUploadHeap().flushAndFinish();
            res_alloc_->getStaticBuffer().freeUploadHeap();

            return 0;
        }

        return loadingStage + 1;
    }

    void buildUI() override
    {
//        ImGui::Begin("CONFIG");
//
//        ImGui::Image((ImTextureID) ImGui_ImplVulkan_AddTexture(gBuffer.position.sampler, gBuffer.position.view, gBuffer.position.imageLayout),
//                     {256, 256});
//
//        ImGui::End();
    }

private:
    struct PassInfo
    {
        VkDescriptorSet       descSet{};
        VkDescriptorPool      descPool{};
        VkDescriptorSetLayout descSetLayout{};

        VkPipeline       pipeline{};
        VkPipelineLayout pipelineLayout{};

        inline void destroy(VkDevice device)
        {
            vkDestroyPipeline(device, pipeline, nullptr);
            vkDestroyPipelineLayout(device, pipelineLayout, nullptr);

            vkDestroyDescriptorPool(device, descPool, nullptr);
            vkDestroyDescriptorSetLayout(device, descSetLayout, nullptr);
        }
    };

    // off screen
    PassInfo pass_off;

    OffScreen offScreen;

    ModelGltf model1;
    SkyBox    skyBox;
};

class AppSample : public AppBase
{
public:
    AppSample() : AppBase()
    {
    }

    ~AppSample() override = default;

protected:
    void initRenderer() override
    {
        renderer_ = std::make_unique<RendererSample>();
    }

    void setVKContextCreateInfo(ContextCreateInfo& createInfo) override
    {

    }
    void buildUI() override
    {
        AppBase::buildUI();

        renderer_->buildUI();
    }

};

int main()
{
    San::LogSystem log;

    San::WinPlatform platform;
    platform.resize(1920, 1080);

    AppSample app{};
    platform.setApplication(&app);

    auto code = platform.initialize();
    if (code == San::ExitCode::Success) {

        code = platform.mainLoop();
    }

    platform.terminate(code);
}